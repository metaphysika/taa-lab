"""Seal v0.1.3 evidence only after all final offline gates pass."""
from pathlib import Path
import base64,hashlib,json,re,subprocess,sys,zipfile
ROOT=Path('/workspace/taa-lab');sys.path.insert(0,str(ROOT))
from live_demo.config import verify as verify_frozen
from live_demo.evidence import verify
from live_demo.state import LiveState
BASE='4ef00671ec27b1266a2d660c55fd19832c403e78'
WORK=Path('/workspace/scratch/live-demo-durable-v013')
OUT=ROOT/'docs/process/evidence/gateway-live-demo-durable-v013'
EXTERNAL=Path('/workspace/taa-live-demo-evidence')
def sha(raw):return hashlib.sha256(raw).hexdigest()
def old(name):return subprocess.check_output(['git','show',BASE+':'+name],cwd=ROOT)
def suite(name):
 p=Path('/tmp/taa-live-demo-durable-'+name+'-001.log');s=p.read_text()
 assert re.search(r'^OK(?: \(skipped=\d+\))?$',s,re.M),'suite unclosed/failed: '+name
 m=re.search(r'Ran (\d+) tests in ([\d.]+)s',s);skip=re.search(r'^OK \(skipped=(\d+)\)',s,re.M)
 return dict(tests=int(m[1]),seconds=float(m[2]),skips=int(skip[1]) if skip else 0,sha256=sha(p.read_bytes()))
def main():
 full=suite('full');focused=suite('focused');assert full['tests']==1184 and focused['tests']==52
 source=json.loads((WORK/'final-source-hashes.json').read_bytes())
 assert all(sha((ROOT/n).read_bytes())==h for n,h in source.items())
 frozen=verify_frozen();assert frozen==json.loads(old('live_demo/frozen/hashes.json'))
 preservation=json.loads(Path('/tmp/taa-live-demo-durable-preservation-001.json').read_bytes());assert preservation['status']=='PASS'
 neutral=json.loads(Path('/tmp/taa-live-demo-durable-neutral-001.json').read_bytes());assert neutral['status']=='PASS' and neutral['requests']==2
 verify('/tmp/taa-live-demo-durable-neutral-001')
 mutations=json.loads(Path('/tmp/taa-live-demo-durable-mutations-001.json').read_bytes());assert mutations['status']=='PASS'
 assert all(r['before']['passed'] and r['restored']['passed'] and r['mutant']['failures']==1 and r['mutant']['errors']==0 for r in mutations['controls'])
 live=LiveState();assert live.step_ledger.read_text().strip()=='0.008324'
 ledger=(ROOT/'results/formation-spending-v021/openai.json').read_bytes()
 assert ledger==(EXTERNAL/'neutral-4ef00671-20261024-002/openai-ledger-after.json').read_bytes()
 assert not (live.root/'check-attempt-000003.once').exists() and not (live.root/'run.once').exists()
 for number in (1,2):verify(EXTERNAL/('neutral-4ef00671-20261024-%03d/evidence'%number))
 probe=json.loads((EXTERNAL/'responses-auth-probe-001/report.json').read_bytes())
 assert probe==dict(status=401,type='invalid_request_error',code='invalid_api_key')
 assert set(probe)=={'status','type','code'}
 prior={}
 for directory in ('gateway-live-demo-v01','gateway-live-demo-pr37-review-v011','gateway-live-demo-pr37-staff-v012'):
  for p in (ROOT/'docs/process/evidence'/directory).iterdir():
   if p.is_file():
    name=str(p.relative_to(ROOT));raw=p.read_bytes();assert raw==old(name);prior[name]=sha(raw)
 for provider in ('claude','google','groq'):
  name='results/formation-spending-v021/'+provider+'.json';assert (ROOT/name).read_bytes()==old(name)
 files={}
 def add_tree(folder,prefix):
  for p in folder.rglob('*'):
   if p.is_file():files[prefix+'/'+str(p.relative_to(folder))]=p
 for folder in ('neutral-4ef00671-20261024-001','neutral-4ef00671-20261024-002','auth-probe-001','responses-auth-probe-001','three-auth-probes-001','state'):
  add_tree(EXTERNAL/folder,'live-audit/'+folder)
 files['live-audit/neutral-attempts-audit-001.md']=EXTERNAL/'neutral-attempts-audit-001.md'
 files['live-audit/responses_auth_probe.py']=EXTERNAL/'responses_auth_probe.py'
 files['live-audit/three_auth_probes.py']=EXTERNAL/'three_auth_probes.py'
 add_tree(Path('/tmp/taa-live-demo-durable-neutral-001'),'standin-neutral')
 add_tree(WORK,'methods-and-scenarios')
 for p in Path('/tmp').glob('taa-live-demo-durable-*'):
  if p.is_file() and p.suffix in ('.json','.log'):files['logs/'+p.name]=p
 for n in source:files['source/'+n]=ROOT/n
 OUT.mkdir(parents=True,exist_ok=True);members={}
 with zipfile.ZipFile(OUT/'acceptance.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for n,p in sorted(files.items()):
   assert p.name!='keys.env';raw=p.read_bytes();members[n]=sha(raw);z.writestr(n,raw)
  z.writestr('MEMBER_SHA256.json',json.dumps(members,indent=2,sort_keys=True)+'\n')
 with zipfile.ZipFile(OUT/'acceptance.zip') as z:
  assert z.testzip() is None and all(sha(z.read(n))==h for n,h in members.items())
 receipt=dict(status='PASS: offline repair; no further live calls or launch approval',version='v0.1.3',base=BASE,
  repository_tests=full,focused_tests=focused,mutations=mutations,preservation=preservation,standin_neutral=neutral,
  approved_free_probe=probe,approved_three_probes=[json.loads((EXTERNAL/('three-auth-probes-001/probe-%d.json'%i)).read_bytes()) for i in (1,2,3)],actual_model_requests_this_repair=0,actual_new_api_dollars_this_repair=0,
  state=dict(path=str(live.root),used_check_attempts=[1,2],persisted_step='0.008324',openai_cumulative='1.1411209749999984',
             provider_ledger= str(live.ledger),shared_lock=str(live.lock),no_live_attempt3=True),
  new_receipt_field='positive integer check_attempt for neutral receipts only; run format unchanged',
  prior_archives_unchanged=prior,frozen_input_hashes_unchanged=frozen,final_source_hashes=source,
  local_namespace='Kernel denies unshare; socket-denied local tests; pushed-head sudo-unshare CI checked in PR',
  archive=dict(path='acceptance.zip',bytes=(OUT/'acceptance.zip').stat().st_size,sha256=sha((OUT/'acceptance.zip').read_bytes()),members=len(members)+1))
 with (OUT/'validation.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
 print(json.dumps({n:receipt[n] for n in ('status','repository_tests','focused_tests','approved_free_probe','archive')},indent=2))
if __name__=='__main__':main()
