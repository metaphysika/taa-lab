"""Owner-approved one-shot POST {} auth probe; never record messages or keys."""
import hashlib,json,os,urllib.error,urllib.request
from pathlib import Path
root=Path('/workspace/taa-live-demo-evidence/responses-auth-probe-001')
root.mkdir(exist_ok=False)
key=os.environ.get('TAA_OPENAI_API_KEY')
if not key:raise SystemExit('TAA_OPENAI_API_KEY is not set; no request sent.')
paths=[Path('/workspace/taa-lab/results/formation-spending-v021/openai.json'),Path('/workspace/taa-lab/results/live-demo-v01-budget.txt')]
before=[hashlib.sha256(p.read_bytes()).hexdigest() for p in paths]
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs):return None
opener=urllib.request.build_opener(NoRedirect())
request=urllib.request.Request('https://api.openai.com/v1/responses',data=b'{}',method='POST',headers={'Content-Type':'application/json','Authorization':'Bearer '+key})
result=dict(status=None,type=None,code=None)
try:
 with opener.open(request,timeout=30) as response:result['status']=response.status
except urllib.error.HTTPError as error:
 result['status']=error.code
 try:
  payload=json.loads(error.read(65536))
  fields=payload.get('error',{}) if type(payload) is dict else {}
  if type(fields) is dict:
   types={'invalid_request_error','authentication_error','permission_error','server_error','insufficient_quota'}
   codes={'missing_required_parameter','invalid_api_key','invalid_organization','invalid_project','project_not_found','organization_deactivated','insufficient_permissions','insufficient_quota','access_terminated'}
   result['type']=fields.get('type') if fields.get('type') in types else ('withheld' if fields.get('type') is not None else None)
   result['code']=fields.get('code') if fields.get('code') in codes else ('withheld' if fields.get('code') is not None else None)
 except (ValueError,TypeError):pass
except Exception:pass
with (root/'report.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
assert before==[hashlib.sha256(p.read_bytes()).hexdigest() for p in paths], 'Accounting changed unexpectedly'
print(json.dumps(result,indent=2))
