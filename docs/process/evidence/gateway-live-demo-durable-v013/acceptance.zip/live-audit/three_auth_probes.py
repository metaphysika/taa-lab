"""Chris-approved three non-generating probes in one process, no retries."""
import hashlib,json,os
from pathlib import Path
from live_demo import adapter as client
root=Path('/workspace/taa-live-demo-evidence/three-auth-probes-001');root.mkdir(exist_ok=False)
key=os.environ.get('TAA_OPENAI_API_KEY')
if not key:raise SystemExit('Configured key variable missing; zero probes sent.')
accounting=[Path('/workspace/taa-lab/results/formation-spending-v021/openai.json'),Path('/workspace/taa-live-demo-evidence/state/step-budget.txt')]
before=[hashlib.sha256(p.read_bytes()).hexdigest() for p in accounting]
headers={'Content-Type':'application/json','Authorization':'Bearer '+key}
results=[]
for method,url,body in [('GET','https://api.openai.com/v1/models',None),('POST','https://api.openai.com/v1/responses',b'{}'),('POST','https://api.openai.com/v1/chat/completions',b'{}')]:
 result={'status':None,'type':None,'code':None}
 request=client.urllib.request.Request(url,data=body,method=method,headers=headers)
 try:
  with client.urllib.request.urlopen(request,timeout=30) as response:result['status']=response.status
 except client.urllib.error.HTTPError as error:
  result['status']=error.code
  result.update(client.http_error_fields(error))
 except Exception:pass
 results.append(result)
 with (root/('probe-%d.json'%len(results))).open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
assert before==[hashlib.sha256(p.read_bytes()).hexdigest() for p in accounting], 'Accounting changed unexpectedly'
print(json.dumps(results,indent=2))
