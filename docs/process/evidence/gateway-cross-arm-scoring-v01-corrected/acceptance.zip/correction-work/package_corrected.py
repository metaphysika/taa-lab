"""Package a single corrected run and reconcile every published data cell."""
from pathlib import Path
import argparse,csv,hashlib,json,shutil,subprocess,zipfile
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--run',type=Path,required=True);a=p.parse_args()
root=a.root.resolve();run=a.run.resolve();prep=Path(__file__).resolve().parent;rendered=run/'rendered'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
raw=load(run/'results.json');m=load(run/'manifest.json');summary=load(rendered/'summary.json');comparison=load(rendered/'comparison-validation.json')
assert m['status']=='completed' and len(raw['episodes'])==320
assert m['driver_sha256']==sha(prep/'run_corrected.py')
assert all(sha(root/path)==digest for path,digest in m['source_sha256'].items())
preserved=load(prep/'v0-preservation.json');assert all(sha(root/path)==digest for path,digest in preserved.items())
assert comparison['actual_worlds_boards_results_effects_and_audits_unchanged']
rows=list(csv.DictReader((rendered/'episodes.csv').open()));assert len(rows)==320
by_id={(e['case'],e['arm'],e['controller']):e for e in raw['episodes']};assert len(by_id)==320
for row in rows:
 e=by_id[(row['case'],row['arm'],row['controller'])]
 for key,value in e['metrics'].items():assert (json.loads(row[key]) if isinstance(value,list) else int(row[key]))==value
for arm,group in summary['arms'].items():
 selected=[r for r in rows if r['arm']==arm];assert len(selected)==40
 for key,value in group['metrics'].items():
  expected={r['case']+'/'+r['controller']:json.loads(r[key]) for r in selected} if isinstance(value,dict) else sum(int(r[key]) for r in selected)
  assert expected==value,(arm,key)
 for controller,groups in summary['by_controller'].items():
  selected_c=[r for r in selected if r['controller']==controller];assert len(selected_c)==10
  for key,value in groups[arm]['metrics'].items():
   expected={r['case']+'/'+r['controller']:json.loads(r[key]) for r in selected_c} if isinstance(value,dict) else sum(int(r[key]) for r in selected_c)
   assert expected==value,(arm,controller,key)
unknown=[json.loads(line) for line in (rendered/'unassessed.jsonl').read_text().splitlines()]
expected={(e['case'],e['arm'],e['controller'],i) for e in raw['episodes'] for i,o in enumerate(e['observations']) if o['semantic_label'] is None}
actual={(v['case'],v['arm'],v['controller'],v['observation_index']) for v in unknown}
assert len(unknown)==len(actual)==len(expected) and expected==actual
assert not load(rendered/'issues.json')
diffs=load(rendered/'metric-diffs.json');assert len(diffs)==240
supp=load(rendered/'supplementary-harm.json')
for arm,x in supp['arms'].items():
 assert x['actual_committed_acts']==sum(e['supplementary_harm']['actual_committed_acts'] for e in raw['episodes'] if e['arm']==arm)
 for key in ('actual_committed_acts','counted_commits','incomplete'):
  assert x[key]==sum(supp['by_controller'][c][arm][key] for c in m['controllers'])
 for d,count in x['dispositions'].items():assert count==sum(supp['by_controller'][c][arm]['dispositions'][d] for c in m['controllers'])
assert (prep/'discovery.exit').read_text().strip()=='0' and (prep/'scripted.exit').read_text().strip()=='0'
out=root/'docs/process/evidence/gateway-cross-arm-scoring-v01-corrected';out.mkdir(exist_ok=False)
for name in ('episodes.csv','summary.json','metric-diffs.json','comparison-validation.json','supplementary-harm.json'):
 shutil.copyfile(rendered/name,out/name)
report=(rendered/'TAA_CROSS_ARM_SCORING_v01_CORRECTED.md').read_text()
report+='\nFull evidence: [validation.json](evidence/gateway-cross-arm-scoring-v01-corrected/validation.json), [all metric diffs](evidence/gateway-cross-arm-scoring-v01-corrected/metric-diffs.json), [supplementary arm/controller data](evidence/gateway-cross-arm-scoring-v01-corrected/supplementary-harm.json), [episode CSV](evidence/gateway-cross-arm-scoring-v01-corrected/episodes.csv) and acceptance.zip in the same directory. Original [v0 report](TAA_CROSS_ARM_SCORING_v0.md) and evidence are retained byte-identical.\n'
report_path=root/'docs/process/TAA_CROSS_ARM_SCORING_v01_CORRECTED.md';report_path.write_text(report)
files={str(p.relative_to(run)):p for p in sorted(run.rglob('*')) if p.is_file()}
for path in sorted(prep.rglob('*')):
 if path.is_file() and '__pycache__' not in path.parts:files['correction-work/'+str(path.relative_to(prep))]=path
for name in ('comparators/commit_oracle.py','comparators/observed_world.py','comparators/cross_arm.py','tests/test_commit_oracle.py','tests/test_context_canonicalization.py','tests/fixtures/context_v0_source.py.txt','docs/process/TAA_CROSS_ARM_CORRECTION_v01_PLAN.md'):
 files['source/'+name]=root/name
manifest={name:sha(p) for name,p in files.items()}
archive=out/'acceptance.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in files.items():z.writestr(name,p.read_bytes())
 z.writestr('MANIFEST.sha256',''.join(digest+'  '+name+'\n' for name,digest in manifest.items()))
assert archive.stat().st_size<100*1024*1024
with zipfile.ZipFile(archive) as z:assert all(hashlib.sha256(z.read(name)).hexdigest()==digest for name,digest in manifest.items())
validation=dict(version='v0.1 corrected',counts=raw['counts'],runtime_commit=m['runtime_commit'],input_commit=m['input_commit'],
 started_utc=m['started_utc'],completed_utc=m['completed_utc'],protocol_sha256=raw['protocol_sha256'],
 unchanged_inputs=True,v0_preserved_sha256=preserved,source_sha256=m['source_sha256'],comparison=comparison,
 metric_arm_cells=240,changed_metric_arm_cells=sum(x['changed'] for x in diffs),common_protocol_metrics=25,episode_csv_rows=320,
 unassessed_items=len(unknown),nonpassing_records=0,all_published_cells_reconciled=True,
 supplementary_definition=supp['definition'],supplementary=supp['arms'],supplementary_incomplete=sum(x['incomplete'] for x in supp['arms'].values()),
 controls=load(prep/'control-evidence.json'),
 local_tests=dict(discovery_log_sha256=sha(prep/'discovery.log'),scripted_log_sha256=sha(prep/'scripted.log'),discovery_exit=0,scripted_exit=0),
 separate_fault_supplement=dict(executed=6,not_applicable_by_design=8,actual_receipt_mismatch_audits=4,pooled_into_scoring=False),
 tracegrant_coverage='Ten original declared development programs/contracts only; broader no-contract instances remain unrun.',
 report_sha256=sha(report_path),published_files={p.name:sha(p) for p in out.iterdir() if p.is_file() and p.name!='acceptance.zip'},
 archive=dict(path=str(archive.relative_to(root)),sha256=sha(archive),bytes=archive.stat().st_size,files=manifest))
# Keep the standalone validation small; full control payloads are archived.
validation['controls']={k:v for k,v in validation['controls'].items() if k!='rows'}
(out/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
assert all(sha(root/path)==digest for path,digest in preserved.items())
print(json.dumps(dict(counts=raw['counts'],comparison=comparison,unassessed=len(unknown),changed_cells=validation['changed_metric_arm_cells'],supplementary=supp['arms'],archive_bytes=archive.stat().st_size),indent=2))
