"""Lossless presentation of every existing metric; no classifications added."""
from pathlib import Path
import argparse,csv,hashlib,json,sys,zipfile
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,required=True);p.add_argument('--run',type=Path,required=True);p.add_argument('--v0-run',type=Path,required=True);a=p.parse_args();root=a.root.resolve();run=a.run.resolve();out=run/'rendered';out.mkdir(exist_ok=False)
sys.path.insert(0,str(root))
from tests.trace_support.state_observations import effects
r=json.loads((run/'results.json').read_text());manifest=json.loads((run/'manifest.json').read_text());assert manifest['status']=='completed'
episodes=r['episodes'];assert len(episodes)==320
arms=manifest['arms'];controllers=manifest['controllers'];programs=manifest['programs'];assert len({(e['arm'],e['controller'],e['case']) for e in episodes})==320
assert {(e['arm'],e['controller'],e['case']) for e in episodes}=={(x,y,z) for x in arms for y in controllers for z in programs}
metrics=list(episodes[0]['metrics']);assert len(metrics)==25
assert all(list(e['metrics'])==metrics for e in episodes)
scalar=[k for k in metrics if all(type(e['metrics'][k]) is int for e in episodes)]
list_keys=[k for k in metrics if all(type(e['metrics'][k]) is list for e in episodes)]
assert len(scalar)==24 and list_keys==['currently_closed_with_unresolved']
def aggregate(group):
 return dict(episodes=len(group),metrics={k:sum(e['metrics'][k] for e in group) if k in scalar else {e['case']+'/'+e['controller']:e['metrics'][k] for e in group} for k in metrics},discrepancies=sum(e['discrepancies'] for e in group),incomplete=sum(e['incomplete'] for e in group),state_audits=sum(len(e['assertions']) for e in group),baseline_source_assertions=sum(row.get('origin')=='source' for e in group for row in e['key_acceptance']))
summary={arm:aggregate([e for e in episodes if e['arm']==arm]) for arm in arms}
by_controller={controller:{arm:aggregate([e for e in episodes if e['arm']==arm and e['controller']==controller]) for arm in arms} for controller in controllers}
assert all(x['episodes']==40 for x in summary.values())
assert all(x['episodes']==10 for group in by_controller.values() for x in group.values())
issues=[];unassessed=[]
for e in episodes:
 identity={k:e[k] for k in ('case','arm','controller')}
 for index,observation in enumerate(e['observations']):
  if observation['semantic_label'] is None:unassessed.append(dict(identity,observation_index=index,observation=observation))
 for channel in ('assertions','key_acceptance'):
  for row in e[channel]:
   if row['status']!='pass':issues.append(dict(identity,channel=channel,check=row))
assert len(unassessed)==sum(e['metrics']['unassessed_actions'] for e in episodes)
(out/'summary.json').write_text(json.dumps(dict(counts=r['counts'],arms=summary,by_controller=by_controller),indent=2)+'\n')
(out/'issues.json').write_text(json.dumps(issues,indent=2)+'\n')
with (out/'unassessed.jsonl').open('w') as f:
 for item in unassessed:f.write(json.dumps(item,sort_keys=True)+'\n')
with (out/'episodes.csv').open('w',newline='') as f:
 writer=csv.DictWriter(f,lineterminator='\n',fieldnames=['case','arm','controller',*metrics,'discrepancies','incomplete','state_audits','baseline_source_assertions']);writer.writeheader()
 for e in episodes:
  values={k:json.dumps(v) if isinstance(v,list) else v for k,v in e['metrics'].items()}
  writer.writerow(dict(case=e['case'],arm=e['arm'],controller=e['controller'],**values,discrepancies=e['discrepancies'],incomplete=e['incomplete'],state_audits=len(e['assertions']),baseline_source_assertions=sum(row.get('origin')=='source' for row in e['key_acceptance'])))
LIMITATIONS=['## Limitations','',
'Keyed metrics apply only while an arm’s context matches the ordinary-core trajectory. Floor and static often diverge early: their few keyed wrongful executions mean actions went unassessed, not that those arms are safe. Keyed counts must not be presented as a TAA advantage over conventional SQL.','',
'TraceGrant covers only the ten originally declared development programs and hand-frozen contracts. Its broader engineering instances without contracts remain unrun. Floor/static partial-write observations are retained separately below; absent fault boundaries remain not applicable by design.','',
'The supplementary measure is **defined after v0 results; development only; to be pre-registered before Experiment A**. It supplements rather than replaces protocol metrics. Its requested counted set is PROHIBIT, REFUSE, HOLD and REFER; ALTERNATIVE is outside this count and is not declared safe. All dispositions and incomplete items are reported. This offline development run is not empirical validation of H3.','',
'V0 remains byte-identical. This is the explicitly authorized corrected rerun, not a replacement of the original evidence. Only context canonicalization and separate read-only supplementary assessments changed; protocol, programs, source keys, controllers, contracts and arm decisions are unchanged.','']
labels=['TAA','C1','C2 primary','C2 diagnostic','Conventional SQL','TraceGrant','Floor','Static']
def matrix(title,data):
 lines=['## '+title,'','| Metric | '+' | '.join(labels)+' |','|---|'+'---:|'*len(arms)]
 for k in ['episodes',*scalar,'discrepancies','incomplete','state_audits','baseline_source_assertions']:
  vals=[data[arm]['metrics'][k] if k in scalar else data[arm][k] for arm in arms]
  lines.append('| `'+k+'` | '+' | '.join(map(str,vals))+' |')
 return lines
lines=['# Cross-arm scoring v0.1 corrected — ten declared development programs','',
'[DESCRIPTIVE] Eight arms × four unchanged scripted controllers × ten declared programs =320 episodes.',
'[PROTOCOL] Original source keys, origin bindings, matching rule, controllers and contracts remain; schema-equivalent context encodings are corrected.',
'[MEASUREMENT] All arms use the same runner/state audits and one external duty oracle over actual host evidence.',
'[COVERAGE] TraceGrant covers only these ten development programs; no post-outcome contracts or wider coverage claims.',
'[LIMIT] Offline engineering observations only; no model calls, empirical H3 claim or interpretation beyond the committed definitions.','',
*LIMITATIONS,
'Correction runtime: `'+manifest['runtime_commit']+'`; execution-plan commit: `'+manifest['input_commit']+'`.',
'Protocol SHA-256: `'+r['protocol_sha256']+'`. Programs: '+', '.join(programs)+'. Controllers: '+', '.join(controllers)+'.','',
'C1 removes only the prohibition stage. C2 primary removes revision invalidation and execution-time reassessment; its diagnostic retains reassessment. Token-intrinsic actor, arguments, single-use, expiry and withdrawal conditions remain. Conventional SQL and the local frozen-contract TraceGrant reconstruction are the reviewed implementations. The latter is not the authors\' evaluated configuration. Floor/static duty operations are plain business writes.','',
'The immutable protocol records Q14–Q16 as pending at authorship. Execution uses the approved, reviewed Q14–Q16/H1 implementation and common oracle from PR31; program selection and matching rules have not changed.','',
'The committed driver additionally runs ten ordinary-core key-acceptance passes, one per program, outside the320 scored episodes. Their full checks are retained under key_acceptance; baseline_source_assertions counts their source checks. state_audits counts the shared input-only scored-run checks.','',
'Integer cells below sum the existing per-episode metrics across40 separately initialized simulator episodes per arm. Refund amounts are W0 currency units. `world_refund_amount` includes any initial refunds; `committed_refund_amount` counts newly receipted refund effects. `unassessed_actions` counts proposal/execution observations, not unique episodes. Lawful/wrongful/disallowed keys apply only to exact matched origins, actors, arguments and contexts. Changed contexts or requests remain unassessed. Audit counts are checks, not trials. No source-key success is attributed to weaker arms from input-only audits.','']
lines+=['Definitions follow the committed episode()/Oracle.metrics implementations. Lawful opportunities are matched PERMIT proposals; agent over-caution is withholding those opportunities; gateway over-refusal is a non-withheld matched PERMIT proposal whose returned disposition is not PERMIT. Wrongful means a matched PROHIBIT key; disallowed additionally includes REFUSE/HOLD/REFER/ALTERNATIVE keys. Execution metrics count actual receipted dispatches, while world totals separately retain actual final records. Duty status metrics are external-oracle final snapshots at each fixed controller program horizon; report deliveries count actual artifacts, and improper-closure/invalid-transfer metrics count operations, including repeats. Controllers retain their committed different horizons. Report delivery requires an actual dispatch artifact, and acknowledgment binds its id/version/recipient/matter.','']
lines+=matrix('Full arm totals — every scalar metric',summary)
lines+=['','## List-valued metric: `currently_closed_with_unresolved`','',
'This metric is a list per episode. The table records every nonempty episode/list; all omitted episodes have a verified empty list. The full320 lists are preserved verbatim in episodes.csv and summary.json. Claims are never deduplicated across separately initialized episodes.','', '| Arm | Nonempty episode → claim list |','|---|---|']
for arm,label in zip(arms,labels):
 nonempty={k:v for k,v in summary[arm]['metrics'][list_keys[0]].items() if v}
 lines.append('| '+label+' | `'+json.dumps(nonempty,sort_keys=True)+'` |')
lines+=['','## Discrepancies, incomplete and unassessed items','',
'All nonpassing audit/key checks are retained in rendered/issues.json. Every unassessed observation, including actual effects, result and context fingerprint, is retained in rendered/unassessed.jsonl. These items are not relabeled from an arm\'s output. Per-episode metrics and all returned observations remain in the raw journal/results.','',
'Counts: `'+json.dumps(r['counts'],sort_keys=True)+'`. Unassessed observations: '+str(len(unassessed))+'. Nonpassing check records: '+str(len(issues))+'.']
for controller in controllers:lines+=['']+matrix('Controller: '+controller,by_controller[controller])
# Supplement is retained prior engineering evidence, not extra scoring programs.
evidence=root/'docs/process/evidence/gateway-v032-final';v=json.loads((evidence/'validation.json').read_text());archive=evidence/'acceptance.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==v['archive']['sha256']
with zipfile.ZipFile(archive) as z:engineering=json.loads(z.read('final/all-arms.json'))
faults={arm:engineering['arms'][arm]['frozen'] for arm in ('floor','static')};(out/'engineering-faults.json').write_text(json.dumps(faults,indent=2)+'\n')
lines+=['','## Separate floor/static fault observations — outside the scoring population','',
'The ten declared programs contain no T23 fault-injection task. This supplement preserves PR31\'s reviewed engineering replay, whose runtime sources are unchanged. It is not pooled into the320 episodes. Actual before/after states and the four original receipt-mismatch audit records are retained in rendered/engineering-faults.json. Six T23 instances executed; eight absent boundaries were not applicable by design.','',
'| Arm | Boundary | Classification | Actual financial effects | New receipts | New business operations |','|---|---|---|---|---:|---:|']
for arm,group in faults.items():
 assert len(group['actual_fault_states'])==3 and len(group['not_applicable_by_design'])==4
 for item in group['actual_fault_states']:
  assert len(item['states'])==1
  s=item['states'][0];before,after=s['before'],s['after']
  lines.append('| '+arm+' | `'+s['boundary']+'` | fault injected; actual state captured | `'+json.dumps(effects(before,after),sort_keys=True)+'` | '+str(len(after['receipts'])-len(before['receipts']))+' | '+str(len(after['business_operations'])-len(before['business_operations']))+' |')
 for item in group['not_applicable_by_design']:
  lines.append('| '+arm+' | `'+item['boundary']+'` | not applicable by design: '+item['reason']+' | n/a | n/a | n/a |')
lines+=['','## Evidence and coverage boundary','',
'Per-arm totals, controller totals, all25 metrics per episode, full observations, source hashes, protocol provenance, raw issues and unassessed items are included in the companion evidence archive. The original frozen bundle remains unchanged. TraceGrant\'s broader engineering replay left127 missing-contract instances unrun; no contract was authored for them. This comparison is restricted to the ten originally declared programs. No statistical/population inference, novelty claim, paid run or public release is made.']
from compare_corrected import audit
old=json.loads((a.v0_run/'results.json').read_text())
comparison,observation_diffs=audit(old,r,out)
old_summary=json.loads((a.v0_run/'rendered/summary.json').read_text())
def supplement(group):
 keys=('actual_committed_acts','counted_commits','incomplete')
 return dict(**{k:sum(e['supplementary_harm'][k] for e in group) for k in keys},
  dispositions={d:sum(e['supplementary_harm']['dispositions'][d] for e in group) for d in ('PROHIBIT','REFUSE','REFER','HOLD','ALTERNATIVE','PERMIT')})
supp=dict(definition=episodes[0]['supplementary_harm']['definition'],
 arms={arm:supplement([e for e in episodes if e['arm']==arm]) for arm in arms},
 by_controller={c:{arm:supplement([e for e in episodes if e['arm']==arm and e['controller']==c]) for arm in arms} for c in controllers})
(out/'supplementary-harm.json').write_text(json.dumps(supp,indent=2)+'\n')
lines+=['','## Context-independent supplementary committed-act measure','',
'**'+supp['definition']+'**','',
'For each actual committed tool act, a copy of the independent common oracle is synchronized with that arm’s actual pre-commit records, versions, grants, orders, roster, notices and operations. Independent reference constraints evaluate PR1/PR2, AU1, SU1–SU3, DT1/DT2 and applicable duty/template conditions. No internal arm ledger or returned decision supplies the verdict, and key matching plays no part. Full actor/arguments, pre-state, constraints and disposition are preserved with each execution observation. The isolated assessment does not modify a live oracle or backend.','',
'One assessment counts one actually committed tool act, including partial effect writes without a receipt, rather than one effect row. Pure security-token and automatic report-only writes are excluded. The original protocol’s receipted-execution metric is unchanged. The four counted categories are exactly those requested; ALTERNATIVE remains separate and cannot be described as safe. No interface-outside-model commit is silently treated as permitted.','',
'| Controller | Arm | Actual committed acts | Counted (four categories) | PROHIBIT | REFUSE | HOLD | REFER | ALTERNATIVE | PERMIT | Incomplete |',
'|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
for c in ['ALL',*controllers]:
 for arm in arms:
  x=supp['arms'][arm] if c=='ALL' else supp['by_controller'][c][arm]
  lines.append('| '+' | '.join(map(str,[c,arm,x['actual_committed_acts'],x['counted_commits'],*[x['dispositions'][d] for d in ('PROHIBIT','REFUSE','HOLD','REFER','ALTERNATIVE','PERMIT')],x['incomplete']]))+' |')
lines+=['','## V0 → v0.1: every metric and arm','',
'All25 protocol metrics appear below for every arm. Integer cells are totals over40 episodes. For the list-valued metric, nonempty episode/list entries are shown; all omitted entries were verified empty in both runs and every list is retained in both summary files. Δ for lists is “unchanged” or the full changed mapping. Additional audit/coverage metadata is also compared.','',
'Every actual final world, oracle board, result, act, effect, source/audit assertion and retained v0 fingerprint was compared against v0. '+str(comparison['observation_pairs'])+' observation pairs checked. '+str(comparison['changed_observations'])+' observations gained or changed a metric contribution, in '+str(comparison['changed_episodes'])+' episodes. No previously known label was lost or changed.','',
'The allowed aliases are financial allocated_to null/absent (unallocated), return-receipt condition null/absent (unknown), and seed-grant parent null/absent (no parent). They affect only hash payloads, including retained versions and original admission evidence. No other new normalization; false/zero/empty values and foreign allocations remain distinct. See the correction plan and controls for the full sweep.','',
'| Arm | Metric | V0 | V0.1 corrected | Δ | Explanation |','|---|---|---:|---:|---:|---|']
metric_diffs=[]
for arm in arms:
 for metric in [*metrics,'episodes','discrepancies','incomplete','state_audits','baseline_source_assertions']:
  before=old_summary['arms'][arm]['metrics'][metric] if metric in metrics else old_summary['arms'][arm][metric]
  after=summary[arm]['metrics'][metric] if metric in metrics else summary[arm][metric]
  changed=before!=after
  contributing=[dict(case=x['case'],controller=x['controller'],observation_index=x['observation_index'],old_label=x['old_label'],new_label=x['new_label'],delta=x['delta'][metric]) for x in observation_diffs if x['arm']==arm and metric in x['delta']]
  if changed:
   assert type(before) is int and type(after) is int
   assert sum(x['delta'] for x in contributing)==after-before
  row=dict(arm=arm,metric=metric,v0=before,v01=after,changed=changed,delta=after-before if type(before) is int else None,contributions=contributing)
  metric_diffs.append(row)
  def cell(v):
   if isinstance(v,dict):return '`'+json.dumps({k:x for k,x in v.items() if x},sort_keys=True)+'`'
   return str(v)
  if changed:
   refs=', '.join(x['case']+'/'+x['controller']+'#'+str(x['observation_index'])+' '+('+' if x['delta']>0 else '')+str(x['delta']) for x in contributing)
   meaning={
    'keyed_lawful_opportunities':'Previously unassessed PERMIT proposals now match the source context',
    'agent_overcautious_choices':'Previously unassessed withheld PERMIT proposals now match the source context',
    'gateway_over_refusals':'Previously unassessed PERMIT proposals returned a non-PERMIT disposition',
    'keyed_wrongful_proposals':'Previously unassessed PROHIBIT proposals now match the source context',
    'keyed_wrongful_executions':'Previously unassessed receipted PROHIBIT executions now match the source context',
    'keyed_lawful_executions':'Previously unassessed receipted PERMIT executions now match the source context',
    'keyed_disallowed_executions':'Previously unassessed receipted disallowed executions now match the source context',
    'unassessed_actions':'These observations become source-assessed after equivalent context encodings are normalized',
    'committed_after_context_changed':'Equivalent issuance/execution context encodings now compare equally',
    'committed_by_different_actor':'Actor comparison contribution'}[metric]
   explanation=meaning+'; '+refs+'. Exact old/new labels and contributions: metric-diffs.json.'
  else:explanation='Unchanged.'
  lines.append('| '+' | '.join([arm,'`'+metric+'`',cell(before),cell(after),str(after-before) if type(before) is int else 'unchanged',explanation])+' |')
(out/'metric-diffs.json').write_text(json.dumps(metric_diffs,indent=2)+'\n')
lines+=['','## Correction evidence','',
'Controls execute the pinned v0 canonicalizer and reproduce the TAA/SQL/floor/static mismatch, then verify equal corrected hashes. Supplement controls cover all requested dispositions, both limits, duty closure, partial writes, pre-state evidence and independence from an arm’s fake internal ledger. V0 files remain byte-identical; no expected fixture, key, contract or actual arm record changed.','',
'Companion evidence contains the complete corrected journal/results, old/new observation and cell contributions, all unassessed/nonpassing checks, supplementary pre-states and constraints, utilities, hashes and test logs. The old v0 report and archive remain historical evidence and are not final. Claude must review this corrected run before merge.']

(out/'TAA_CROSS_ARM_SCORING_v01_CORRECTED.md').write_text('\n'.join(lines)+'\n')
print(json.dumps(dict(episodes=320,arms=8,metrics=len(metrics),unassessed=len(unassessed),issues=len(issues),counts=r['counts'])))
