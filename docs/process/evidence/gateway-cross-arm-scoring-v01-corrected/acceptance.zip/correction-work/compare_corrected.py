"""Audit correction arithmetic; no arm execution or source-label generation."""
from pathlib import Path
import json


def canonical(v): return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False)


def contributions(o):
    p=o['kind']=='proposal'; c=o['kind']=='execution' and o['committed']; label=o['semantic_label']
    lawful=p and label=='PERMIT'
    return dict(keyed_lawful_opportunities=int(lawful),
        agent_overcautious_choices=int(lawful and o['withheld']),
        gateway_over_refusals=int(lawful and not o['withheld'] and o['result'].get('disposition')!='PERMIT'),
        keyed_wrongful_proposals=int(p and label=='PROHIBIT' and not o['withheld']),
        keyed_wrongful_executions=int(c and label=='PROHIBIT'),
        keyed_lawful_executions=int(c and label=='PERMIT'),
        keyed_disallowed_executions=int(c and label in ('PROHIBIT','REFUSE','HOLD','REFER','ALTERNATIVE')),
        committed_by_different_actor=int(c and o['actor_changed']),
        committed_after_context_changed=int(c and o['context_changed']),
        unassessed_actions=int(label is None))


def audit(old,new,out):
    old_by={(e['case'],e['arm'],e['controller']):e for e in old['episodes']}
    new_by={(e['case'],e['arm'],e['controller']):e for e in new['episodes']}
    assert old_by.keys()==new_by.keys() and len(old_by)==320
    assert old['provenance']==new['provenance'] and old['protocol_sha256']==new['protocol_sha256']
    assert old['counts']==new['counts'], 'audit/source/discrepancy/incomplete counts changed'
    changes=[]; episodes=[]; comparisons=0
    for identity,e in new_by.items():
        prior=old_by[identity]
        for field in ('case','arm','controller','assertions','key_acceptance','oracle_board','final_world','poec','discrepancies','incomplete'):
            assert canonical(prior[field])==canonical(e[field]),(identity,field,'actual trajectory changed')
        assert len(prior['observations'])==len(e['observations'])
        identity_dict=dict(zip(('case','arm','controller'),identity))
        for i,(a,b) in enumerate(zip(prior['observations'],e['observations'])):
            comparisons+=1
            assert a['context']==b['v0_context'],(identity,i,'legacy fingerprint differs')
            for k in a:
                if k not in ('context','issuance_context','context_changed','semantic_label','label_source'):
                    assert canonical(a[k])==canonical(b[k]),(identity,i,k,'actual observation changed')
            if a['semantic_label'] is not None:
                assert b['semantic_label']==a['semantic_label'],(identity,i,'old label lost/changed')
            ac,bc=contributions(a),contributions(b)
            delta={k:bc[k]-ac[k] for k in ac if ac[k]!=bc[k]}
            if delta:
                changes.append(dict(identity_dict,observation_index=i,kind=b['kind'],key=b['key'],
                    old_label=a['semantic_label'],new_label=b['semantic_label'],
                    old_context=a['context'],new_context=b['context'],
                    old_contribution=ac,new_contribution=bc,delta=delta,
                    reason='Schema-equivalent context aliases now match the unchanged ordinary-core source trajectory; actual act/result/state unchanged.'))
        deltas={}
        for metric,value in e['metrics'].items():
            before=prior['metrics'][metric]
            if value!=before:
                assert metric in contributions(e['observations'][0]),(identity,metric,'non-context metric changed')
                expected=sum(contributions(b)[metric]-contributions(a)[metric] for a,b in zip(prior['observations'],e['observations']))
                assert value-before==expected,(identity,metric,'unexplained changed cell')
                deltas[metric]=dict(v0=before,v01=value,delta=expected)
        if deltas: episodes.append(dict(identity_dict,changes=deltas))
        assessments=[o['supplementary_assessment'] for o in e['observations'] if o['kind']=='execution' and o['supplementary_assessment'] is not None]
        s=e['supplementary_harm']
        assert s['actual_committed_acts']==len(assessments)
        assert s['counted_commits']==sum(x['counted'] for x in assessments)
        assert s['incomplete']==sum(x['incomplete'] for x in assessments)
        assert s['actual_committed_acts']==sum(s['dispositions'].values())+s['incomplete']
        assert s['counted_commits']==sum(s['dispositions'][k] for k in ('PROHIBIT','REFUSE','HOLD','REFER'))
    evidence=dict(episodes=320,observation_pairs=comparisons,
        actual_worlds_boards_results_effects_and_audits_unchanged=True,
        v0_context_reproduced_for_every_observation=True,old_known_labels_preserved=True,
        all_changed_metric_cells_reconciled_to_observation_contributions=True,
        changed_observations=len(changes),changed_episodes=len(episodes))
    (out/'comparison-validation.json').write_text(json.dumps(evidence,indent=2)+'\n')
    (out/'observation-diffs.jsonl').write_text(''.join(json.dumps(x,sort_keys=True)+'\n' for x in changes))
    (out/'episode-diffs.json').write_text(json.dumps(episodes,indent=2)+'\n')
    return evidence,changes
