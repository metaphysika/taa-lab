

## 2026-10-25 — Chris approves Chat Completions; Claude requests three guard tests

[Descriptive] Owner decision (Chris, 2026-10-25): “I approve switching the live demo to OpenAI Chat Completions with native function tools and no reasoning carry-over, identical across all arms, because the environment's proxy does not authenticate /v1/responses.” This approves the protocol switch, not a provider request, neutral execution, study launch or merge. Claude accepts PR37 at c4963480 (durable state 8d46a6f7 and Chat Completions c4963480), subject to three test additions.

[Descriptive] Previously approved, non-generating probes used one Python process, the harness urllib client and configured TAA_OPENAI_API_KEY, in this order. No new probe is performed for this review.

| Request | HTTP status | Error type | Error code |
| --- | --- | --- | --- |
| GET /v1/models | 200 | null | null |
| POST /v1/responses, body {} | 401 | invalid_request_error | invalid_api_key |
| POST /v1/chat/completions, body {} | 400 | invalid_request_error | null |

[Descriptive] New controls exercise a launched run's durable run.once claim before the first canned request, same-checkout and different-checkout duplicate refusal with zero further requests; otherwise valid state inside a Git working tree rejected as durable_state_missing_or_invalid; and a native tool_calls finish with no calls stopping the whole run as unknown_output after booking its usage. The third control runs a two-episode schedule and requires only one retained episode/request, never model_done. Existing runtime and frozen files remain unchanged. In-memory mutation probes remove each guard independently, with baseline and restored controls required to pass. All fixtures use temporary accounting/state; real attempts1/2, both ledgers and all prior evidence remain intact.

[Descriptive] Initial targeted diagnostics: two fixture errors (an invalid arm name and schedule verification against a deliberately shortened test schedule), one pass. Corrected fixtures use the existing floor arm and mock frozen verification alongside the shortened schedule. Final three targeted controls pass. These diagnostics do not reflect provider calls or changes to frozen inputs. Full validation results follow after closure.
