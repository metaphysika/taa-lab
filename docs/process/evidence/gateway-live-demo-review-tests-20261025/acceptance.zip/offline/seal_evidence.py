"""Seal offline review evidence only after all validation has completed."""
from pathlib import Path
import hashlib, json, re, subprocess, sys, zipfile

ROOT=Path('/workspace/taa-lab')
WORK=Path('/workspace/scratch/live-demo-review-v015')
BASE='c4963480668d28cfaebdd50e67d0983c2120101d'
sys.path.insert(0,str(ROOT))
from live_demo.evidence import verify
from live_demo.config import verify as frozen_verify

def sha(raw):return hashlib.sha256(raw).hexdigest()
def suite(name,count):
    raw=(WORK/(name+'-001.log')).read_bytes();text=raw.decode()
    assert re.search(r'^OK(?: \(skipped=\d+\))?$',text,re.M),name
    match=re.search(r'Ran (\d+) tests in ([\d.]+)s',text)
    assert int(match[1])==count
    skip=re.search(r'^OK \(skipped=(\d+)\)',text,re.M)
    return dict(tests=count,seconds=float(match[2]),skips=int(skip[1]) if skip else 0,sha256=sha(raw))

def main():
    full=suite('full',1193);focused=suite('focused',61)
    sources=json.loads((WORK/'source-hashes.json').read_bytes())
    assert all(sha((ROOT/name).read_bytes())==value for name,value in sources.items())
    accounting=json.loads((WORK/'actual-accounting-hashes.json').read_bytes())
    assert all(sha(Path(name).read_bytes())==value for name,value in accounting.items())
    state=Path('/workspace/taa-live-demo-evidence/state')
    assert sorted(p.name for p in state.glob('*.once'))==['check-attempt-000001.once','check-attempt-000002.once']
    for path in (ROOT/'live_demo').rglob('*'):
        if path.is_file() and '__pycache__' not in str(path):
            assert path.read_bytes()==subprocess.check_output(['git','show',BASE+':'+str(path.relative_to(ROOT))],cwd=ROOT)
    frozen=frozen_verify()
    preservation=json.loads((WORK/'preservation-001.json').read_bytes())
    assert preservation['status']=='PASS' and len(preservation['protected_hashes'])==140 and preservation['episodes']==320
    mutants=json.loads((WORK/'mutations-002.json').read_bytes())
    assert mutants['status']=='PASS' and len(mutants['controls'])==7
    assert all(c['before']['passed'] and c['restored']['passed'] and c['mutant']['failures']==1 and c['mutant']['errors']==0 for c in mutants['controls'])
    neutral=json.loads((WORK/'neutral-001.log').read_bytes())
    assert neutral['stop']=='complete' and neutral['requests']==2
    standin=json.loads((WORK/'standin-001.log').read_bytes())
    assert standin['stop']=='complete' and standin['episodes']==30
    faults=json.loads((WORK/'faults-001.log').read_bytes())
    assert [(r['probe'],r['stop'],r['calls']) for r in faults]==[
        ('partial','partial_reply',1),('exhausted','transport_exhaustion',5),('cap','cap_stop',0)]
    assert all(r['retained_episode'] for r in faults)
    checkpoints={str(p.parent.relative_to(WORK)):verify(p.parent) for p in WORK.rglob('checkpoint.json')}
    assert len(checkpoints)==35
    assert (WORK/'scripted-scenarios-001').is_dir()
    prior={}
    for p in (ROOT/'docs/process/evidence').glob('gateway-live-demo*/**/*'):
        if p.is_file():
            name=str(p.relative_to(ROOT));assert p.read_bytes()==subprocess.check_output(['git','show',BASE+':'+name],cwd=ROOT)
            prior[name]=sha(p.read_bytes())
    for provider in ('claude','google','groq'):
        name='results/formation-spending-v021/'+provider+'.json'
        assert (ROOT/name).read_bytes()==subprocess.check_output(['git','show',BASE+':'+name],cwd=ROOT)
    out=ROOT/'docs/process/evidence/gateway-live-demo-review-tests-20261025'
    out.mkdir(exist_ok=False)
    files={'source/'+name:ROOT/name for name in sources}
    files.update({'offline/'+str(p.relative_to(WORK)):p for p in WORK.rglob('*') if p.is_file() and '__pycache__' not in str(p)})
    hashes={}
    with zipfile.ZipFile(out/'acceptance.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for name,path in sorted(files.items()):
            assert path.name!='keys.env'
            raw=path.read_bytes();hashes[name]=sha(raw);archive.writestr(name,raw)
        archive.writestr('MEMBER_SHA256.json',json.dumps(hashes,indent=2,sort_keys=True)+'\n')
    with zipfile.ZipFile(out/'acceptance.zip') as archive:
        assert archive.testzip() is None
        assert all(sha(archive.read(name))==value for name,value in hashes.items())
    report=dict(status='PASS',base=BASE,repository_tests=full,focused_tests=focused,
        local_isolation='unshare denied by kernel; focused suite denies sockets; namespace CI recorded in PR',
        preservation=preservation,standin=standin,faults=[{k:r[k] for k in ('probe','stop','calls')} for r in faults],
        neutral=neutral,mutations=mutants,checkpoints=checkpoints,source_hashes=sources,
        frozen_input_hashes=frozen,prior_evidence_unchanged=prior,actual_accounting_hashes=accounting,
        actual_provider_requests=0,actual_new_spend=0,
        archive=dict(bytes=(out/'acceptance.zip').stat().st_size,members=len(hashes)+1,sha256=sha((out/'acceptance.zip').read_bytes())))
    with (out/'validation.json').open('x') as stream:json.dump(report,stream,indent=2);stream.write('\n')
    print(json.dumps({k:report[k] for k in ('status','repository_tests','focused_tests','archive')},indent=2))

if __name__=='__main__':main()
