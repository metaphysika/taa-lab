"""Package verified offline build only; sealed H contents never enter the archive."""
from pathlib import Path
import hashlib,json,os,re,sys,zipfile
ROOT=Path('/workspace/taa-experiment-a');V=Path('/workspace/scratch/experiment-a');OUT=ROOT/'docs/process/evidence/experiment-a-offline'
sys.path.insert(0,str(ROOT))
from experiment_a import config
from experiment_a.cases import sealed_digest

def read(p):return json.loads(p.read_bytes())
def sha(b):return hashlib.sha256(b).hexdigest()
full=(V/'full-tests-closure.log').read_text()
m=re.search(r'Ran (\d+) tests in ([0-9.]+)s',full)
assert m and int(m[1])==1616 and 'OK (skipped=36)' in full and 'FAILED (' not in full,'final full discovery incomplete or failed'
assert 'Ran 52 tests' in (V/'focused-chain-closure.log').read_text() and '\nOK\n' in (V/'focused-chain-closure.log').read_text()
assert read(V/'preservation.json')['status']=='PASS'
verification=read(V/'evidence-chain-verification.json')
assert verification['frame_chains_verified']==435 and verification['raw_H_chains_kept_external']==18
assert not verification['actual_experiment_state_provisioned']
for name,digest in verification['current_runtime_source_sha256'].items():assert sha((ROOT/name).read_bytes())==digest,'runtime source changed after verification'
config.verify()
seal=sealed_digest('/workspace/taa-experiment-a-sealed/H-v01-encoding-final')
assert seal==verification['H_sha256']==(config.INPUTS/'H.sha256').read_text().strip()
for group in ('state_and_openai','all_provider_ledgers'):
    for name,digest in read(V/'actual-state-ledger-before.json')[group].items():
        assert Path(name).name!='keys.env';assert sha(Path(name).read_bytes())==digest,'actual accounting/marker change'
reports=read(V/'canned-neutral-summary.json')
assert all(r['stop']=='complete' and r['requests']==2 for r in reports.values())
assert read(V/'structure/report.json')['status']=='STRUCTURE_PASS'
assert '"stop": "complete"' in (V/'canned-pilot-execution.log').read_text() and '"episodes": 396' in (V/'canned-pilot-execution.log').read_text()
assert 'Saved to results/20261026-005050-scripted/' in (V/'scripted-all-closure.log').read_text()
record=dict(claim='[Descriptive] Offline engineering validation complete, reliable primary scoring BLOCKED by oracle binding finding; no launch.',
            base_commit='e98c40a9bcb0f81bd8b5ac48ff3fb5b60218d8ef',
            full_discovery=dict(tests=int(m[1]),existing_optional_skips=36,seconds=m[2],exit_code=0),
            focused_tests=dict(tests=52,exit_code=0,network='socket creation denied; pushed CI uses sudo unshare'),
            scripted_all_exit_code=0,canned_schedule_episodes=396,canned_neutral_requests_per_provider=2,
            twin_pairs_structurally_verified=12,controller_completion_cells=36,controller_turns_each=4,
            controller_qualification='P02/P10/H02/H10 have disallowed independent-oracle assessments in all arms; see controller-qualification.json; no unqualified lawfulness PASS',
            no_lawful_completion_labels=0,H_sha256=seal,guide_sha256=config.load('approval.json')['guide_sha256'],
            proposed_output_tokens=config.OUTPUT_TOKENS,provider_price_status='verify before launch; no pricing fetch',
            key_presence={v:bool(os.environ.get(v)) for v in config.KEY_VARIABLES.values()},
            actual_provider_requests=0,actual_model_calls=0,actual_new_api_dollars='0',actual_markers_and_ledgers_unchanged=True,
            actual_experiment_state_provisioned=False,policy_implementations_unchanged=True,
            preservation=read(V/'preservation.json'),evidence_frame_chains_verified=435,raw_H_chains_external=18,canonical_frame_mirrors=3,
            source_changes_after_controller=verification['source_changes_after_controller'],runtime_source_sha256=verification['current_runtime_source_sha256'],
            expected_outcomes_authored_or_generated=False,lawful_controller_or_full_canned_campaign_rerun=False,
            remaining_gates=['Claude build review','Astra conventional review','blind expected key separate commit','Astra guide/measures review','oracle-binding review and separately authorized repair','verified provider prices/limits','exact-commit owner launch receipt'],
            limitations=['Canned responses and fixture prices do not establish provider compatibility or model behavior.',
                         'All36 completion observations include inherited same-customer W0 claims; completion alone does not certify oracle lawfulness.',
                         'Three original canned directories retain auxiliary JSON; byte-identical frame mirrors verify without editing originals.',
                         'H encoded files and detailed H feasibility evidence remain private outside Git/model run paths.'])
files={}
for p in sorted(V.rglob('*')):
    if p.is_file() and p.name!='RESUME.md' and '__pycache__' not in p.parts and p.suffix!='.zip':
        assert p.name!='keys.env';assert not p.is_symlink()
        files['validation/'+str(p.relative_to(V))]=p.read_bytes()
# Explicit source selection, never traverse attachments or the sealed root.
source=[*sorted((ROOT/'experiment_a').rglob('*')),
    ROOT/'tests/test_experiment_a.py',ROOT/'tests/test_experiment_a_guards.py',ROOT/'scripts/check_experiment_a_cases.py',
    ROOT/'.github/workflows/experiment-a.yml',ROOT/'docs/process/TAA_EXPERIMENT_A_OFFLINE_v01.md',ROOT/'docs/process/TAA_EXPERIMENT_A_DESIGN_v01.md']
for p in source:
    if p.is_file() and '__pycache__' not in p.parts:
        assert p.name!='keys.env' and not p.is_symlink();files['source/'+str(p.relative_to(ROOT))]=p.read_bytes()
for p in OUT.glob('*'):
    if p.is_file() and p.name not in ('validation.json','acceptance.zip'):files['review/'+p.name]=p.read_bytes()
files['verification.json']=(json.dumps(record,sort_keys=True,indent=2)+'\n').encode()
patterns=[rb'\b(?:sk-(?:proj-|ant-)?[A-Za-z0-9_-]{20,}|AIza[A-Za-z0-9_-]{25,}|gh[pousr]_[A-Za-z0-9]{20,})',rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',rb'(?i)authorization[\x22\x27\s:]+bearer\s+[A-Za-z0-9._-]{10,}']
secrets=[v.encode() for k,v in os.environ.items() if v and any(tag in k for tag in ('API_KEY','TOKEN_SECRET','ACCESS_TOKEN'))]
for name,data in files.items():
    assert not any(re.search(pattern,data) for pattern in patterns),'credential pattern in '+name+' (content withheld)'
    assert not any(secret in data for secret in secrets),'configured credential match in '+name+' (content withheld)'
members={name:sha(data) for name,data in sorted(files.items())}
files['manifest.json']=(json.dumps({'claim':'[Descriptive] Offline review archive; H encoded inputs excluded.','files':members},sort_keys=True,indent=2)+'\n').encode()
archive=OUT/'acceptance.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(files.items()):
        info=zipfile.ZipInfo(name,(2026,10,25,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
        z.writestr(info,data,compresslevel=9)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,digest in members.items():assert sha(z.read(name))==digest
record['archive']=dict(path=str(archive.relative_to(ROOT)),sha256=sha(archive.read_bytes()),bytes=archive.stat().st_size,members=len(files),files=members)
record['credential_scan']=dict(findings=0,files=len(members),keys_env_read_or_copied=False,limit='No matches to credential patterns/configured values; not a proof about unknown secrets.')
(OUT/'validation.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k not in ('archive','preservation','runtime_source_sha256')},indent=2))
print(json.dumps({k:v for k,v in record['archive'].items() if k!='files'},indent=2))
