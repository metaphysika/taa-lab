"""Read-only audit plus byte-identical canonical mirrors; no case/model execution."""
from pathlib import Path
import hashlib,json,re,shutil,sys
ROOT=Path('/workspace/taa-experiment-a');V=Path('/workspace/scratch/experiment-a')
sys.path.insert(0,str(ROOT))
from live_demo.evidence import verify,encoded
from experiment_a import config
from experiment_a.cases import sealed_digest

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
config.verify()
report=json.loads((V/'lawful-controller-once/report.json').read_bytes())
assert report['status']=='PASS' and len(report['controllers'])==36
assert all(r['lawful_completion'] and r['turns']==4 for r in report['controllers'])
seal=sealed_digest('/workspace/taa-experiment-a-sealed/H-v01-encoding-final')
assert seal==(config.INPUTS/'H.sha256').read_text().strip()==report['H_sha256']
for name,digest in report['source_sha256'].items():
    if name in ('experiment_a/run.py','experiment_a/check.py'):continue
    assert sha(ROOT/name)==digest,name
before=V/'pre-chain-filename-fix'
assert (ROOT/'experiment_a/run.py').read_text()==(before/'run.py').read_text().replace("'fixture-'+provider+'.json'","'fixture-'+provider+'.txt'")
assert (ROOT/'experiment_a/check.py').read_text()==(before/'check.py').read_text().replace("'fixture-provider.json'","'fixture-provider.txt'")
changes={name:dict(campaign_source_sha256=report['source_sha256'][name],current_source_sha256=sha(ROOT/name),change='offline auxiliary ledger extension only; no request/host/controller logic changes') for name in ('experiment_a/run.py','experiment_a/check.py')}
roots=[V/'canned-pilot',*sorted((V/'canned-pilot').glob('episode-*')),V/'canned-neutral-anthropic',V/'canned-neutral-google']
roots+=sorted(p for p in (V/'lawful-controller-once').iterdir() if p.is_dir())
hroot=Path('/workspace/taa-experiment-a-sealed')/('feasibility-'+seal)
roots+=sorted(p for p in hroot.iterdir() if p.is_dir())
assert len(roots)==435
mirrors=V/'canonical-chain-mirrors';mirrors.mkdir(exist_ok=False)
checks=[]
for directory in roots:
    outside=directory.is_relative_to(hroot)
    label='sealed/'+directory.name if outside else str(directory.relative_to(V))
    auxiliary=[]
    try:
        checkpoint=verify(directory);source='original directory'
    except ValueError:
        assert directory.name in ('canned-pilot','canned-neutral-anthropic','canned-neutral-google')
        auxiliary=[p.name for p in directory.glob('*.json') if p.name!='checkpoint.json' and not re.fullmatch(r'[0-9]{6}\.json',p.name)]
        expected=['fixture-anthropic.json','fixture-google.json'] if directory.name=='canned-pilot' else ['fixture-provider.json']
        assert sorted(auxiliary)==sorted(expected)
        derived=mirrors/directory.name;derived.mkdir(exist_ok=False)
        for p in directory.glob('*.json'):
            if p.name=='checkpoint.json' or re.fullmatch(r'[0-9]{6}\.json',p.name):
                shutil.copyfile(p,derived/p.name);assert sha(p)==sha(derived/p.name)
        checkpoint=verify(derived);source='byte-identical canonical-frame mirror; original auxiliary JSON retained'
    checks.append(dict(directory=label,checkpoint=checkpoint,verification=source,auxiliary_json=auxiliary,raw_H_stays_sealed=outside))
state=json.loads((V/'actual-state-ledger-before.json').read_bytes())
for group in ('state_and_openai','all_provider_ledgers'):
    for name,digest in state[group].items():
        assert Path(name).name!='keys.env';assert sha(Path(name))==digest,'actual marker or ledger changed'
summary=dict(claim='[Descriptive] Retained numeric chains verified without changing original evidence or rerunning a case.',
             frame_chains_verified=len(checks),raw_H_chains_kept_external=18,canonical_mirrors=3,
             checks=checks,source_changes_after_controller=changes,H_sha256=seal,
             current_runtime_source_sha256={str(p.relative_to(ROOT)):sha(p) for p in sorted((ROOT/'experiment_a').rglob('*.py'))},
             original_case_guide_inputs_unchanged=True,actual_markers_and_ledgers_unchanged=True,
             actual_experiment_state_provisioned=Path('/workspace/taa-experiment-a-evidence/state').exists())
assert not summary['actual_experiment_state_provisioned']
(V/'evidence-chain-verification.json').write_text(json.dumps(summary,sort_keys=True,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ('checks','current_runtime_source_sha256')},indent=2))
