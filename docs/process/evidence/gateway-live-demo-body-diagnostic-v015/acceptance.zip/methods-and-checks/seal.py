"""Seal this completed diagnostic round after final offline checks pass."""
from pathlib import Path
from decimal import Decimal
import hashlib,json,re,subprocess,sys,zipfile
ROOT=Path('/workspace/taa-lab');sys.path.insert(0,str(ROOT))
WORK=Path('/workspace/scratch/live-demo-diagnostic-v015')
LIVE=Path('/workspace/taa-live-demo-evidence/request-body-diagnostic-20261025-001')
BASE='fae033e05d3ecb35e308524f78ed7eead5ebefad'
from live_demo.config import verify as frozen_verify
from live_demo.evidence import verify
from live_demo.state import LiveState
def sha(raw):return hashlib.sha256(raw).hexdigest()
def old(name):return subprocess.check_output(['git','show',BASE+':'+name],cwd=ROOT)
def suite(name,count):
    p=Path('/workspace/scratch/live-demo-error-param-'+name+'-001.log');s=p.read_text()
    assert re.search(r'^OK(?: \(skipped=\d+\))?$',s,re.M),name
    m=re.search(r'Ran (\d+) tests in ([\d.]+)s',s);skip=re.search(r'^OK \(skipped=(\d+)\)',s,re.M)
    assert int(m[1])==count
    return dict(tests=count,seconds=float(m[2]),skips=int(skip[1]) if skip else 0,sha256=sha(p.read_bytes()))
def main():
    full=suite('full',1194);focused=suite('focused',62)
    source=json.loads((WORK/'source-hashes.json').read_bytes())
    assert all(sha((ROOT/p).read_bytes())==h for p,h in source.items())
    for p in (ROOT/'live_demo').rglob('*'):
        if p.is_file() and '__pycache__' not in str(p) and p.name!='adapter.py':assert p.read_bytes()==old(str(p.relative_to(ROOT)))
    frozen=frozen_verify();assert frozen==json.loads(old('live_demo/frozen/hashes.json'))
    result=json.loads((LIVE/'result.json').read_bytes());plan=json.loads((LIVE/'plan.json').read_bytes())
    assert result['requests']==4 and Decimal(result['total_reserved_dollars'])<=Decimal('0.01')
    assert verify(LIVE/'evidence')==result['checkpoint']
    assert [r['status'] for r in result['rows']]==[400,400,200,400]
    assert all(r['error']==dict(type='invalid_request_error',code=None,param='reasoning_effort') for r in result['rows'] if r['status']==400)
    assert sum(Decimal(r['booked_dollars']) for r in result['rows'])==Decimal(result['booked_dollars'])==Decimal('0.006370050')
    state=LiveState()
    assert state.ledger.read_bytes()==(LIVE/'openai-ledger-after.json').read_bytes()
    assert state.step_ledger.read_bytes()==(LIVE/'step-budget-after.txt').read_bytes()
    assert state.step_ledger.read_text().strip()=='0.018854925'
    assert plan['initial_marker_hashes']=={p.name:sha(p.read_bytes()) for p in state.root.glob('*.once')}
    assert not (state.root/'run.once').exists() and not (state.root/'check-attempt-000004.once').exists()
    assert not state.lock.exists()
    prior={}
    for p in (ROOT/'docs/process/evidence').glob('gateway-live-demo*/**/*'):
        if p.is_file():
            name=str(p.relative_to(ROOT));assert p.read_bytes()==old(name);prior[name]=sha(p.read_bytes())
    for provider in ('claude','google','groq'):
        name='results/formation-spending-v021/'+provider+'.json';assert (ROOT/name).read_bytes()==old(name)
    preservation=json.loads((WORK/'preservation.json').read_bytes());assert preservation['status']=='PASS'
    assert len(preservation['protected_hashes'])==140 and preservation['episodes']==320
    mutants=json.loads((WORK/'review-mutations.json').read_bytes());assert mutants['status']=='PASS' and len(mutants['controls'])==7
    assert 'PASS: removing the param pattern fails one assertion' in (WORK/'param-mutation.log').read_text()
    assert 'four-successes PASS 4' in (WORK/'standin-validation.log').read_text()
    assert (WORK/'scripted-scenarios').is_dir()
    files={}
    for folder,prefix in ((LIVE,'actual-diagnostic'),(WORK,'methods-and-checks')):
        for p in folder.rglob('*'):
            if p.is_file() and '__pycache__' not in str(p):files[prefix+'/'+str(p.relative_to(folder))]=p
    attempt3=Path('/workspace/taa-live-demo-evidence/neutral-fae033e0-20261025-003')
    verify(attempt3/'evidence')
    for p in attempt3.rglob('*'):
        if p.is_file():files['prior-attempt3/'+str(p.relative_to(attempt3))]=p
    for p in Path('/workspace/scratch').glob('live-demo-error-param-*.log'):files['logs/'+p.name]=p
    for name in source:files['source/'+name]=ROOT/name
    out=ROOT/'docs/process/evidence/gateway-live-demo-body-diagnostic-v015';out.mkdir(exist_ok=False)
    members={}
    with zipfile.ZipFile(out/'acceptance.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for name,p in sorted(files.items()):
            assert p.name!='keys.env';raw=p.read_bytes();members[name]=sha(raw);archive.writestr(name,raw)
        archive.writestr('MEMBER_SHA256.json',json.dumps(members,sort_keys=True,indent=2)+'\n')
    with zipfile.ZipFile(out/'acceptance.zip') as archive:
        assert archive.testzip() is None and all(sha(archive.read(n))==h for n,h in members.items())
    report=dict(status='PASS',base=BASE,version='v0.1.5',repository_tests=full,focused_tests=focused,
        source_hashes=source,frozen_input_hashes=frozen,diagnostic=result,plan=plan,preservation=preservation,
        review_mutations=mutants,param_mutation='PASS: one assertion failure, zero errors; baseline/restored PASS',
        old_archives_unchanged=prior,prior_attempt3_checkpoint=verify(attempt3/'evidence'),
        actual_provider_requests=4,no_neutral_check=True,no_thirty_episodes=True,no_merge=True,
        accounting=dict(step='0.018854925',openai='1.1516518999999985',booked='0.006370050',
            observed_usage='0.000011800',retained_error_reserves='0.006358250',markers_unchanged=True),
        local_namespace='Local kernel denies unshare; socket-denied suite; pushed-head namespace CI in PR',
        archive=dict(bytes=(out/'acceptance.zip').stat().st_size,members=len(members)+1,sha256=sha((out/'acceptance.zip').read_bytes())))
    with (out/'validation.json').open('x') as stream:json.dump(report,stream,indent=2);stream.write('\n')
    print(json.dumps({k:report[k] for k in ('status','repository_tests','focused_tests','accounting','archive')},indent=2))
if __name__=='__main__':main()
