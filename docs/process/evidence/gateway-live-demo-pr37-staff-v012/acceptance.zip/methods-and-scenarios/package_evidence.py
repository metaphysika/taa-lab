"""Close retained v0.1.2 offline evidence only after all local gates pass."""
from pathlib import Path
import hashlib,json,platform,re,subprocess,sys,zipfile
ROOT=Path('/workspace/taa-lab');sys.path.insert(0,str(ROOT))
from live_demo.config import verify as frozen_verify
from live_demo.evidence import verify
BASE='ad8fa76a76d01fa1d387ec64d3479e280dcef92c'
WORK=Path('/workspace/scratch/live-demo-staff-v012')
PREFIX='taa-live-demo-staff-v012-'
OUT=ROOT/'docs/process/evidence/gateway-live-demo-pr37-staff-v012'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def old(name):return subprocess.check_output(['git','show',BASE+':'+name],cwd=ROOT)
def suite(name):
 p=Path('/tmp')/(PREFIX+name+'-001.log');s=p.read_text()
 assert re.search(r'^OK(?: \(skipped=\d+\))?$',s,re.M), 'unclosed/failed suite: '+str(p)
 count=re.search(r'Ran (\d+) tests in ([\d.]+)s',s)
 skip=re.search(r'^OK \(skipped=(\d+)\)',s,re.M)
 return dict(tests=int(count[1]),seconds=float(count[2]),skipped=int(skip[1]) if skip else 0,sha256=sha(p.read_bytes()))
def main():
 full=suite('full');focused=suite('focused');assert focused['tests']==44
 source=json.loads((WORK/'final-source-hashes.json').read_bytes())
 assert all(sha((ROOT/n).read_bytes())==h for n,h in source.items())
 frozen=frozen_verify();previous_pins=json.loads(old('live_demo/frozen/hashes.json'))
 assert set(previous_pins)==set(frozen)
 assert [n for n in frozen if frozen[n]!=previous_pins[n]]==['live_demo/frozen/programs.json']
 previous=json.loads(old('live_demo/frozen/programs.json'))
 current=json.loads((ROOT/'live_demo/frozen/programs.json').read_bytes())
 staff={r['brief']['staff'] for r in current.values()};assert len(staff)==1
 for row in current.values():row['brief'].pop('staff')
 assert current==previous
 preservation=json.loads(Path('/tmp/'+PREFIX+'preservation-001.json').read_bytes());assert preservation['status']=='PASS'
 probes=json.loads(Path('/tmp/'+PREFIX+'standins-001.json').read_bytes());assert probes['status']=='PASS'
 folder=Path('/tmp/'+PREFIX+'standins-001')
 for p in folder.rglob('checkpoint.json'):verify(p.parent)
 mutations=json.loads(Path('/tmp/'+PREFIX+'mutations-001.json').read_bytes())
 assert mutations['status']=='PASS' and len(mutations['controls'])==4
 assert all(r['before']['passed'] and r['restored']['passed'] and r['mutant']['failures']==1 and r['mutant']['errors']==0 for r in mutations['controls'])
 scenarios=Path('/tmp/'+PREFIX+'scenarios-001.log').read_text();assert 'Saved to results/' in scenarios
 preserved={}
 for n in ('openai','claude','google','groq'):
  name='results/formation-spending-v021/'+n+'.json';raw=(ROOT/name).read_bytes();assert raw==old(name);preserved[name]=sha(raw)
 for directory in ('gateway-live-demo-v01','gateway-live-demo-pr37-review-v011'):
  for p in (ROOT/'docs/process/evidence'/directory).iterdir():
   if p.is_file():
    name=str(p.relative_to(ROOT));raw=p.read_bytes();assert raw==old(name);preserved[name]=sha(raw)
 files={}
 for p in folder.rglob('*'):
  if p.is_file():files['standins/'+str(p.relative_to(folder))]=p
 for p in Path('/tmp').glob(PREFIX+'*'):
  if p.is_file() and p.suffix in ('.log','.json'):files['logs-and-controls/'+p.name]=p
 for p in WORK.rglob('*'):
  if p.is_file():files['methods-and-scenarios/'+str(p.relative_to(WORK))]=p
 for n in source:files['final-source/'+n]=ROOT/n
 report=ROOT/'docs/process/TAA_LIVE_DEMO_PR37_STAFF_v012.md';files['report-at-validation.md']=report
 OUT.mkdir(parents=True,exist_ok=True)
 members={}
 with zipfile.ZipFile(OUT/'acceptance.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for name,p in sorted(files.items()):
   assert p.name!='keys.env'
   raw=p.read_bytes();members[name]=sha(raw);z.writestr(name,raw)
  z.writestr('MEMBER_SHA256.json',json.dumps(members,indent=2,sort_keys=True)+'\n')
 with zipfile.ZipFile(OUT/'acceptance.zip') as z:
  assert z.testzip() is None
  assert all(sha(z.read(n))==h for n,h in members.items())
 receipt=dict(status='PASS: offline only; no merge or launch',version='v0.1.2',base=BASE,python=platform.python_version(),
  staff_approval=dict(owner='Chris',date='2026-10-24',source='Chris relayed Claude review and explicit owner approval in this task'),
  exact_staff=next(iter(staff)),program_change='Only brief.staff added in each of ten programs; other values unchanged',
  repository_tests=full,focused_tests=focused,mutations=mutations,preservation=preservation,engineering_probes=probes,
  frozen_input_hashes=frozen,final_source_hashes=source,prior_ledgers_and_archives_unchanged=preserved,
  actual_model_or_real_neutral_calls=0,actual_api_dollars=0,
  namespace=dict(local='Kernel denies unshare --net: Operation not permitted',local_fallback='Outbound sockets denied',ci='Verify pushed-head sudo-unshare job separately in PR description'),
  archive=dict(path='acceptance.zip',bytes=(OUT/'acceptance.zip').stat().st_size,sha256=sha((OUT/'acceptance.zip').read_bytes()),members=len(members)+1))
 with (OUT/'validation.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
 print(json.dumps({k:receipt[k] for k in ('status','repository_tests','focused_tests','archive')},indent=2))
if __name__=='__main__':main()
