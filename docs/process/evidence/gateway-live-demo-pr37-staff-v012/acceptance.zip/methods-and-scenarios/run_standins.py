"""Retained offline engineering probes for the approved staff-only amendment."""
from pathlib import Path
import base64
import json
import socket
import sys
from unittest.mock import patch
ROOT=Path('/workspace/taa-lab');sys.path.insert(0,str(ROOT))
from live_demo.run import run,fault_probes
from live_demo.check import run as neutral
from live_demo.evidence import verify,encoded

def blocked(*args,**kwargs):raise AssertionError('outbound connection forbidden')
base=Path('/tmp/taa-live-demo-staff-v012-standins-001')
base.mkdir(exist_ok=False)
with patch.object(socket.socket,'connect',blocked),patch.object(socket.socket,'connect_ex',blocked):
    result=run(base/'run')
    assert result['stop']=='complete' and len(result['episodes'])==30
    stops=fault_probes(base/'stops')
    assert [(r['stop'],r['calls']) for r in stops]==[('partial_reply',1),('transport_exhaustion',5),('cap_stop',0)]
    check=neutral(base/'neutral')
    assert check['stop']=='complete' and check['requests']==2
chains={str(p.parent.relative_to(base)):verify(p.parent) for p in base.rglob('checkpoint.json')}
assert len(chains)==35
rows=[json.loads(p.read_bytes()) for p in sorted((base/'neutral').glob('[0-9]*.json'))]
requests=[r['value']['body'] for r in rows if r['kind']=='request']
first_native=next(json.loads(base64.b64decode(r['value']['base64'])) for r in rows if r['kind']=='native_reply')
reasoning=[r for r in first_native['output'] if r['type']=='reasoning']
carried=[r for r in requests[1]['input'] if r.get('type')=='reasoning']
assert encoded(reasoning)==encoded(carried) and reasoning[0]['encrypted_content'] and reasoning[0]['summary']
formats=[r['value'] for r in rows if r['kind']=='native_format']
assert len(formats)==2 and all(r['model_returned']==check['model_returned'] for r in formats)
summary=dict(status='PASS',mode='CANNED ENGINEERING ONLY',actual_api_dollars=0,
             standin=dict(stop=result['stop'],episodes=len(result['episodes']),per_arm=result['per_arm'],totals=result['totals']),
             faults=[dict(probe=r['probe'],stop=r['stop'],calls=r['calls']) for r in stops],
             neutral=dict(report=check,reasoning_replayed_unchanged=True,native_format=formats),chains=chains)
with Path('/tmp/taa-live-demo-staff-v012-standins-001.json').open('x') as f:json.dump(summary,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in summary.items() if k!='chains'},indent=2))
