"""Package completed offline validation without rerunning any scored episode."""
from pathlib import Path
import hashlib
import json
import platform
import re
import subprocess
import zipfile

ROOT=Path('/workspace/taa-lab')
import sys
sys.path.insert(0,str(ROOT))
from live_demo.evidence import verify

OUT=ROOT/'docs/process/evidence/gateway-live-demo-v01'
OUT.mkdir(parents=True,exist_ok=True)

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def suite(path):
    text=path.read_text()
    if not re.search(r'^OK(?: \(skipped=\d+\))?$',text,re.M):
        raise ValueError('suite not closed PASS: '+str(path))
    m=re.search(r'Ran (\d+) tests in ([\d.]+)s',text)
    skips=re.search(r'^OK \(skipped=(\d+)\)',text,re.M)
    return dict(tests=int(m[1]),seconds=float(m[2]),skips=int(skips[1]) if skips else 0,sha256=sha(path))

full=suite(Path('/tmp/taa-live-demo-full-004.log'))
focused=suite(Path('/tmp/taa-live-demo-tests-006.log'))
if focused['tests']!=24:raise ValueError('unexpected focused test count')
acceptance=json.loads(Path('/tmp/taa-live-demo-acceptance-001.json').read_bytes())
if not acceptance['gate_pass']:raise ValueError('normative acceptance not passed')
normative={}
for name,groups in acceptance['backends'].items():
    counts=[s['counts'] for s in groups.values()]
    normative[name]={k:sum(c[k] for c in counts) for k in ('scenarios','source','audits','discrepancies','incomplete')}
    if normative[name]['discrepancies'] or normative[name]['incomplete']:raise ValueError('normative failure')
source=json.loads(Path('/workspace/scratch/live-demo-v01/final-source-hashes.json').read_bytes())
for name,digest in source.items():
    if sha(ROOT/name)!=digest:raise ValueError('final code changed: '+name)
ledgers={}
for provider in ('openai','claude','google','groq'):
    name='results/formation-spending-v021/'+provider+'.json'
    original=subprocess.check_output(['git','show','436fbf00:'+name],cwd=ROOT)
    if original!=(ROOT/name).read_bytes():raise ValueError('real provider ledger changed')
    ledgers[name]=sha(ROOT/name)

final=Path('/tmp/taa-live-demo-final-002')
checkpoints={'run':verify(final)}
for folder in final.glob('episode-*'):checkpoints[folder.name]=verify(folder)
rows=[json.loads(p.read_bytes()) for p in final.glob('[0-9]*.json')]
summary=next(r['value'] for r in rows if r['kind']=='summary')
if summary['stop']!='complete' or len(summary['episodes'])!=30:raise ValueError('standin incomplete')
for folder in Path('/tmp/taa-live-demo-stops-002').iterdir():verify(folder)

files={}
for folder,prefix in [(Path('/tmp/taa-live-demo-build-002'),'development-standin-002'),
                      (Path('/tmp/taa-live-demo-final-001'),'pre-final-review-standin-001'),
                      (final,'final-standin-002'),
                      (Path('/tmp/taa-live-demo-stops-001'),'development-stops-001'),
                      (Path('/tmp/taa-live-demo-stops-002'),'final-stops-002'),
                      (Path('/workspace/scratch/live-demo-v01/scripted-scenarios-001'),'scripted-scenarios-001'),
                      (Path('/workspace/scratch/live-demo-v01/scripted-scenarios-002'),'scripted-scenarios-002')]:
    for path in folder.rglob('*'):
        if path.is_file():files[prefix+'/'+str(path.relative_to(folder))]=path
for path in Path('/tmp').glob('taa-live-demo-*.log'):files['logs/'+path.name]=path
for name in ('taa-live-demo-acceptance-001.json','taa-live-demo-preservation-001.json'):
    files['validation-inputs/'+name]=Path('/tmp')/name
for name in ('final-source-hashes.json','pre-review-source-hashes.json','package_evidence.py'):
    files['methods/'+name]=Path('/workspace/scratch/live-demo-v01')/name
for name in source:files['final-source/'+name]=ROOT/name
for path in (ROOT/'live_demo/frozen').iterdir():
    if path.is_file():files['final-source/live_demo/frozen/'+path.name]=path

inventory={}
with zipfile.ZipFile(OUT/'acceptance.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for name,path in sorted(files.items()):
        if path.name=='keys.env':raise ValueError('forbidden file')
        raw=path.read_bytes();inventory[name]=hashlib.sha256(raw).hexdigest()
        archive.writestr(name,raw)
    archive.writestr('MEMBER_SHA256.json',json.dumps(inventory,indent=2,sort_keys=True)+'\n')
receipt=dict(status='PASS: offline build validation; no launch approval',base='436fbf002d3e0f9e84a41206fe3c4c43b0d71ed7',
    python=platform.python_version(),repository_tests=full,focused_tests=focused,normative_acceptance=normative,
    scripted_scenarios='PASS; two retained free scripted runs; no scientific model run',
    final_source_hashes=source,provider_ledger_sha256_unchanged=ledgers,
    original_openai_estimated_dollars='1.1327969749999984',actual_model_requests=0,actual_new_api_dollars=0,
    standin=dict(episodes=30,mode='CANNED ENGINEERING FIXTURES; synthetic usage/cost only',
                 totals=summary['totals'],checkpoints=checkpoints),
    scored_v02_rerun=False,retained_v02_journal_sha256='4f96fa81efdb5362fa385ce5ab0a550f9faa7ddb1057e25c0432e049b653776a',
    protected_preservation=json.loads(Path('/tmp/taa-live-demo-preservation-001.json').read_bytes()),
    archive=dict(path='acceptance.zip',sha256=sha(OUT/'acceptance.zip'),bytes=(OUT/'acceptance.zip').stat().st_size,members=len(inventory)+1),
    diagnostics=['First command failed at import on missing parenthesis before episodes.',
      'Focused001 has two mistaken format-only assumptions; native outcomes and original diagnostics retained.',
      'Broad001 interrupted before final transport classification.',
      'Broad002 Python3.12 prefix has two documented historical source-spending float-sum errors; no archived arithmetic changed.',
      'Python3.11 preflight: all four historical v0220 controls PASS.',
      'Broad003 interrupted for final native-usage/tool-result logging review; all prior prefixes retained.',
      'Focused005: three final review controls PASS; final focused006 covers all24.'],
    limits=['No model/neutral/metadata call, Modal action, spending, keys.env access or launch.',
      'Native Responses compatibility and current price remain unprobed.',
      'Prompt reservation byte bound plus16K framing is a prospective assumption for review.',
      'Context delivery, immediate execution, termination,4096 and claimant completion definitions need Claude review.',
      'No automatic replacement/resume; exact-commit owner launch approval remains separate.'])
with (OUT/'validation.json').open('x') as stream:json.dump(receipt,stream,indent=2);stream.write('\n')
print(json.dumps(dict(repository_tests=full,focused_tests=focused,archive=receipt['archive']),indent=2))
