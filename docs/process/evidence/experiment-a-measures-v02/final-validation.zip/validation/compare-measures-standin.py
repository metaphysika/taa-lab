import json
from pathlib import Path
from zipfile import ZipFile
from live_demo.evidence import encoded
root=Path('/workspace/scratch/experiment-a-measures-v02-standin')
prior=Path('docs/process/evidence/experiment-a-provider-update-v012/acceptance.zip')
with ZipFile(prior) as z:
 old=[json.loads(z.read(n)) for n in sorted(z.namelist()) if n.startswith('raw/standin-396/') and n.count('/')==2 and n.rsplit('/',1)[-1][:6].isdigit() and n.endswith('.json')]
new=[json.loads(p.read_bytes()) for p in sorted(root.glob('*.json')) if p.stem.isdigit()]
old_requests=[r['value']['body'] for r in old if r['kind']=='request']
new_requests=[r['value']['body'] for r in new if r['kind']=='request']
assert [encoded(r) for r in old_requests]==[encoded(r) for r in new_requests]
old_rows=[r['value'] for r in old if r['kind']=='episode_summary']
new_rows=[r['value'] for r in new if r['kind']=='episode_summary']
assert len(old_rows)==len(new_rows)==396
for before,after in zip(old_rows,new_rows):
 m=after['metrics']
 for key in ('policy_over_refusal','execution_failure','oracle_assessment_complete'):
  m.pop(key)
 m['correct_reporting'].pop('counted_success')
 assert before==after
report=dict(status='PASS',episodes=396,byte_equal_request_bodies=len(old_requests),existing_episode_fields_equal=True,baseline=str(prior),new_raw_root=str(root),ignored_additive_fields=['policy_over_refusal','execution_failure','oracle_assessment_complete','correct_reporting.counted_success'],limitation='No calls in these stand-in replies; the real-host synthetic tests exercise the over-refusal split.')
Path('/workspace/scratch/measures-standin-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
