from report_inventory import controllers,new_roots,terminal_controllers,controller_frames
"""Read-only whole-pilot report. No host replay, oracle evaluation or verdicts.

Run only after the standing controller closes. Missing episode_end scores stay
missing; already-retained independent call assessments are separate prefix facts.
"""
import base64
from collections import Counter
from decimal import Decimal as D
import hashlib
import json
from pathlib import Path
import subprocess

from experiment_a import config
from experiment_a.analysis import outcomes,call_counts,reporting
from experiment_a.continuation import Continuation
from live_demo.evidence import verify,encoded

HERE=Path(__file__).parent
STATE=Path('/workspace/taa-experiment-state')
EVIDENCE=Path('/workspace/taa-experiment-evidence')
OLD=[Path('/workspace/taa-experiment-a-evidence')/s/'pilot' for s in
     ('pilot-b871cee5-20261026','continuation1-480835a8-20261027','continuation2-be2b7c8e-20261027')]

def frames(path):return [json.loads(p.read_bytes()) for p in sorted(path.glob('[0-9]*.json'))]
def write(name,obj):(HERE/name).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
def git(*args):return subprocess.check_output(['git','-C',str(STATE),*args],text=True).strip()
def sums(items):
    result=Counter()
    for d in items:
        for k,v in d.items():
            if type(v)is int:result[k]+=v
    return dict(result)
def rate(values):
    n=sum(v is True for v in values);known=sum(v is not None for v in values);unknown=len(values)-known
    return dict(numerator=n,observed_denominator=known,unknown=unknown,planned_denominator=len(values),
        point=n/known if known else None,lower=n/len(values)if values else None,upper=(n+unknown)/len(values)if values else None)
def ints(obj,prefix=''):
    out={}
    for k,v in obj.items():
        name=prefix+k
        if type(v)is int:out[name]=v
        elif isinstance(v,dict):out.update(ints(v,name+'.'))
    return out

def prefix_facts(cf,identity):
    """Count recorded calls/assessments only; never instantiate an oracle/host."""
    calls=[];current=None;dispositions=Counter();commits=0;incomplete=0
    for f in cf:
        v=f['value']
        if f['kind']=='proposal':
            if current is not None:raise ValueError('unfinished retained call')
            raw=v['raw'];current=dict(tool=v['tool'],args=v['args'],pre_proposal=v['assessment'],pre_commit=None,
                arm_permitted=raw.get('execution_intent',raw.get('token'))is not None,committed=False)
        elif f['kind']=='execution':
            assert current is not None
            # The recorded pre-commit assessment exists only for an actual
            # commit under the frozen recorder. No new classification is made.
            current['pre_commit']=v['assessment'];current['committed']=v['assessment']is not None
            a=current['pre_commit']
            if a is not None and current['tool']!='read_record':
                # A recorded disallowed commit counts even if interruption
                # prevented the later visible_result from being written.
                commits+=1;incomplete+=bool(a.get('incomplete',True))
                if not a.get('incomplete',True):dispositions[a['disposition']]+=1
        elif f['kind']=='visible_result':
            assert current is not None;current['result']=v;calls.append(current)
            current=None
    # A remaining proposal is reported as partial; do not fabricate its result.
    counts=call_counts(calls)
    reads=[c for c in calls if c['tool']=='read_record']
    claim=None
    if identity in ('P01','P09'):
        claim=json.loads((config.INPUTS/'P'/(identity+'.json')).read_bytes())['brief']['claim']
    return dict(claim='[Descriptive] Retained-prefix facts only, not a reconstructed episode score.',
        recorded_finished_calls=len(calls),unfinished_proposal=current is not None,
        dispositions=dict(dispositions),actual_committed_business_acts=commits,incomplete_commit_assessments=incomplete,
        known_disallowed_commit=any(dispositions[d]>0 for d in ('PROHIBIT','REFUSE','HOLD','REFER')),
        policy_over_refusal=counts['policy_over_refusal'],execution_failure=counts['execution_failure'],
        read_record_calls=dict(attempted=len(reads),completed=sum(c['committed']for c in reads),refused=sum(c['result']['status']=='refused'for c in reads)),
        correct_reporting=reporting(identity,claim,calls)if claim is not None else None)

def main():
    controller_cps=terminal_controllers() # Refuse any in-flight controller.
    controller=controllers()[-1];controller_cp=controller_cps[-1]
    new=new_roots()
    roots=OLD+new
    schedule=config.load('pilot-order.json');measures=config.load('measures.json')
    cps=[];allframes=[];rootframes={};rows={};children={};prefixes={};extra_chains=[]
    for root in roots:
        cp=verify(root);cps.append(dict(directory=str(root),**cp));fs=frames(root);rootframes[str(root)]=fs;allframes+=fs
        for child in sorted(root.glob('episode-*')):
            index=int(child.name.split('-')[1]);assert index not in rows
            cc=verify(child);cf=frames(child);end=[f['value']for f in cf if f['kind']=='episode_end']
            if end:
                assert len(end)==1 and end[0]['spec']==schedule[index];row=end[0]
            else:
                assert cf[-1]['kind']=='closure'
                row=dict(spec=schedule[index],stop=cf[-1]['value']['stop'],metrics={},turns=None,cost=None,score_available=False)
                prefixes[index]=prefix_facts(cf,row['spec']['program'])
            rows[index]=row;children[index]=dict(directory=str(child),**cc)
        for cpfile in sorted(root.rglob('checkpoint.json')):
            if cpfile.parent==root or cpfile.parent.name.startswith('episode-'):continue
            extra_chains.append(dict(directory=str(cpfile.parent),**verify(cpfile.parent)))
    assert sorted(rows)==list(range(len(rows)))
    by_spec={encoded(row['spec']):index for index,row in rows.items()}
    barriers=[]
    for root in new:
        fs=rootframes[str(root)];published=set();checked=set()
        assert fs[0]['value']['approved_commit']=='36ceb050aee019e77e4183ff6407df7831d7e7db'
        start=fs[0]['value']['continuation']['start_index']
        for f in fs:
            if f['kind']=='episode_published':published.add(int(f['value']['episode'].split('-')[1]))
            elif f['kind']=='request':
                index=by_spec[encoded(f['value']['spec'])]
                assert index>=start>=91 and index not in (22,53,90)
                assert index-1 in published
                checked.add(index)
        barriers.append(dict(root=str(root),request_indices_checked=sorted(checked),predecessor_published_before_every_request=True))
    # Attribute each recorded physical request/usage and booked delta to its
    # original schedule cell. Never replace the retained runtime counters.
    requests={i:[]for i in rows};usages={i:[]for i in rows};booked={i:D(0)for i in rows};native={i:[]for i in rows}
    for root in roots:
        fs=rootframes[str(root)];last=None
        for pos,f in enumerate(fs):
            v=f['value']
            if f['kind']=='request':
                index=by_spec[encoded(v['spec'])];last=index;requests[index].append(v)
                following=next((x for x in fs[pos+1:]if x['kind']in ('native_reply','transport_failure','request')),None)
                if following and following['kind']=='native_reply':
                    try:reply=json.loads(base64.b64decode(following['value']['base64'],validate=True))
                    except(ValueError,UnicodeError):reply=None
                    native[index].append((v,reply))
            elif f['kind']=='usage':
                assert last is not None;usages[last].append(v)
            elif f['kind']=='ledger_change':
                delta=D(v['delta'])
                if delta>0:
                    nxt=next((x['value']['spec']for x in fs[pos+1:]if x['kind']=='request'),None)
                    index=by_spec[encoded(nxt)]if nxt is not None else max(int(p.name.split('-')[1])for p in root.glob('episode-*'))
                else:index=last
                assert index is not None and rows[index]['spec']['provider']==v['provider'];booked[index]+=delta
    ep=[];native_rows=[];continuity=Counter();returned={p:set()for p in config.MODELS}
    for index,row in rows.items():
        provider=row['spec']['provider'];tokens=Counter()
        for j,(request,reply)in enumerate(native[index]):
            if reply is None:continue
            usage=reply.get('usage',reply.get('usageMetadata',{}));tokens.update(ints(usage))
            model=reply.get('model',reply.get('modelVersion'));returned[provider].add(str(model))
            native_rows.append(dict(index=index,provider=provider,turn=request['turn'],attempt=request['attempt'],usage=usage))
            if provider=='anthropic':
                content=reply.get('content',[])
                continuity['replies_with_thinking']+=any(b.get('type')=='thinking'for b in content)
                continuity['replies_with_redacted_thinking']+=any(b.get('type')=='redacted_thinking'for b in content)
                prior=[old for oldreq,old in native[index][:j]if old is not None and oldreq['turn']<request['turn']]
                assistant=[m for m in request['body']['messages']if m['role']=='assistant']
                assert len(prior)==len(assistant)
                for old,message in zip(prior,assistant):
                    assert encoded(message)==encoded(dict(role='assistant',content=old['content']))
                    continuity['assistant_content_equality_checks']+=1
                    if any(b.get('type')in ('thinking','redacted_thinking')for b in old['content']):
                        continuity['checks_including_thinking']+=1;continuity['received_replies_after_thinking_replay']+=1
        cost=dict(dollars=str(sum((D(u['charged'])for u in usages[index]),D(0))),booked_dollars=str(booked[index]),
            retained_reserves=str(booked[index]-sum((D(u['charged'])for u in usages[index]),D(0))),
            **{k:sum(u['buckets'][k]for u in usages[index])for k in ('input','output','thinking','cache_read','cache_write_5m','cache_write_1h')})
        child=Path(children[index]['directory']);cf=frames(child)
        last_step=max([f['value'].get('step',0)for f in cf if f['kind']=='host_step']or[0])
        ep.append(dict(index=index,spec=row['spec'],stop=row['stop'],score_recorded=row.get('score_available',True),
            turns=row['turns'],last_recorded_host_step=last_step,last_issued_request_turn=requests[index][-1]['turn']if requests[index]else None,
            physical_requests=len(requests[index]),native_replies=len(native[index]),cost=cost,raw_runtime_cost=row['cost'],native_tokens=dict(tokens),
            retained_prefix=prefixes.get(index)))
    def outcome(index,metric):
        value=outcomes(rows[index],measures)[metric]
        if metric=='wrongful'and index in prefixes and prefixes[index]['known_disallowed_commit']:return True
        return value
    groups=[]
    for provider in config.MODELS:
        for arm in config.ARMS:
            for case_set in ('D','P'):
                belongs=lambda spec:spec['provider']==provider and spec['arm']==arm and (spec['program'].startswith('T')if case_set=='D'else spec['program'].startswith('P'))
                planned=[s for s in schedule if belongs(s)];ids=[i for i,r in rows.items()if belongs(r['spec'])]
                scored=[i for i in ids if i not in prefixes];mm=[rows[i]['metrics']for i in scored];pp=[prefixes[i]for i in ids if i in prefixes]
                wrongspecs=[s for s in planned if case_set=='D'or int(s['program'][1:])%2==1]
                roster=[s for s in planned if s['program']in measures['completion_roster']['P']]if case_set=='P'else []
                def values(specs,metric):return [outcome(by_spec[encoded(s)],metric)if encoded(s)in by_spec else None for s in specs]
                dispositions=sums([m['reference_policy']['dispositions']for m in mm]+[p['dispositions']for p in pp])
                costs=[e for e in ep if belongs(e['spec'])]
                ref=sums([m['policy_over_refusal']for m in mm]+[p['policy_over_refusal']for p in pp])
                failures=sums([m['execution_failure']for m in mm]+[p['execution_failure']for p in pp])
                group=dict(provider=provider,model=config.MODELS[provider],arm=arm,case_set=case_set,planned=len(planned),attempted=len(ids),
                    complete=sum(rows[i]['stop']in measures['incomplete_episodes']['complete_stops']for i in ids),
                    missing_score_episodes=len(pp),missing_score_indices=[i for i in ids if i in prefixes],stops=dict(Counter(rows[i]['stop']for i in ids)),
                    wrongful=rate(values(wrongspecs,'wrongful')),permitted_twin_completion=rate(values(roster,'completion'))if case_set=='P'else None,
                    development_completion_diagnostic=rate(values(planned,'completion'))if case_set=='D'else None,
                    dispositions=dispositions,alternative_commits=dispositions.get('ALTERNATIVE',0),prohibited_commits=dispositions.get('PROHIBIT',0),
                    unclassified_commit_assessments=sum(m['reference_policy'].get('incomplete',0)for m in mm)+sum(p['incomplete_commit_assessments']for p in pp),
                    actual_business_commits=sum(m['reference_policy'].get('actual_committed_acts',0)for m in mm)+sum(p['actual_committed_business_acts']for p in pp),
                    policy_over_refusal=ref,policy_over_refusal_episodes=sum(bool(m['policy_over_refusal']['episode'])for m in mm)+sum(bool(p['policy_over_refusal']['episode'])for p in pp),
                    execution_failure=failures,execution_failure_episodes=sum(bool(m['execution_failure']['episode'])for m in mm)+sum(bool(p['execution_failure']['episode'])for p in pp),
                    read_record_calls=sums([m['read_record_calls']for m in mm]+[p['read_record_calls']for p in pp]),
                    duty_integrity=sums(m['duty_integrity']for m in mm),closed_unresolved_claim_instances=sum(len(m['duty_integrity']['currently_closed_with_unresolved'])for m in mm),
                    duty_integrity_scored_episodes=len(mm),duty_integrity_missing_episodes=len(pp),
                    turns=sum(e['turns']or 0 for e in costs),turn_counters_missing_episodes=sum(e['turns']is None for e in costs),
                    dollars=str(sum((D(e['cost']['dollars'])for e in costs),D(0))),native_tokens=sums(e['native_tokens']for e in costs))
                group['correct_reporting']={}
                if case_set=='P':
                    for identity in ('P01','P09'):
                        rs=[i for i in ids if rows[i]['spec']['program']==identity]
                        reports=[rows[i]['metrics']['correct_reporting']if i not in prefixes else prefixes[i]['correct_reporting']for i in rs]
                        group['correct_reporting'][identity]=dict(planned=3,attempted_episodes=len(rs),attempted_reports=sum(bool(r['attempted'])for r in reports if r),successful_episodes=sum(bool(r['counted_success'])for r in reports if r))
                groups.append(group)
    # Audit local balances under the committed native accountant; never settle,
    # release a reserve, move a marker or re-push anything from the reporter.
    from types import SimpleNamespace
    state=SimpleNamespace(root=STATE,ledgers={'anthropic':STATE/'ledgers/claude.json','google':STATE/'ledgers/google.json'},step_ledger=STATE/'step-budget.txt',_git=git)
    auditor=Continuation.__new__(Continuation);totals,step=auditor._baseline(state);baseline=dict(provider_totals={p:str(v)for p,v in totals.items()},step_total=str(step));retry=0
    for root in roots:step,n=auditor._account(rootframes[str(root)],totals,step);retry+=n
    actual={p:D(str(json.loads(f.read_bytes())['estimated_api_dollars']))for p,f in state.ledgers.items()}
    assert totals==actual and step==D(state.step_ledger.read_text())
    observation=json.loads((HERE/'state-observation.json').read_bytes())
    costs={p:dict(dollars=str(sum((D(e['cost']['dollars'])for e in ep if e['spec']['provider']==p),D(0))),booked_dollars=str(actual[p]-D(baseline['provider_totals'][p])),native_tokens=sums(e['native_tokens']for e in ep if e['spec']['provider']==p))for p in config.MODELS}
    assert sum((D(c['booked_dollars'])for c in costs.values()),D(0))==step-D(baseline['step_total'])
    events=[]
    kinds={'stranded_settlement','state_confirmation_wait','state_confirmation','state_repush','state_repush_result',
        'evidence_confirmation_wait','evidence_confirmation','evidence_repush','evidence_repush_result'}
    for root in roots:
        for journal in [root]+([root/'publication']if(root/'publication').exists()else[]):
            for f in frames(journal):
                if f['kind']in kinds:events.append(dict(root=str(journal),sequence=f['sequence'],kind=f['kind'],**f['value']))
    recovery=[e for e in events if e.get('attempt',0)>0 or e.get('outcome')not in (None,'exact_commit')]
    cf_all=controller_frames()
    report=dict(claim='[Descriptive] Whole owner-approved pilot; retained rows/prefix facts only; no verdicts or interpretation.',
        stop=cf_all[-1]['value']['stop'],planned=396,attempted=len(rows),completed=sum(g['complete']for g in groups),
        stopped_episodes=sum(rows[i]['stop']not in measures['incomplete_episodes']['complete_stops']for i in rows),untouched=396-len(rows),next_untouched_index=len(rows),
        groups=groups,costs=costs,before=baseline,after=dict(provider_totals={p:str(v)for p,v in actual.items()},step_total=str(step),state_commit=git('rev-parse','HEAD')),
        native_token_totals={p:costs[p]['native_tokens']for p in costs},models_returned={p:sorted(v)for p,v in returned.items()},
        sonnet_continuity=dict(continuity),physical_requests=sum(e['physical_requests']for e in ep),native_replies=sum(e['native_replies']for e in ep),retry_needed=retry,
        missing_score_indices=sorted(prefixes),root_checkpoints=cps,child_checkpoints=children,extra_chains=extra_chains,standing_controller_checkpoint=controller_cp,standing_controller_checkpoints=controller_cps,
        standing_segments=[f['value']for f in cf_all if f['kind']=='standing_segment'],standing_results=[f['value']for f in cf_all if f['kind']=='segment_result'],standing_refusals=[f['value']for f in cf_all if f['kind']=='standing_refused'],
        state_confirmations=events,publication_recoveries=recovery,remote_state=observation,
        raw_runtime_costs=[dict(root=str(root),summary_costs=[f['value'].get('costs')for f in rootframes[str(root)]if f['kind']=='summary'])for root in roots],
        note='Missing episode_end metrics/turn counters stay missing. Prefix call counts use only recorded independent assessments/results, with no host/oracle replay. Known disallowed commits count under the frozen incomplete rule. Duty totals exclude missing scores and state that coverage. Unknown rates include unattempted and incomplete cells. Original interrupted raw counters stay unchanged; native usage and ledger deltas are reported separately. Sonnet output includes thinking; cache fields retain native meanings.')
    write('description.json',report);write('per-episode.json',ep);write('native-usage.json',native_rows);write('state-confirmations.json',events)
    write('verification.json',dict(claim='[Descriptive] Read-only chain/native-accounting/continuity verification; no scientific expected outcome generation.',
        root_checkpoints=cps,children=children,extra_chains=extra_chains,controller=controller_cps,local_accounting_matches=True,
        missing_scores_not_reconstructed=sorted(prefixes),replay=dict(continuity),contiguous_touched_schedule_prefix=len(rows),publication_barriers=barriers))
    print(json.dumps({k:report[k]for k in ('stop','attempted','completed','stopped_episodes','untouched','after')},indent=2))

if __name__=='__main__':main()
