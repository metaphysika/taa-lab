from report_inventory import controllers,new_roots,terminal_controllers,controller_frames
"""Read-only retrospective checks for every taken/refused standing segment."""
import json
from pathlib import Path
from types import SimpleNamespace
from decimal import Decimal as D
import subprocess

from experiment_a.continuation import Continuation,marker_name
from experiment_a.standing import binding,successor
from live_demo.evidence import verify
from live_demo.adapter import Stop

HERE=Path(__file__).parent;STATE=Path('/workspace/taa-experiment-state')
OLD=[Path('/workspace/taa-experiment-a-evidence')/s/'pilot'for s in ('pilot-b871cee5-20261026','continuation1-480835a8-20261027','continuation2-be2b7c8e-20261027')]
def frames(root):return [json.loads(p.read_bytes())for p in sorted(root.glob('[0-9]*.json'))]
def git(*args):return subprocess.check_output(['git','-C',str(STATE),*args],text=True).strip()
def ancestor(a,b):return subprocess.run(['git','-C',str(STATE),'merge-base','--is-ancestor',a,b],capture_output=True).returncode==0

def main():
    controller_cps=terminal_controllers();controller=controllers()[-1]
    fs=controller_frames();segments=[f['value']for f in fs if f['kind']=='standing_segment']
    results=[f['value']for f in fs if f['kind']=='segment_result']
    observation=json.loads((HERE/'state-observation.json').read_bytes())
    published=observation['published_state_commit']
    state=SimpleNamespace(root=STATE,ledgers={'anthropic':STATE/'ledgers/claude.json','google':STATE/'ledgers/google.json'},step_ledger=STATE/'step-budget.txt',_git=git)
    auditor=Continuation.__new__(Continuation);audit=[];prior=list(OLD);previous=None
    for at,entry in enumerate(segments):
        a=entry['approval'];authority=binding(a);number=a['continuation'];root=Path(entry['output']);name=marker_name(number)
        record=dict(continuation=number,segment=authority['segment'],automatic=authority['segment']>1,receipt_sha256=authority['receipt_sha256'],
            marker=name,marker_exists=(STATE/name).exists(),root_exists=root.exists(),stop=frames(root)[-1]['value']['stop'] if root.exists() else fs[-1]['value']['stop'])
        try:
            cps=[]
            for source in prior:
                cps.append(verify(source)['head'])
                for cp in source.rglob('checkpoint.json'):verify(cp.parent)
            record['prior_chains_verified']=cps==a['source_checkpoints']
        except(OSError,ValueError,KeyError,TypeError):record['prior_chains_verified']=False
        try:
            totals,step=auditor._baseline(state)
            for source in prior:step,_=auditor._account(frames(source),totals,step,require_settled=True)
            record['no_open_pilot_reservation']=True
        except(OSError,ValueError,KeyError,TypeError):record['no_open_pilot_reservation']=False;totals=None;step=None
        if record['marker_exists']:
            m=json.loads((STATE/name).read_bytes());record['marker_receipt_binding']=(m.get('standing_receipt_sha256')==authority['receipt_sha256']and m.get('standing_segment')==authority['segment']and m.get('approved_commit')==a['commit']and m.get('used')is True)
            commits=git('log','--diff-filter=A','--format=%H','--',name).splitlines();assert len(commits)<=1
            claim=commits[0]if commits else None;record['claim_commit']=claim
            record['claim_published']=ancestor(claim,published)if claim and published else None
            if claim and totals is not None:
                actual={p:D(str(json.loads(git('show',claim+':'+str(f.relative_to(STATE))))['estimated_api_dollars']))for p,f in state.ledgers.items()}
                record['claim_accounting_matches']=actual==totals and D(git('show',claim+':step-budget.txt'))==step
            else:record['claim_accounting_matches']=False
        else:
            record.update(claim_commit=None,claim_published=False,marker_receipt_binding=None,claim_accounting_matches=None)
        record['same_approved_commit']=a['commit']=='36ceb050aee019e77e4183ff6407df7831d7e7db'
        record['within_original_allowance']=1<=authority['segment']<=a['standing']['max_continuations']<=3
        if previous is None:
            record['original_receipt_matches']=a==json.loads((HERE/'approval.json').read_bytes())
            record['allowed_predecessor_stop']=True # Explicit initial approval.
        else:
            record['allowed_predecessor_stop']=frames(prior[-1])[-1]['value']['stop']in a['standing']['allowed_stop_reasons']
            try:record['derived_receipt_matches']=successor(previous,prior)==a
            except(Stop,OSError,ValueError,KeyError,TypeError):record['derived_receipt_matches']=False
        if root.exists():
            indices=sorted(int(c.name.split('-')[1])for c in root.glob('episode-*'))
            expected=a['start_index'];record['first_touched_index']=indices[0]if indices else None
            record['untouched_cursor_respected']=not indices or indices==list(range(expected,expected+len(indices)))
            record['root_checkpoint']=verify(root)
            prior.append(root)
        audit.append(record);previous=a
    report=dict(claim='[Descriptive] Retained chains, native-accounting prefixes, published marker ancestry and receipt bindings; no provider request or state mutation.',segments=audit,
        refusals=[f['value']for f in fs if f['kind']=='standing_refused'],controller_checkpoints=controller_cps,original_receipt_max_segments=3)
    (HERE/'standing-audit.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
