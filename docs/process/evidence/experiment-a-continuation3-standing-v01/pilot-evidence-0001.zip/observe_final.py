from report_inventory import controllers,new_roots,terminal_controllers,controller_frames
"""Observe terminal Git balances/public evidence; no repair or provider calls."""
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import subprocess

from live_demo.evidence import verify

HERE=Path(__file__).parent;STATE=Path('/workspace/taa-experiment-state');EV=Path('/workspace/taa-experiment-evidence')
OLD=[Path('/workspace/taa-experiment-a-evidence')/s/'pilot'for s in ('pilot-b871cee5-20261026','continuation1-480835a8-20261027','continuation2-be2b7c8e-20261027')]
def git(*args,cwd=STATE):return subprocess.check_output(['git','-C',str(cwd),*args],text=True).strip()

def main():
    terminal_controllers() # Never fetch while the controller is active.
    refs=dict((line.split()[1].split('/')[-1],line.split()[0])for line in git('ls-remote','origin','refs/heads/experiment-state','refs/heads/experiment-a-evidence').splitlines())
    for branch in ('experiment-state','experiment-a-evidence'):
        if subprocess.run(['git','-C',str(STATE),'cat-file','-e',refs[branch]+'^{commit}'],capture_output=True).returncode:
            git('fetch','--no-tags','--no-write-fetch-head','origin','refs/heads/'+branch)
    sh=refs['experiment-state'];eh=refs['experiment-a-evidence']
    names={'anthropic':'ledgers/claude.json','google':'ledgers/google.json'}
    observation=dict(claim='[Descriptive] Terminal read-only observation; no branch, ledger, lease or marker repair.',observed_utc=datetime.now(timezone.utc).isoformat(),
        published_state_commit=sh,local_state_commit=git('rev-parse','HEAD'),
        published_provider_totals={p:str(json.loads(git('show',sh+':'+name))['estimated_api_dollars'])for p,name in names.items()},
        local_provider_totals={p:str(json.loads((STATE/name).read_bytes())['estimated_api_dollars'])for p,name in names.items()},
        published_step_total=git('show',sh+':step-budget.txt'),local_step_total=(STATE/'step-budget.txt').read_text().strip(),state_clean=not git('status','--porcelain','--untracked-files=all'),
        published_evidence_commit=eh,local_evidence_commit=git('rev-parse','HEAD',cwd=EV),evidence_clean=not git('status','--porcelain','--untracked-files=all',cwd=EV),
        active_lease_exists=(STATE/'active-run.json').exists(),continuation_claim_commits=git('log','--format=%H %s','--','continuation-*.once').splitlines(),
        markers={p.name:dict(sha256=hashlib.sha256(p.read_bytes()).hexdigest(),metadata=json.loads(p.read_bytes()))for p in sorted(STATE.glob('*.once'))})
    observation['published_local_balances_agree']=(observation['published_provider_totals']==observation['local_provider_totals']and observation['published_step_total']==observation['local_step_total'])
    # Verify all published blobs against retained source bytes without one Git
    # subprocess per frame. SHA1 here is Git's blob ID, not a replacement for
    # the evidence chain's SHA256.
    tree={}
    for line in git('ls-tree','-r',eh).splitlines():
        meta,name=line.split('\t',1);mode,kind,oid=meta.split()
        if kind=='blob':tree[name]=oid
    roots=OLD+new_roots()
    matched=0;missing=[];different=[]
    for root in roots:
        identity=hashlib.sha256(str(root).encode()).hexdigest();base='runs/'+identity+'/'
        files={base+'root/'+p.name:p for p in root.glob('*.json')}
        for child in root.glob('episode-*'):
            files.update({base+child.name+'/'+p.name:p for p in child.glob('*.json')})
        for name,path in files.items():
            b=path.read_bytes();oid=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
            if name not in tree:missing.append(name)
            elif tree[name]!=oid:different.append(name)
            else:matched+=1
    observation['public_evidence_coverage']=dict(matching_files=matched,missing_files=missing,different_files=different,
        all_retained_root_and_child_jsons_match=not missing and not different,
        note='Local final-publication diagnostics are separate chains retained in the report archive; they do not rewrite the sealed root.')
    (HERE/'state-observation.json').write_text(json.dumps(observation,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:v for k,v in observation.items()if k not in ('markers','public_evidence_coverage','continuation_claim_commits')},indent=2))

if __name__=='__main__':main()
