from report_inventory import controllers,new_roots,terminal_controllers,controller_frames
"""Freeze/scan retained new pilot evidence into GitHub-sized ZIP chunks."""
import ast
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import zipfile

from live_demo.evidence import verify

HERE=Path(__file__).parent
REPO=Path('/workspace/taa-lab')
DEST=REPO/'docs/process/evidence/experiment-a-continuation3-standing-v01'
LIMIT=48*1024*1024

def main():
    terminal_controllers()
    assert (HERE/'REPORT.md').exists()and (HERE/'verification.json').exists()
    assert not DEST.exists()
    assert not list(HERE.glob('pilot-evidence-*.zip')), 'keep earlier packaging attempts; choose a new archive prefix if needed'
    source=REPO/'studies/live-demo-03131469-review/scan_original_evidence.py'
    patterns=next(ast.literal_eval(n.value)for n in ast.parse(source.read_bytes()).body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='patterns'for t in n.targets))
    secrets=[v.encode()for k,v in os.environ.items()if v and any(w in k for w in ('API_KEY','TOKEN_SECRET','ACCESS_TOKEN'))]
    findings=[];decoded=0
    def allowed(name):
        assert Path(name).name!='keys.env'
        assert not re.search(r'(^|/)(?:H\d\d\.json|expected-key-H[^/]*\.md|[^/]*\.once)$',name)
    def scan(name,b):
        nonlocal decoded
        allowed(name)
        for label,pattern in patterns.items():
            if re.search(pattern,b):findings.append(dict(file=name,category=label))
        if any(secret in b for secret in secrets):findings.append(dict(file=name,category='configured_secret_match'))
        if name.endswith('.json'):
            try:r=json.loads(b)
            except(ValueError,UnicodeError):return
            if isinstance(r,dict)and r.get('kind')=='native_reply':
                decoded+=1;scan(name+'#decoded',base64.b64decode(r['value']['base64'],validate=True))
    excluded={'archive-manifest.json','credential-scan.json','project-publication-scan.json'}
    files=[p for p in sorted(HERE.rglob('*'))if p.is_file()and '__pycache__'not in p.parts and p.name not in excluded and not p.name.startswith('pilot-evidence-')]
    manifest={};groups=[];group=[];size=0
    for p in files:
        name=str(p.relative_to(HERE));allowed(name);assert not p.is_symlink()
        b=p.read_bytes();scan(name,b)
        manifest[name]=dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),mtime_ns=p.stat().st_mtime_ns)
        if group and size+len(b)>LIMIT:groups.append(group);group=[];size=0
        group.append(p);size+=len(b)
    if group:groups.append(group)
    assert not findings, 'credential scan matched; no copy/publication permitted'
    archives=[];members=0
    for number,group in enumerate(groups,1):
        archive=HERE/('pilot-evidence-%04d.zip'%number)
        with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
            for p in group:z.write(p,p.relative_to(HERE))
        assert archive.stat().st_size<90*1024*1024
        with zipfile.ZipFile(archive)as z:
            assert z.testzip()is None
            for name in z.namelist():
                allowed(name);b=z.read(name);members+=1
                assert hashlib.sha256(b).hexdigest()==manifest[name]['sha256'];scan(name,b)
        scan(archive.name,archive.read_bytes())
        archives.append(dict(file=archive.name,bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),members=len(group)))
    assert members==len(files)and not findings
    # Every original file must still match its pin after the archive pass.
    for name,entry in manifest.items():
        p=HERE/name;assert p.stat().st_mtime_ns==entry['mtime_ns']and hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256']
    record=dict(claim='[Descriptive] Exact retained new-root/standing/publication evidence and reporting files; prior roots stay in their preserved PR41 archives and public evidence branch.',archives=archives,source_files=manifest)
    (HERE/'archive-manifest.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    scan_record=dict(claim='[Descriptive] Same PR38 credential patterns, exact configured-secret comparisons, every retained source/archive member and decoded native reply. No values emitted.',files_scanned=len(files),archive_members_scanned=members,decoded_native_replies_scanned=decoded,findings=findings,no_H_material=True,no_keys_env_read=True,archives=archives)
    (HERE/'credential-scan.json').write_text(json.dumps(scan_record,indent=2,sort_keys=True)+'\n')
    for name in ('archive-manifest.json','credential-scan.json'):scan(name,(HERE/name).read_bytes())
    assert not findings
    DEST.mkdir(parents=True)
    names=['REPORT.md','description.json','per-episode.json','native-usage.json','state-confirmations.json',
           'standing-audit.json','state-observation.json','verification.json','backfill-verification.json',
           'before.json','approval.json','before-continuation4.json','backfill-continuation4-verification.json','outage-before.json','outage-verification.json','archive-manifest.json','credential-scan.json']
    for name in names+[a['file']for a in archives]:shutil.copy2(HERE/name,DEST/name)
    print(json.dumps(scan_record,indent=2))

if __name__=='__main__':main()
