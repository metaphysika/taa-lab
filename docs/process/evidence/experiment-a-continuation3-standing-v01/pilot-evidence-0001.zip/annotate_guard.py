"""Report-only distinction between a request record and actual provider dispatch."""
from pathlib import Path
from decimal import Decimal
import json
HERE=Path(__file__).parent
r=json.loads((HERE/'description.json').read_bytes())
e=json.loads((HERE/'per-episode.json').read_bytes())
fs=[json.loads(p.read_bytes())for p in sorted((HERE/'pilot-continuation-000004').glob('[0-9]*.json'))]
q=[f for f in fs if f['kind']=='request'][-1]
assert q['value']['spec']==dict(program='T03',arm='conventional',provider='google',repeat=1) and q['value']['turn']==1
assert not any(f['kind'] in ('native_reply','transport_failure') for f in fs if f['sequence']>q['sequence'])
assert r['stop']=='state_git_failure' and e[-1]['index']==149 and e[-1]['native_replies']==0
reserve=[f for f in fs if f['kind']=='reservation'][-1]['value']['dollars']
assert Decimal(reserve)==Decimal('0.266223')
assert sum(Decimal(c['booked_dollars'])-Decimal(c['dollars'])for c in r['costs'].values())==Decimal(reserve)
r['recorded_requests']=r['physical_requests']
r['retained_open_reservations']=[dict(index=149,provider='google',dollars=reserve,request_record_sequence=q['sequence'],request_turn=1,native_reply_recorded=False,stop='state_git_failure',http_dispatch_reached=False,source_basis='Approved adapter.respond writes request, then calls state.before_request before entering http. state_git_failure arises in that Git guard; the HTTP client does not raise that reason.')]
r['note']+=' The legacy physical_requests/last_issued_request_turn report fields count recorded intents. There are '+str(r['recorded_requests'])+' request records and '+str(r['native_replies'])+' native replies. The last request record at index149/turn1 is followed by state_git_failure in the final pre-HTTP Git guard, before transport dispatch; its $0.266223 reservation remains booked, not a native usage charge. No settlement or reserve release was performed by the reporter.'
(HERE/'description.json').write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(recorded_requests=r['recorded_requests'],native_replies=r['native_replies'],retained_open_reservations=r['retained_open_reservations'])))
