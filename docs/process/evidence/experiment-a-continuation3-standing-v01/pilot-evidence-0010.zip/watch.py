"""Read-only observer. Never starts, resumes, retries or stops an experiment."""
from datetime import datetime,timezone
from pathlib import Path
import json
import subprocess
import sys
import time
HERE=Path(__file__).parent
COMMIT='36ceb050aee019e77e4183ff6407df7831d7e7db'
while True:
    result=subprocess.run([sys.executable,str(HERE/'progress.py')],capture_output=True,text=True)
    if result.returncode:
        print(json.dumps(dict(status='observer_read_failed',returncode=result.returncode)),flush=True)
        break
    value=json.loads(result.stdout)
    value['observed_utc']=datetime.now(timezone.utc).isoformat()
    ps=subprocess.run(['ps','-C','python','-o','pid=,args='],capture_output=True,text=True)
    runners=[]
    for line in ps.stdout.splitlines():
        fields=line.split()
        if '-m' in fields and 'experiment_a.run'in fields and COMMIT in fields:
            runners.append(int(fields[0]))
    value['runner_pids']=runners
    value['controller_closed']=(HERE/'pilot-standing/checkpoint.json').exists()
    value['status']='controller_closed'if value['controller_closed']else 'running'if runners else 'runner_not_seen'
    with(HERE/'observer-progress.jsonl').open('a')as stream:
        stream.write(json.dumps(value,sort_keys=True)+'\n');stream.flush()
    print(json.dumps(value),flush=True)
    if value['status']!='running':break
    time.sleep(50)
