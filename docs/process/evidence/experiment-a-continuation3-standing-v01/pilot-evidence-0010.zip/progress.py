"""Streaming read-only progress; no transport, scoring or state mutation."""
from pathlib import Path
from collections import Counter
from decimal import Decimal
import json
HERE=Path(__file__).parent
segments=[];totals={p:Decimal(0)for p in ('anthropic','google')};delayed=0;repush=Counter();failures=0
for root in sorted(p for p in HERE.glob('pilot*')if p.is_dir()and not p.name.endswith('-standing')):
 complete=requests=published=0;backfill=set();current=None;stop=None
 for path in sorted(root.glob('[0-9]*.json')):
  try:f=json.loads(path.read_bytes())
  except(ValueError,OSError):continue
  kind=f['kind'];v=f['value']
  if kind=='episode_summary':complete+=1
  elif kind=='request':requests+=1;current=dict(spec=v['spec'],turn=v['turn'],attempt=v['attempt'])
  elif kind=='closure':stop=v.get('stop')
  elif kind=='episode_published':
   published+=1
   if int(v['episode'].split('-')[1])<91:backfill.add(v['episode'])
  elif kind=='usage':totals[v['provider']]+=Decimal(v['charged'])
  elif kind in ('state_confirmation','evidence_confirmation'):delayed+=v.get('attempt',0)>0
  elif kind in ('state_repush','evidence_repush'):repush[kind]+=1
  elif kind=='transport_failure':failures+=1
 segments.append(dict(root=root.name,complete=complete,requests=requests,current=current,closed=(root/'checkpoint.json').exists(),stop=stop,backfilled_episodes=len(backfill),published_episode_events=published))
print(json.dumps(dict(segments=segments,completed_new=sum(s['complete']for s in segments),physical_requests=sum(s['requests']for s in segments),usage_backed_new_dollars={p:str(v)for p,v in totals.items()},delayed_confirmations=delayed,repushes=dict(repush),transport_failures=failures)))
