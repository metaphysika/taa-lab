"""Report-only inventory of closed segments/controllers; no experiment mutations."""
from pathlib import Path
import json
from live_demo.evidence import verify
HERE=Path(__file__).parent
def controllers():
    return sorted((p for p in HERE.glob('pilot*-standing') if p.is_dir()),key=lambda p:json.loads((p/'000000.json').read_bytes())['value']['approval']['continuation'])
def new_roots():
    return sorted((p for p in HERE.glob('pilot*') if p.is_dir() and not p.name.endswith('-standing')),key=lambda p:json.loads((p/'000000.json').read_bytes())['value']['continuation']['number'])
def terminal_controllers():
    cs=controllers()
    assert cs
    return [dict(directory=str(p),**verify(p)) for p in cs]
def controller_frames():
    return [json.loads(p.read_bytes()) for c in controllers() for p in sorted(c.glob('[0-9]*.json'))]
