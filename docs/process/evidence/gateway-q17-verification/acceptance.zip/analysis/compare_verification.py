"""Compare every retained score cell; stop rather than repair a changed outcome."""
from pathlib import Path
import argparse,json,hashlib

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('before',type=Path);p.add_argument('after',type=Path)
a=p.parse_args()
def load(path):
    with path.open() as f:
        # Keep every compared field; release bulky audit/transition channels per episode.
        return [{k:e[k] for k in ('case','arm','controller','metrics','reference_policy_committed_acts','discrepancies','incomplete','final_world','oracle_board')} for e in (json.loads(line) for line in f)]
before=load(a.before/'episodes.jsonl');after=load(a.after/'episodes.jsonl')
identity=lambda e:(e['case'],e['arm'],e['controller'])
previous={identity(e):e for e in before};current={identity(e):e for e in after}
assert len(before)==len(after)==len(previous)==len(current)==320
assert previous.keys()==current.keys()
arms=sorted({e['arm'] for e in after});controllers=sorted({e['controller'] for e in after})
metrics=sorted(after[0]['metrics'])
def aggregate(es):
    return {key:sum(e['metrics'][key] for e in es) if type(es[0]['metrics'][key]) is int else
            {e['case']+'/'+e['controller']:e['metrics'][key] for e in es} for key in metrics}
def supplementary(es):
    values=[e['reference_policy_committed_acts'] for e in es]
    return dict(actual_committed_acts=sum(v['actual_committed_acts'] for v in values),
                counted_commits=sum(v['counted_commits'] for v in values),incomplete=sum(v['incomplete'] for v in values),
                dispositions={d:sum(v['dispositions'][d] for v in values) for d in values[0]['dispositions']})
rows=[];supp=[]
for arm in arms:
    for controller in [None,*controllers]:
        subset=lambda es:[e for e in es if e['arm']==arm and (controller is None or e['controller']==controller)]
        b,n=aggregate(subset(before)),aggregate(subset(after))
        for key in metrics:rows.append(dict(arm=arm,controller=controller,metric=key,before=b[key],after=n[key],changed=b[key]!=n[key]))
        b,n=supplementary(subset(before)),supplementary(subset(after))
        supp.append(dict(arm=arm,controller=controller,before=b,after=n,changed=b!=n))
episode_changes=[]
for key,e in current.items():
    old=previous[key]
    changed=[k for k in ('metrics','reference_policy_committed_acts','discrepancies','incomplete') if e[k]!=old[k]]
    if changed:episode_changes.append(dict(case=key[0],arm=key[1],controller=key[2],changed=changed))
report=dict(episodes=320,protocol_cells=rows,supplementary_cells=supp,episode_score_changes=episode_changes,
            changed_protocol_cells=sum(r['changed'] for r in rows),changed_supplementary_groups=sum(r['changed'] for r in supp),
            final_worlds_identical=all(e['final_world']==previous[k]['final_world'] for k,e in current.items()),
            oracle_boards_identical=all(e['oracle_board']==previous[k]['oracle_board'] for k,e in current.items()),
            before_journal_sha256=hashlib.sha256((a.before/'episodes.jsonl').read_bytes()).hexdigest(),
            after_journal_sha256=hashlib.sha256((a.after/'episodes.jsonl').read_bytes()).hexdigest())
target=a.after/'q17-metric-verification.json';assert not target.exists()
target.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('protocol_cells','supplementary_cells','episode_score_changes')},indent=2))
if report['changed_protocol_cells'] or report['changed_supplementary_groups'] or episode_changes:
    raise SystemExit('Score changed: stop and report to Claude. No outcome repair or additional run.')
