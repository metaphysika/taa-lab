"""Read-only current pilot status; no provider transport or state mutation."""
import json
from pathlib import Path
from collections import Counter
from decimal import Decimal
p=Path(__file__).parent/'pilot'
fs=[json.loads(f.read_bytes()) for f in sorted(p.glob('[0-9]*.json'))]
rows=[f['value'] for f in fs if f['kind']=='episode_summary']
req=[f['value'] for f in fs if f['kind']=='request']
print(json.dumps(dict(completed=len(rows),by_provider=dict(Counter(r['spec']['provider'] for r in rows)),
    by_arm=dict(Counter(r['spec']['arm'] for r in rows)),requests=len(req),
    current=req[-1]['spec'] if req else None,turn=req[-1]['turn'] if req else None,
    attempt=req[-1]['attempt'] if req else None,
    failures=[f['value']['status'] for f in fs if f['kind']=='transport_failure'],
    closed=(p/'checkpoint.json').exists(), confirmations=[f['value'] for f in fs if f['kind']=='state_confirmation'],
    settled_dollars={provider:str(sum((Decimal(f['value']['charged']) for f in fs if f['kind']=='usage' and f['value']['provider']==provider),Decimal(0))) for provider in ('anthropic','google')})))
