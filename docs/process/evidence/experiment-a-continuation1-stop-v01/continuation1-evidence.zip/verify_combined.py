"""Read-only completed evidence audit; no launch, transport, scorer or verdict calls."""
from decimal import Decimal as D
import hashlib,json,subprocess
from pathlib import Path
from experiment_a import config
from experiment_a.continuation import Continuation,frames
from experiment_a.state import State
from live_demo.evidence import verify,encoded
p=Path(__file__).parent
roots=[Path('/workspace/taa-experiment-a-evidence/pilot-b871cee5-20261026/pilot'),p/'pilot']
a=json.loads((p/'approval.json').read_bytes());plan=Continuation([roots[0]],a)
# Use only the read-only Git accessor/accounting helpers, not State acquisition
# or require_current: local and published tips intentionally differ after stop.
s=object.__new__(State);s.root=Path('/workspace/taa-experiment-state');s.ledgers={n:s.root/f for n,f in [('anthropic','ledgers/claude.json'),('google','ledgers/google.json')]};s.step_ledger=s.root/'step-budget.txt'
totals,step=plan._baseline(s);cursor=0;checks=[];heads=[];retries=0;allrows=[]
for root in roots:
 fs,cp=frames(root);rows=plan._segment(root,fs,cursor,heads)
 step,n=plan._account(fs,totals,step);retries+=n
 assert next(f['value']['retry_needed'] for f in fs if f['kind']=='summary')==retries
 checks.append({'directory':str(root),'checkpoint':cp,'rows':len(rows),'children':[{'index':i,'checkpoint':verify(root/('episode-%04d'%i))} for i in range(cursor,cursor+len(rows))]})
 allrows+=rows;cursor+=len(rows);heads.append(cp['head'])
assert cursor==54 and allrows[22]['stop']==allrows[53]['stop']=='state_publication_failed'
assert allrows[22]['spec']==dict(arm='taa',program='P10',provider='anthropic',repeat=1)
assert allrows[53]['spec']==dict(arm='conventional',program='P06',provider='google',repeat=3)
assert [r['spec'] for r in allrows]==config.schedule()[:54]
actual={n:D(json.loads(f.read_bytes())['estimated_api_dollars']) for n,f in s.ledgers.items()}
assert actual==totals and D(s.step_ledger.read_text())==step
before=json.loads((p/'before.json').read_bytes());obs=json.loads((p/'state-observation.json').read_bytes())
assert hashlib.sha256((s.root/'run.once').read_bytes()).hexdigest()==before['file_hashes']['run.once']
assert not (s.root/'continuation-000002.once').exists()
assert (s.root/'continuation-000001.once').is_file() and (s.root/'active-run.json').is_file()
assert D(obs['remote']['step-budget.txt'])-step==D('0.228354')
assert D(obs['remote']['ledgers/google.json'])-totals['google']==D('0.228354')
assert D(obs['remote']['ledgers/claude.json'])==totals['anthropic']
r=json.loads((p/'description.json').read_bytes())
assert len(r['child_checkpoints'])==54 and r['completed']==52 and r['physical_requests']==r['native_replies']==326
assert sum(e['turns'] for e in json.loads((p/'per-episode.json').read_bytes()))==326
assert all(g['prohibited_commits']==g['alternative_commits']==0 for g in r['groups'])
assert r['state_confirmations']==[dict(kind='state_confirmation_wait',attempt=1,commit=obs['local_commit'],delay_seconds=10),dict(kind='state_confirmation',attempt=1,commit=obs['local_commit'],delay_seconds=10,outcome='different_tip')]
runroot=Path('/workspace/taa-experiment-a-continuation-480835a8')
assert subprocess.check_output(['git','-C',str(runroot),'rev-parse','HEAD'],text=True).strip()==a['commit']
assert not subprocess.check_output(['git','-C',str(runroot),'status','--porcelain']).strip()
assert not subprocess.check_output(['git','-C',str(runroot),'branch','--show-current']).strip()
record={'claim':'[Descriptive] Read-only provenance/native-accounting audit; no rescore or model request.','roots':checks,'next_untouched_index':cursor,'remaining_untouched':396-cursor,'completed':52,'stopped':2,'native_requests_and_replies':326,'retry_needed':retries,'local_settled_totals':{k:str(v) for k,v in totals.items()},'local_step':str(step),'published_extra_reserve':'0.228354','original_stopped_episode_unchanged':True,'original_run_marker_unchanged':True,'continuation1_used':True,'continuation2_absent':True,'retained_active_lease':True,'approved_checkout_clean_detached':True,'input_pins':config.verify(),'H_accessed':False,'verdicts_computed':False}
(p/'verification.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in record.items() if k not in ('roots','input_pins')},indent=2))
