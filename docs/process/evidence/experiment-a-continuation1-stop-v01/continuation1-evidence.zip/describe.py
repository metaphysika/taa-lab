"""Read-only pilot description; never calls analyze(), bootstrap(), or verdict()."""
import base64
from collections import Counter
from decimal import Decimal as D
import json
from pathlib import Path
import subprocess

from live_demo.evidence import verify, encoded
from experiment_a import config
from experiment_a.analysis import outcomes

HERE = Path(__file__).parent
ROOT = HERE / 'pilot'
ORIGINAL = Path('/workspace/taa-experiment-a-evidence/pilot-b871cee5-20261026/pilot')
SOURCES = (ORIGINAL, ROOT)
STATE = Path('/workspace/taa-experiment-state')

def frames(path):
    return [json.loads(p.read_bytes()) for p in sorted(path.glob('[0-9]*.json'))]

def write(name, value):
    (HERE/name).write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')

def rate(values):
    yes = sum(v is True for v in values)
    known = sum(v is not None for v in values)
    unknown = len(values)-known
    return dict(numerator=yes, observed_denominator=known, unknown=unknown,
                planned_denominator=len(values), point=None if not known else yes/known,
                lower=None if not values else yes/len(values),
                upper=None if not values else (yes+unknown)/len(values))

def total_dict(items):
    c=Counter()
    for item in items:
        for k,v in item.items():
            if type(v) is int: c[k]+=v
    return dict(c)

def main():
    checkpoints=[dict(directory=str(root),**verify(root)) for root in SOURCES]
    checkpoint=checkpoints[-1]
    fs=[f for root in SOURCES for f in frames(root)]
    summaries=[[f['value'] for f in frames(root) if f['kind']=='summary'] for root in SOURCES]
    assert all(len(s)==1 for s in summaries)
    summary=summaries[-1][0]
    rows=[row for ss in summaries for row in ss[0]['episodes']]
    schedule=config.load('pilot-order.json')
    measures=config.load('measures.json')
    assert [r['spec'] for r in rows]==schedule[:len(rows)]
    by_spec={encoded(r['spec']):r for r in rows}
    usages_by_spec={}
    last_request=None
    for f in fs:
        if f['kind']=='request': last_request=f['value']
        elif f['kind']=='usage':
            assert last_request is not None
            assert f['value']['provider']==last_request['provider']
            usages_by_spec.setdefault(encoded(last_request['spec']),[]).append(f['value'])
    assert sum(len(v) for v in usages_by_spec.values())==sum(f['kind']=='request' for f in fs)
    closed=[]; episode_costs=[]; thinking_replies=0; redacted_replies=0
    replay_checks=0; replay_with_thinking=0; replay_accepted=0
    native_totals={p:Counter() for p in config.MODELS}
    native_usage_rows=[]; models={p:set() for p in config.MODELS}
    for index,row in enumerate(rows):
        child=(ORIGINAL if index<23 else ROOT)/('episode-%04d'%index)
        closed.append(dict(episode=index,checkpoint=verify(child)))
        cf=frames(child)
        end=[f['value'] for f in cf if f['kind']=='episode_end']
        assert end==[row]
        # Requests/usages belong to root accounting, linked to child by spec.
        rf=[f for f in fs if f['kind']=='request' and f['value']['spec']==row['spec']]
        native=[]
        for f in rf:
            pos=next(i for i,x in enumerate(fs) if x is f)
            suffix=fs[pos+1:]
            reply=next((x for x in suffix if x['kind'] in ('native_reply','transport_failure','request')),None)
            if reply and reply['kind']=='native_reply':
                raw=json.loads(base64.b64decode(reply['value']['base64']))
                native.append((f['value'],raw))
        p=row['spec']['provider']; tokens=Counter()
        for request,reply in native:
            model=reply.get('model',reply.get('modelVersion'))
            models[p].add(model)
            u=reply.get('usage',reply.get('usageMetadata'))
            native_usage_rows.append(dict(episode=index,provider=p,turn=request['turn'],attempt=request['attempt'],usage=u))
            if p=='anthropic':
                for k in ('input_tokens','output_tokens','cache_read_input_tokens','cache_creation_input_tokens'):
                    tokens[k]+=u.get(k,0)
                for k,v in u.get('cache_creation',{}).items(): tokens[k]+=v
                for k,v in u.get('output_tokens_details',{}).items():
                    if type(v) is int: tokens['output_tokens_details.'+k]+=v
                thinking_replies+=any(b['type']=='thinking' for b in reply['content'])
                redacted_replies+=any(b['type']=='redacted_thinking' for b in reply['content'])
            else:
                for k,v in u.items():
                    if type(v) is int: tokens[k]+=v
        if p=='anthropic':
            for j,(request,reply) in enumerate(native):
                previous=[old for old_request,old in native[:j] if old_request['turn']<request['turn']]
                assistant=[m for m in request['body']['messages'] if m['role']=='assistant']
                assert len(assistant)==len(previous)
                for prior,message in zip(previous,assistant):
                    assert encoded(message)==encoded(dict(role='assistant',content=prior['content']))
                    replay_checks+=1
                    if any(b['type'] in ('thinking','redacted_thinking') for b in prior['content']):
                        replay_with_thinking+=1
                        replay_accepted+=1 # this request has a received native reply
        native_totals[p].update(tokens)
        usages=usages_by_spec.get(encoded(row['spec']),[])
        usage_backed=dict(dollars=str(sum((D(u['charged']) for u in usages),D(0))),attempts=len(rf),
                          **{k:sum(u['buckets'][k] for u in usages) for k in ('input','output','thinking','cache_read','cache_write_5m','cache_write_1h')})
        episode_costs.append(dict(index=index,spec=row['spec'],stop=row['stop'],turns=row['turns'],
                                  cost=usage_backed,raw_runtime_cost=row['cost'],native_tokens=dict(tokens),replies=len(native)))
    groups=[]
    for p in config.MODELS:
        for arm in config.ARMS:
            for case_set in ('D','P'):
                belongs=lambda spec: spec['provider']==p and spec['arm']==arm and (spec['program'].startswith('T') if case_set=='D' else spec['program'].startswith('P'))
                planned=[s for s in schedule if belongs(s)]
                rr=[r for r in rows if belongs(r['spec'])]
                # P wrongfulness uses frozen odd twins; D has no twin split.
                wrong_specs=[s for s in planned if case_set=='D' or int(s['program'][1:])%2==1]
                wrong=[outcomes(by_spec[encoded(s)],measures)['wrongful'] if encoded(s) in by_spec else None for s in wrong_specs]
                completion_specs=[s for s in planned if s['program'] in measures['completion_roster']['P']] if case_set=='P' else []
                completion=[outcomes(by_spec[encoded(s)],measures)['completion'] if encoded(s) in by_spec else None for s in completion_specs]
                mm=[r['metrics'] for r in rr]
                lawful_mm=[r['metrics'] for r in rr if r['spec']['program'] in measures['completion_roster']['P']]
                group=dict(provider=p,model=config.MODELS[p],arm=arm,case_set=case_set,planned=len(planned),attempted=len(rr),
                    complete=sum(r['stop'] in measures['incomplete_episodes']['complete_stops'] for r in rr),
                    stops=dict(Counter(r['stop'] for r in rr)),wrongful=rate(wrong),
                    wrongful_population='all development programs' if case_set=='D' else 'P01/P03/P05/P07/P09/P11',
                    dispositions=total_dict(m['reference_policy']['dispositions'] for m in mm),
                    alternative_commits=sum(m['reference_policy']['dispositions'].get('ALTERNATIVE',0) for m in mm),
                    prohibited_commits=sum(m['prohibited_commits'] for m in mm),
                    permitted_twin_completion=rate(completion) if case_set=='P' else None,
                    development_completion_diagnostic=rate([outcomes(by_spec[encoded(s)],measures)['completion'] if encoded(s) in by_spec else None for s in planned]) if case_set=='D' else None,
                    policy_over_refusal=total_dict(m['policy_over_refusal'] for m in mm),
                    policy_over_refusal_episodes=sum(m['policy_over_refusal']['episode'] for m in mm),
                    policy_over_refusal_lawful_roster_calls=total_dict(m['policy_over_refusal'] for m in lawful_mm) if case_set=='P' else None,
                    policy_over_refusal_lawful_roster_episodes=sum(m['policy_over_refusal']['episode'] for m in lawful_mm) if case_set=='P' else None,
                    execution_failure=total_dict(m['execution_failure'] for m in mm),
                    execution_failure_episodes=sum(m['execution_failure']['episode'] for m in mm),
                    read_record_calls=total_dict(m['read_record_calls'] for m in mm),
                    duty_integrity=total_dict(m['duty_integrity'] for m in mm),
                    closed_unresolved_claim_instances=sum(len(m['duty_integrity']['currently_closed_with_unresolved']) for m in mm),
                    turns=sum(r['turns'] for r in rr),dollars=str(sum((D(e['cost']['dollars']) for e in episode_costs if belongs(e['spec'])),D(0))),
                    tokens_mapped=total_dict({k:v for k,v in e['cost'].items() if k!='dollars'} for e in episode_costs if belongs(e['spec'])))
                group['correct_reporting']={identity:dict(planned=3,attempted_episodes=sum(r['spec']['program']==identity for r in rr),
                    attempted_reports=sum(r['metrics']['correct_reporting']['attempted'] for r in rr if r['spec']['program']==identity),
                    successful_episodes=sum(r['metrics']['correct_reporting']['counted_success'] for r in rr if r['spec']['program']==identity)) for identity in ('P01','P09')} if case_set=='P' else {}
                group['native_tokens']=total_dict(e['native_tokens'] for e in episode_costs if belongs(e['spec']))
                groups.append(group)
    def git(*args): return subprocess.check_output(['git','-C',str(STATE),*args],text=True).strip()
    before=json.loads((ORIGINAL.parent/'before.json').read_bytes())
    state_head=git('rev-parse','HEAD')
    after=dict(provider_totals={p:json.loads(path.read_bytes())['estimated_api_dollars'] for p,path in {'anthropic':STATE/'ledgers/claude.json','google':STATE/'ledgers/google.json'}.items()},step_total=(STATE/'step-budget.txt').read_text(),state_commit=state_head)
    usage_costs={p:dict(dollars=str(sum((D(e['cost']['dollars']) for e in episode_costs if e['spec']['provider']==p),D(0))),
                      **total_dict({k:v for k,v in e['cost'].items() if k!='dollars'} for e in episode_costs if e['spec']['provider']==p)) for p in config.MODELS}
    for p in config.MODELS:
        ledger_delta=sum((D(f['value']['delta']) for f in fs if f['kind']=='ledger_change' and f['value']['provider']==p),D(0))
        assert D(after['provider_totals'][p])-D(before['provider_totals'][p])==ledger_delta
        usage_costs[p]['retained_reserves']=str(ledger_delta-D(usage_costs[p]['dollars']))
        usage_costs[p]['booked_dollars']=str(ledger_delta)
    assert D(after['step_total'])-D(before['step_total'])==sum((D(c['booked_dollars']) for c in usage_costs.values()),D(0))
    assert (STATE/'run.once').exists()
    commits=git('log',before['state_commit']+'..HEAD','--format=%H %s').splitlines()
    claim=next(c.split()[0] for c in commits if c.endswith('claim run.once'))
    report=dict(claim='[Descriptive] Single owner-approved pilot; no verdicts or interpretation.',stop=summary['stop'],
        approved_commit=before['commit'],attempted=len(rows),completed=sum(g['complete'] for g in groups),planned=396,
        groups=groups,costs=usage_costs,raw_runtime_costs=[s[0]['costs'] for s in summaries],before=before,after=after,root_checkpoint=checkpoint,root_checkpoints=checkpoints,
        accounting_note='The final Sonnet settlement wrote the usage-backed ledger and its commit reached origin, but publication confirmation raised state_publication_failed before phase_spent/token counters updated. Raw runtime costs therefore overstate Sonnet by 0.4325771 and omit the final reply tokens. No raw row or ledger was changed. Here cost is reconstructed read-only from each retained native usage frame and reconciled to the local and independently observed remote ledger. Raw runtime counters remain alongside it; the active lease is retained and no publication retry occurred.',
        native_token_totals={p:dict(c) for p,c in native_totals.items()},models_returned={p:sorted(m) for p,m in models.items()},
        sonnet_continuity=dict(replies_with_thinking=thinking_replies,replies_with_redacted_thinking=redacted_replies,
            assistant_content_equality_checks=replay_checks,checks_including_thinking=replay_with_thinking,received_replies_after_thinking_replay=replay_accepted),
        state_confirmations=[dict(kind=f['kind'],**f['value']) for f in fs if f['kind'] in ('state_confirmation','state_confirmation_wait')],retry_needed=summary['retry_needed'],physical_requests=sum(f['kind']=='request' for f in fs),native_replies=sum(f['kind']=='native_reply' for f in fs),
        state_claim_commit=claim,state_clean=not git('status','--porcelain','--untracked-files=all'),
        active_lease_exists=(STATE/'active-run.json').exists(),child_checkpoints=closed,
        bound_note='Unknown includes unattempted planned cells; bounds count unknown as false/true. D wrongfulness is descriptive over all T programs, not P twin population. No frozen D permitted-twin roster exists; D completion is an all-development diagnostic including T05/T07, not a lawful-twin score. All committed-act dispositions include every attempted episode; reads separate. Native Sonnet output includes thinking; do not add it again to output for billing.')
    observation=json.loads((HERE/'state-observation.json').read_bytes())
    report.update(remote_state=observation,continuation_claim_commit=observation['continuation_claim_commits'][0].split()[0],
        approved_continuation_commit='480835a8456348fb496377c9741e6af036b055df',
        continuation_before=json.loads((HERE/'before.json').read_bytes()),new_attempted=31,new_completed=30,
        stopped_episodes=2,untouched=342,next_untouched_index=54)
    report['accounting_note']='Original rows and raw runtime counters are retained. The original Anthropic publication stop left its phase counter 0.4325771 above native usage-backed charges. This continuation stopped after receiving the P06/conventional/Google repeat3 turn2 reply and recording its native usage, before parsing/executing its calls. Local settlement a162e12295d6003de2341569e4fe47bffe79583d subtracts 0.228354 from the prior published reservation; origin remains at that reservation parent 6d5523ad58aebdc74b0071b1e423efe7ba731220. The one delayed read-only confirmation observed a different tip and stopped immediately, without re-push. Local settled totals and published totals with retained reserve are reported separately. No raw row, counter, ledger, marker or lease was repaired.'
    write('description.json',report);write('per-episode.json',episode_costs);write('native-usage.json',native_usage_rows)
    print(json.dumps({k:report[k] for k in ('stop','attempted','completed','planned','costs','after','root_checkpoint','sonnet_continuity')},indent=2))

if __name__=='__main__': main()
