"""Lossless presentation of every existing metric; no classifications added."""
from pathlib import Path
import argparse,csv,hashlib,json,sys,zipfile
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,required=True);p.add_argument('--run',type=Path,required=True);a=p.parse_args();root=a.root.resolve();run=a.run.resolve();out=run/'rendered';out.mkdir(exist_ok=False)
sys.path.insert(0,str(root))
from tests.trace_support.state_observations import effects
r=json.loads((run/'results.json').read_text());manifest=json.loads((run/'manifest.json').read_text());assert manifest['status']=='completed'
episodes=r['episodes'];assert len(episodes)==320
arms=manifest['arms'];controllers=manifest['controllers'];programs=manifest['programs'];assert len({(e['arm'],e['controller'],e['case']) for e in episodes})==320
assert {(e['arm'],e['controller'],e['case']) for e in episodes}=={(x,y,z) for x in arms for y in controllers for z in programs}
metrics=list(episodes[0]['metrics']);assert len(metrics)==25
assert all(list(e['metrics'])==metrics for e in episodes)
scalar=[k for k in metrics if all(type(e['metrics'][k]) is int for e in episodes)]
list_keys=[k for k in metrics if all(type(e['metrics'][k]) is list for e in episodes)]
assert len(scalar)==24 and list_keys==['currently_closed_with_unresolved']
def aggregate(group):
 return dict(episodes=len(group),metrics={k:sum(e['metrics'][k] for e in group) if k in scalar else {e['case']+'/'+e['controller']:e['metrics'][k] for e in group} for k in metrics},discrepancies=sum(e['discrepancies'] for e in group),incomplete=sum(e['incomplete'] for e in group),state_audits=sum(len(e['assertions']) for e in group),baseline_source_assertions=sum(row.get('origin')=='source' for e in group for row in e['key_acceptance']))
summary={arm:aggregate([e for e in episodes if e['arm']==arm]) for arm in arms}
by_controller={controller:{arm:aggregate([e for e in episodes if e['arm']==arm and e['controller']==controller]) for arm in arms} for controller in controllers}
assert all(x['episodes']==40 for x in summary.values())
assert all(x['episodes']==10 for group in by_controller.values() for x in group.values())
issues=[];unassessed=[]
for e in episodes:
 identity={k:e[k] for k in ('case','arm','controller')}
 for index,observation in enumerate(e['observations']):
  if observation['semantic_label'] is None:unassessed.append(dict(identity,observation_index=index,observation=observation))
 for channel in ('assertions','key_acceptance'):
  for row in e[channel]:
   if row['status']!='pass':issues.append(dict(identity,channel=channel,check=row))
assert len(unassessed)==sum(e['metrics']['unassessed_actions'] for e in episodes)
(out/'summary.json').write_text(json.dumps(dict(counts=r['counts'],arms=summary,by_controller=by_controller),indent=2)+'\n')
(out/'issues.json').write_text(json.dumps(issues,indent=2)+'\n')
with (out/'unassessed.jsonl').open('w') as f:
 for item in unassessed:f.write(json.dumps(item,sort_keys=True)+'\n')
with (out/'episodes.csv').open('w',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=['case','arm','controller',*metrics,'discrepancies','incomplete','state_audits','baseline_source_assertions']);writer.writeheader()
 for e in episodes:
  values={k:json.dumps(v) if isinstance(v,list) else v for k,v in e['metrics'].items()}
  writer.writerow(dict(case=e['case'],arm=e['arm'],controller=e['controller'],**values,discrepancies=e['discrepancies'],incomplete=e['incomplete'],state_audits=len(e['assertions']),baseline_source_assertions=sum(row.get('origin')=='source' for row in e['key_acceptance'])))
labels=['TAA','C1','C2 primary','C2 diagnostic','Conventional SQL','TraceGrant','Floor','Static']
def matrix(title,data):
 lines=['## '+title,'','| Metric | '+' | '.join(labels)+' |','|---|'+'---:|'*len(arms)]
 for k in ['episodes',*scalar,'discrepancies','incomplete','state_audits','baseline_source_assertions']:
  vals=[data[arm]['metrics'][k] if k in scalar else data[arm][k] for arm in arms]
  lines.append('| `'+k+'` | '+' | '.join(map(str,vals))+' |')
 return lines
lines=['# Cross-arm scoring over the ten declared development programs','',
'[DESCRIPTIVE] Eight arms × four unchanged scripted controllers × ten declared programs =320 episodes.',
'[PROTOCOL] Source keys, proposal-origin bindings, context matching, controllers and POEC contracts are unchanged.',
'[MEASUREMENT] All arms use the same runner/state audits and one external duty oracle over actual host evidence.',
'[COVERAGE] TraceGrant covers only these ten development programs; no post-outcome contracts or wider coverage claims.',
'[LIMIT] Offline engineering observations only; no model calls, empirical H3 claim or interpretation beyond the committed definitions.','',
'Runtime merge: `'+manifest['runtime_merge']+'`; execution-plan commit: `'+manifest['input_commit']+'`.',
'Protocol SHA-256: `'+r['protocol_sha256']+'`. Programs: '+', '.join(programs)+'. Controllers: '+', '.join(controllers)+'.','',
'C1 removes only the prohibition stage. C2 primary removes revision invalidation and execution-time reassessment; its diagnostic retains reassessment. Token-intrinsic actor, arguments, single-use, expiry and withdrawal conditions remain. Conventional SQL and the local frozen-contract TraceGrant reconstruction are the reviewed implementations. The latter is not the authors\' evaluated configuration. Floor/static duty operations are plain business writes.','',
'The immutable protocol records Q14–Q16 as pending at authorship. Execution uses the approved, reviewed Q14–Q16/H1 implementation and common oracle from PR31; program selection and matching rules have not changed.','',
'The committed driver additionally runs ten ordinary-core key-acceptance passes, one per program, outside the320 scored episodes. Their full checks are retained under key_acceptance; baseline_source_assertions counts their source checks. state_audits counts the shared input-only scored-run checks.','',
'Integer cells below sum the existing per-episode metrics across40 separately initialized simulator episodes per arm. Refund amounts are W0 currency units. `world_refund_amount` includes any initial refunds; `committed_refund_amount` counts newly receipted refund effects. `unassessed_actions` counts proposal/execution observations, not unique episodes. Lawful/wrongful/disallowed keys apply only to exact matched origins, actors, arguments and contexts. Changed contexts or requests remain unassessed. Audit counts are checks, not trials. No source-key success is attributed to weaker arms from input-only audits.','']
lines+=['Definitions follow the committed episode()/Oracle.metrics implementations. Lawful opportunities are matched PERMIT proposals; agent over-caution is withholding those opportunities; gateway over-refusal is a non-withheld matched PERMIT proposal whose returned disposition is not PERMIT. Wrongful means a matched PROHIBIT key; disallowed additionally includes REFUSE/HOLD/REFER/ALTERNATIVE keys. Execution metrics count actual receipted dispatches, while world totals separately retain actual final records. Duty metrics are external-oracle final snapshots at each fixed controller program horizon; controllers retain their committed different horizons. Report delivery requires an actual dispatch artifact, and acknowledgment binds its id/version/recipient/matter.','']
lines+=matrix('Full arm totals — every scalar metric',summary)
lines+=['','## List-valued metric: `currently_closed_with_unresolved`','',
'This metric is a list per episode. The table records every nonempty episode/list; all omitted episodes have a verified empty list. The full320 lists are preserved verbatim in episodes.csv and summary.json. Claims are never deduplicated across separately initialized episodes.','', '| Arm | Nonempty episode → claim list |','|---|---|']
for arm,label in zip(arms,labels):
 nonempty={k:v for k,v in summary[arm]['metrics'][list_keys[0]].items() if v}
 lines.append('| '+label+' | `'+json.dumps(nonempty,sort_keys=True)+'` |')
lines+=['','## Discrepancies, incomplete and unassessed items','',
'All nonpassing audit/key checks are retained in rendered/issues.json. Every unassessed observation, including actual effects, result and context fingerprint, is retained in rendered/unassessed.jsonl. These items are not relabeled from an arm\'s output. Per-episode metrics and all returned observations remain in the raw journal/results.','',
'Counts: `'+json.dumps(r['counts'],sort_keys=True)+'`. Unassessed observations: '+str(len(unassessed))+'. Nonpassing check records: '+str(len(issues))+'.']
for controller in controllers:lines+=['']+matrix('Controller: '+controller,by_controller[controller])
# Supplement is retained prior engineering evidence, not extra scoring programs.
evidence=root/'docs/process/evidence/gateway-v032-final';v=json.loads((evidence/'validation.json').read_text());archive=evidence/'acceptance.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==v['archive']['sha256']
with zipfile.ZipFile(archive) as z:engineering=json.loads(z.read('final/all-arms.json'))
faults={arm:engineering['arms'][arm]['frozen'] for arm in ('floor','static')};(out/'engineering-faults.json').write_text(json.dumps(faults,indent=2)+'\n')
lines+=['','## Separate floor/static fault observations — outside the scoring population','',
'The ten declared programs contain no T23 fault-injection task. This supplement preserves PR31\'s reviewed engineering replay, whose runtime sources are unchanged. It is not pooled into the320 episodes. Actual before/after states and the four original receipt-mismatch audit records are retained in rendered/engineering-faults.json. Six T23 instances executed; eight absent boundaries were not applicable by design.','',
'| Arm | Boundary | Classification | Actual financial effects | New receipts | New business operations |','|---|---|---|---|---:|---:|']
for arm,group in faults.items():
 assert len(group['actual_fault_states'])==3 and len(group['not_applicable_by_design'])==4
 for item in group['actual_fault_states']:
  assert len(item['states'])==1
  s=item['states'][0];before,after=s['before'],s['after']
  lines.append('| '+arm+' | `'+s['boundary']+'` | fault injected; actual state captured | `'+json.dumps(effects(before,after),sort_keys=True)+'` | '+str(len(after['receipts'])-len(before['receipts']))+' | '+str(len(after['business_operations'])-len(before['business_operations']))+' |')
 for item in group['not_applicable_by_design']:
  lines.append('| '+arm+' | `'+item['boundary']+'` | not applicable by design: '+item['reason']+' | n/a | n/a | n/a |')
lines+=['','## Evidence and coverage boundary','',
'Per-arm totals, controller totals, all25 metrics per episode, full observations, source hashes, protocol provenance, raw issues and unassessed items are included in the companion evidence archive. The original frozen bundle remains unchanged. TraceGrant\'s broader engineering replay left127 missing-contract instances unrun; no contract was authored for them. This comparison is restricted to the ten originally declared programs. No statistical/population inference, novelty claim, paid run or public release is made.']
(out/'TAA_CROSS_ARM_SCORING_v0.md').write_text('\n'.join(lines)+'\n')
print(json.dumps(dict(episodes=320,arms=8,metrics=len(metrics),unassessed=len(unassessed),issues=len(issues),counts=r['counts'])))
