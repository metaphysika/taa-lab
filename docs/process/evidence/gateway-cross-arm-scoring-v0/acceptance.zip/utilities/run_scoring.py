"""One complete execution of the already committed cross-arm driver. No retries."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,os,subprocess,sys,traceback
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--merge',required=True);a=p.parse_args();root=a.root.resolve();out=a.out.resolve()
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
assert not git('status','--porcelain'),'scoring starts from a clean committed tree'
subprocess.run(['git','merge-base','--is-ancestor',a.merge,'HEAD'],cwd=root,check=True)
protected=['taa_gateway','taa_gateway_reference','conventional_gateway','comparators','agents/refunds','worlds/refunds','tests/trace_support','tests/expected_traces','docs/process/TAA_CROSS_ARM_PROTOCOL_v0.md','docs/process/TAA_GATEWAY_SPEC_CLARIFICATIONS_v0.3.2.md','docs/process/TAA_GATEWAY_REGRESSION_HOST_EVENTS_H1.md','docs/process/TAA_COMPARATOR_HARNESS_RULINGS.md']
assert not git('diff',a.merge,'HEAD','--',*protected)
sys.path.insert(0,str(root))
from comparators.cross_arm import run_suite,ARMS,PROTOCOL
from agents.refunds import CONTROLLERS
from worlds.refunds.catalog import catalog,provenance
from tests.trace_support.bundle import verify_bundle
verify_bundle();programs=catalog();assert [x['id'] for x in programs]==['T%02d'%i for i in range(1,11)]
assert hashlib.sha256(PROTOCOL.read_bytes()).hexdigest()=='e8059b51eaea0399f4ffe198d5712497067e5a0f43045539ffad1a71a67b9580'
files={}
for base in protected:
 q=root/base
 for f in ([q] if q.is_file() else sorted(q.rglob('*'))):
  if f.is_file() and f.suffix in ('.py','.yaml','.json','.md','.zip'):
   files[str(f.relative_to(root))]=hashlib.sha256(f.read_bytes()).hexdigest()
out.mkdir(parents=True,exist_ok=False)
manifest=dict(scope='Ten declared development programs only; existing committed driver and matching rules, no policy changes or model calls.',runtime_merge=a.merge,input_commit=git('rev-parse','HEAD'),started_utc=datetime.now(timezone.utc).isoformat(),python=sys.version,source_sha256=files,driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),programs=[c['id'] for c in programs],arms=list(ARMS),controllers=list(CONTROLLERS),expected_episodes=320,status='running',provenance=provenance())
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');seen=[]
try:
 with (out/'episodes.jsonl').open('x') as f:
  def retain(e):
   identity=(e['case'],e['arm'],e['controller']);assert identity not in seen;seen.append(identity)
   f.write(json.dumps(e,sort_keys=True,allow_nan=False)+'\n');f.flush();os.fsync(f.fileno())
   print(json.dumps(dict(episode=len(seen),case=e['case'],arm=e['arm'],controller=e['controller'],discrepancies=e['discrepancies'],incomplete=e['incomplete'])),flush=True)
  result=run_suite(on_episode=retain)
 assert len(result['episodes'])==320 and len(seen)==320
 journal=[json.loads(line) for line in (out/'episodes.jsonl').read_text().splitlines()]
 assert json.dumps(journal,sort_keys=True,allow_nan=False)==json.dumps(result['episodes'],sort_keys=True,allow_nan=False),'durable JSON journal differs from driver serialization'
 assert all(hashlib.sha256((root/k).read_bytes()).hexdigest()==v for k,v in files.items()),'runtime/input changed during scoring'
 (out/'results.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
 manifest.update(status='completed',counts=result['counts'],completed_utc=datetime.now(timezone.utc).isoformat())
except BaseException as error:
 manifest.update(status='stopped',episodes_retained=len(seen),error=dict(type=type(error).__name__,message=str(error)),stopped_utc=datetime.now(timezone.utc).isoformat())
 (out/'error.log').write_text(traceback.format_exc());raise
finally:(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
