from pathlib import Path
import csv,hashlib,json,shutil,subprocess,zipfile
root=Path('/workspace/taa-gateway-v032');run=Path('/workspace/scratch/gateway-cross-arm-scoring-a6df341d');rendered=run/'rendered';prep=Path('/workspace/scratch/gateway-scoring-prep')
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
raw=load(run/'results.json');m=load(run/'manifest.json');summary=load(rendered/'summary.json')
assert m['status']=='completed' and len(raw['episodes'])==320 and raw['counts']['discrepancies']==raw['counts']['incomplete']==0
assert m['driver_sha256']==sha(prep/'run_scoring.py')
plan=(root/'docs/process/TAA_CROSS_ARM_SCORING_RUN_PLAN_v0.md').read_text()
assert all(sha(prep/name) in plan for name in ('run_scoring.py','render_scoring.py'))
assert all(sha(root/path)==digest for path,digest in m['source_sha256'].items())
csvrows=list(csv.DictReader((rendered/'episodes.csv').open()));assert len(csvrows)==320
by_id={(e['case'],e['arm'],e['controller']):e for e in raw['episodes']};assert len(by_id)==320
for row in csvrows:
 e=by_id[(row['case'],row['arm'],row['controller'])]
 for key,value in e['metrics'].items():assert (json.loads(row[key]) if isinstance(value,list) else int(row[key]))==value
for arm,group in summary['arms'].items():
 selected=[r for r in csvrows if r['arm']==arm];assert len(selected)==40
 for key,value in group['metrics'].items():
  expected={r['case']+'/'+r['controller']:json.loads(r[key]) for r in selected} if isinstance(value,dict) else sum(int(r[key]) for r in selected)
  assert expected==value,(arm,key)
 for controller,groups in summary['by_controller'].items():
  selected_c=[r for r in selected if r['controller']==controller];assert len(selected_c)==10
  for key,value in groups[arm]['metrics'].items():
   expected={r['case']+'/'+r['controller']:json.loads(r[key]) for r in selected_c} if isinstance(value,dict) else sum(int(r[key]) for r in selected_c)
   assert expected==value,(arm,controller,key)
unknown=[json.loads(line) for line in (rendered/'unassessed.jsonl').read_text().splitlines()]
expected={(e['case'],e['arm'],e['controller'],i) for e in raw['episodes'] for i,o in enumerate(e['observations']) if o['semantic_label'] is None}
actual={(v['case'],v['arm'],v['controller'],v['observation_index']) for v in unknown}
assert len(unknown)==len(actual)==len(expected)==2105 and expected==actual
assert not load(rendered/'issues.json')
faults=load(rendered/'engineering-faults.json');assert sum(len(v['observed_nonatomic_faults']) for v in faults.values())==4
assert sum(len(v['not_applicable_by_design']) for v in faults.values())==8
assert sum(len(v['actual_fault_states']) for v in faults.values())==6
for value in faults.values():
 for item in value['actual_fault_states']:
  for s in item['states']:
   assert s['boundary'] in ('after_validate','during_effect_commit','during_receipt_write')
protected=['taa_gateway','taa_gateway_reference','conventional_gateway','comparators','agents/refunds','worlds/refunds','tests','scripts','docs/process/TAA_CROSS_ARM_PROTOCOL_v0.md']
assert not subprocess.check_output(['git','diff','a6df341d','HEAD','--',*protected],cwd=root)
out=root/'docs/process/evidence/gateway-cross-arm-scoring-v0';out.mkdir(exist_ok=True)
shutil.copyfile(rendered/'episodes.csv',out/'episodes.csv');shutil.copyfile(rendered/'summary.json',out/'summary.json')
report=(rendered/'TAA_CROSS_ARM_SCORING_v0.md').read_text()
# Editorial precision only; retain the frozen renderer output verbatim in the archive.
before='Duty metrics are external-oracle final snapshots at each fixed controller program horizon; controllers retain their committed different horizons.'
after='Duty status metrics are external-oracle final snapshots at each fixed controller program horizon; report deliveries count actual artifacts, and improper-closure/invalid-transfer metrics count operations, including repeats. Controllers retain their committed different horizons.'
assert report.count(before)==1
report=report.replace(before,after)
report+='\nFull evidence: [validation.json](evidence/gateway-cross-arm-scoring-v0/validation.json), [episode metrics CSV](evidence/gateway-cross-arm-scoring-v0/episodes.csv), [all summary/list metrics](evidence/gateway-cross-arm-scoring-v0/summary.json) and acceptance.zip in the same directory. The archive retains the exact pre-frozen utilities, original generated report, raw journal/results, all2105 unassessed observations, empty nonpassing-check list and full supplemental fault states. The published report only clarifies status-versus-operation count wording; no value or classification changes.\n'
(root/'docs/process/TAA_CROSS_ARM_SCORING_v0.md').write_text(report)
(run/'presentation-edit.json').write_text(json.dumps(dict(before=before,after=after,scope='Editorial metric-definition precision only; no values, classifications, policy or rendering utility changes.'),indent=2)+'\n')
files={str(p.relative_to(run)):p for p in sorted(run.rglob('*')) if p.is_file()}
for name in ('run_scoring.py','render_scoring.py','package_scoring.py'):files['utilities/'+name]=prep/name
for suffix in ('.log','.exit','-render.log'):
 p=Path(str(run)+suffix)
 if p.exists():files['logs/'+p.name]=p
manifest={name:sha(p) for name,p in files.items()}
archive=out/'acceptance.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in files.items():z.writestr(name,p.read_bytes())
 z.writestr('MANIFEST.sha256',''.join(digest+'  '+name+'\n' for name,digest in manifest.items()))
assert archive.stat().st_size<100*1024*1024
with zipfile.ZipFile(archive) as z:assert all(hashlib.sha256(z.read(name)).hexdigest()==digest for name,digest in manifest.items())
validation=dict(scope='One completed execution of the existing cross-arm driver over ten declared development programs. No interpretation or empirical H3 claim.',runtime_merge=m['runtime_merge'],input_commit=m['input_commit'],started_utc=m['started_utc'],completed_utc=m['completed_utc'],counts=raw['counts'],common_metrics=25,scalar_metrics=24,list_metrics=['currently_closed_with_unresolved'],episodes_csv_rows=320,unassessed_items=2105,nonpassing_records=0,all_scalar_and_list_cells_reconciled=True,all_unassessed_items_reconciled=True,protected_runtime_diff_empty=True,source_sha256=m['source_sha256'],utilities_sha256={name:sha(prep/name) for name in ('run_scoring.py','render_scoring.py')},protocol_sha256=raw['protocol_sha256'],tracegrant_coverage='Ten predeclared development programs only; no new contracts. Broader engineering missing-contract tasks unrun.',separate_fault_supplement=dict(executed=6,not_applicable_by_design=8,actual_receipt_mismatch_audits=4,pooled_into_scoring=False),presentation_edit=load(run/'presentation-edit.json'),archive=dict(path=str(archive.relative_to(root)),sha256=sha(archive),bytes=archive.stat().st_size,files=manifest),report_sha256=sha(root/'docs/process/TAA_CROSS_ARM_SCORING_v0.md'),episode_csv_sha256=sha(out/'episodes.csv'),summary_sha256=sha(out/'summary.json'))
(out/'validation.json').write_text(json.dumps(validation,indent=2)+'\n');print(json.dumps(dict(counts=raw['counts'],unassessed=2105,archive_bytes=archive.stat().st_size),indent=2))
