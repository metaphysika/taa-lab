"""Render description.json only; no statistical comparisons or provider calls."""
import json
from pathlib import Path
p=Path(__file__).parent
r=json.loads((p/'description.json').read_bytes())
lines=['[Descriptive] Experiment A pilot at approved `'+r['approved_commit']+'`. Stop: **'+r['stop']+'**. '+str(r['completed'])+' complete / '+str(r['attempted'])+' attempted / 396 planned episodes. H stayed sealed; no verdicts or comparisons computed.','',
'[Descriptive] Wrongfulness: `successes/observed` plus planned-cell lower–upper bounds. P uses the frozen odd twins (18 planned per arm/model). D uses all development programs (30); D has no twin population or frozen permitted-twin roster. P completion uses only P02/P04/P06/P08/P10/P12 (18 planned). Unknown includes stopped and unattempted cells. Known positive outcomes count despite incomplete endings.','']
lines[2:2]=['[Descriptive] '+r['accounting_note'],'', '[Descriptive] Final stop was in P10/taa/Sonnet repeat 1, turn 1, after the native reply and usage were retained, before parsing or executing its tool calls. Read-only later observation confirms local and origin tips agree at the settlement commit; this does not erase the failed confirmation or authorize a retry. The exact failed Git suboperation is not retained by the sanitized publisher, so its cause is unresolved.','']
def pct(v):return 'unavailable' if v is None else f'{v*100:.2f}%'
def rate(v):return f"{v['numerator']}/{v['observed_denominator']} ({pct(v['point'])}); bounds {pct(v['lower'])}–{pct(v['upper'])}; unknown {v['unknown']}/{v['planned_denominator']}"
def table(headers,rows):
 lines.append('| '+' | '.join(headers)+' |'); lines.append('| '+' | '.join(['---']*len(headers))+' |')
 for row in rows: lines.append('| '+' | '.join(str(v) for v in row)+' |')
 lines.append('')
gs=r['groups']; key=lambda g:g['provider']+'/'+g['arm']+'/'+g['case_set']
table(['Model/arm/set','Complete / attempted / planned','Wrongful episodes','Permitted-twin completion'],[[key(g),f"{g['complete']} / {g['attempted']} / {g['planned']}",rate(g['wrongful']),rate(g['permitted_twin_completion']) if g['case_set']=='P' else 'No frozen D twin roster; diagnostic below'] for g in gs])
lines+=['[Descriptive] D claimant-duty completion diagnostic uses all 30 planned development cells per arm/model, including the prospectively excluded no-lawful-completion programs T05/T07. It is not a permitted-twin completion score.','']
table(['Model/arm/D','Development completion diagnostic'],[[key(g),rate(g['development_completion_diagnostic'])] for g in gs if g['case_set']=='D'])
lines+=['[Descriptive] Committed non-read acts, independent pre-commit disposition. ALTERNATIVE is excluded from wrongful episodes and shown separately.','']
order=['PROHIBIT','REFUSE','REFER','HOLD','ALTERNATIVE','PERMIT']
table(['Model/arm/set']+order,[[key(g)]+[g['dispositions'].get(k,0) for k in order] for g in gs])
lines+=['[Descriptive] Over-refusal and execution failure are call counts; episode incidence follows in parentheses. Read counts stay separate from business acts. These counts cover all attempted episodes in the stated set; lawful-roster-only over-refusal also appears in description.json.','']
table(['Model/arm/set','Policy refusal reads / business (episodes)','Execution failure reads / business (episodes)','Read attempted / completed / refused','Output ceiling / turn limit'],[[key(g),f"{g['policy_over_refusal'].get('reads',0)} / {g['policy_over_refusal'].get('business_acts',0)} ({g['policy_over_refusal_episodes']})",f"{g['execution_failure'].get('reads',0)} / {g['execution_failure'].get('business_acts',0)} ({g['execution_failure_episodes']})",' / '.join(str(g['read_record_calls'].get(k,0)) for k in ('attempted','completed','refused')),f"{g['stops'].get('output_ceiling',0)} / {g['stops'].get('turn_limit',0)}"] for g in gs])
lines+=['[Descriptive] Correct reporting is once-per-episode delivery to C or F on the program claim; no assessment of content. Untouched episodes are shown in the planned denominator.','']
table(['Model/arm','Program','Successful / attempted episodes / planned','Episodes proposing report'],[[g['provider']+'/'+g['arm'],identity,f"{v['successful_episodes']} / {v['attempted_episodes']} / {v['planned']}",v['attempted_reports']] for g in gs if g['case_set']=='P' for identity,v in g['correct_reporting'].items()])
lines+=['[Descriptive] Duty integrity totals sum episode measurements, so repeated or inherited duties are counted again in each episode. Complete per-episode duty metrics remain in the raw rows; these are not counts of unique business duties across the experiment.','']
di=['unresolved_duties','overdue_duties','unowned_duties','report_duties','reports_delivered','reports_acknowledged','closures_with_unresolved_duties','invalid_transfer_operations','oracle_incomplete']
table(['Model/arm/set']+di,[[key(g)]+[g['duty_integrity'].get(k,0) for k in di] for g in gs])
lines+=['[Descriptive] Native token totals follow. Sonnet output includes thinking tokens; thinking is a subset and is not charged twice. Cache creation is partitioned into 5m/1h in native-usage.json. Mapped Sonnet thinking=0 is the unchanged runtime accounting convention; the native thinking field is authoritative in this report.','']
table(['Provider','Native tokens','Pilot dollars','Before provider total','After provider total'],[[provider,'; '.join(k+'='+str(v) for k,v in r['native_token_totals'][provider].items()),r['costs'][provider]['dollars'],r['before']['provider_totals'][provider],r['after']['provider_totals'][provider]] for provider in ('anthropic','google')])
table(['Model/arm/set','Turns','Pilot dollars','Native tokens'],[[key(g),g['turns'],g['dollars'],'; '.join(k+'='+str(v) for k,v in g['native_tokens'].items())] for g in gs])
lines+=['[Descriptive] Step total: '+r['before']['step_total']+' → '+r['after']['step_total']+'. Physical requests '+str(r['physical_requests'])+', native replies '+str(r['native_replies'])+', retry-needed requests '+str(r['retry_needed'])+'.','',
'[Descriptive] Sonnet continuity: `'+json.dumps(r['sonnet_continuity'],sort_keys=True)+'`. Every received follow-up was checked against exact retained assistant content, including opaque signatures.','',
'[Descriptive] Root checkpoint: `'+r['root_checkpoint']['head']+'`; state attempt claim `'+r['state_claim_commit']+'`; final state `'+r['after']['state_commit']+'`. State clean='+str(r['state_clean'])+'; active lease='+str(r['active_lease_exists'])+'. The pilot once-marker remains used.','',
'[Descriptive] Evidence directory: '+str(p/'pilot')+'. [Full grouped metrics and bounds](description.json), [per-episode tokens, dollars and turns](per-episode.json), [exact native usage fields by episode/turn](native-usage.json). All child chains and the root chain verified. No A1/H3 verdict, bootstrap comparison, H loading, replacement or restart was performed.','']
(p/'REPORT.md').write_text('\n'.join(lines))
print('Rendered descriptive report:',p/'REPORT.md')
