from pathlib import Path
import json,hashlib
root=Path('/workspace/taa-gateway-q18');before=json.loads(Path('/workspace/scratch/gateway-q18/pre-change-effective.json').read_bytes());after=json.loads(Path('/workspace/scratch/gateway-q18/fixed-initial.json').read_bytes())
old={(r['case'],r['implementation']):r for r in before['rows']};new={(r['case'],r['implementation']):r for r in after['rows']}
assert old.keys()==new.keys();rows=[]
for key,row in old.items():
 fixed=new[key];assert row['expected']==fixed['expected'] and fixed['passed']
 rows.append(dict(case=key[0],implementation=key[1],expected=row['expected'],before=row['observed'],after=fixed['observed'],exposes_pre_change_defect=not row['passed']))
r={'claim':'[Descriptive] Observations compared to previously authored expectations; no implementation-generated keys.','checks':len(rows),'before_discrepancies':sum(r['exposes_pre_change_defect'] for r in rows),'after_discrepancies':0,'rows':rows}
(root/'docs/process/evidence/gateway-q18/before-after.json').write_text(json.dumps(r,indent=2)+'\n')
lines=['# [Descriptive] Q18 pre-change sensitivity by case and implementation','', '[Descriptive] Expected values are the independently rule-authored fixture literals. Before/after columns are observations; a matching old result is a preservation control, not a claimed pre-change defect. Every mismatching old implementation below fails that case’s assertion. All six exact live cases fail on their named targets.','', '| Case | Reference before → fixed | Core before → fixed | MCP before → fixed | Conventional before → fixed | Expected |','|---|---|---|---|---|---|']
for c in json.loads((root/'tests/regression_scenarios/q18.json').read_bytes())['cases']+json.loads((root/'tests/regression_scenarios/q18_additional.json').read_bytes())['cases']:
 values=[]
 for backend in ('reference','core','mcp','conventional'):
  a=old[c['id'],backend];b=new[c['id'],backend];values.append(('**' if not a['passed'] else '')+str(a['observed'])+' → '+str(b['observed'])+('**' if not a['passed'] else ''))
 lines.append('| '+c['id']+' | '+' | '.join(values)+' | '+c['expected']+' |')
(root/'docs/process/TAA_GATEWAY_Q18_SENSITIVITY.md').write_text('\n'.join(lines)+'\n')
live=[]
for r in after['rows']:
 if 'Q18-LD03131469-' in r['case']:
  ident=r['case'].removeprefix('Q18-');src=root/'studies/live-demo-03131469-review/internal-adjudication'/(ident+'.json')
  live.append(dict(case=ident,implementation=r['implementation'],expected=r['expected'],observed=r['observed'],source_prestate_file=str(src.relative_to(root)),source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),result=r['result']))
(root/'docs/process/evidence/gateway-q18/live-readjudication.json').write_text(json.dumps({'claim':'[Descriptive] Separate fixed-policy counterfactual in the six original pre-proposal states; original live scores and evidence unchanged. No live rerun, tool execution or provider request.','observations':live},indent=2)+'\n')
