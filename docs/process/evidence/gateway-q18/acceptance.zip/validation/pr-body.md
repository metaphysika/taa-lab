[Descriptive] Implements Chris's 2026-10-25 Q18 ruling: primary objects determine scope; unresolved optional references add no resource; every resolved reference must satisfy every applicable scope dimension on one complete grant path. Records the ruling beside Q17/Q17.1.

[Descriptive] The reference and conventional policies now HOLD on unknown assertions and unresolvable primary objects, and enforce Q13 basis-record requirements for implicit denial notices. Core resource projection admits the two legitimate reports while checking resolved optional references. Registered projections are trusted context, with token invalidation when a formerly absent reference appears.

| Exact archived live call | Rule-derived expectation, all four paths |
|---|---|
| OR01 | HOLD |
| OR02 | HOLD |
| OR03 | REFUSE |
| OR04 | PERMIT |
| OR05 | PERMIT |
| OR06 | REFUSE |

[Descriptive] The complete 91-case expectation table is in `docs/process/TAA_GATEWAY_Q18_EXPECTATIONS.md`; `TAA_GATEWAY_Q18_SENSITIVITY.md` identifies each pre-change failure and matched control. Expected literals were authored from the rules before policy edits. The six original pre-proposal states and exact calls are replayed through reference, direct core, MCP and conventional paths. Separate `live-readjudication.json` records counterfactual judgments; original live counts and evidence are unchanged.

[Descriptive] Verification:

- 364 case/implementation checks: 119 assertion discrepancies on clean pre-change a3e77d56, zero after repair. The insertion/invalidation boundary also fails by assertion on all four pre-change paths. Three boundary and two preservation guard tests pass.
- Frozen v0.2.2: all 534 assertions pass. Each backend passes all 153 active scenarios / 1,079 source assertions, including permanent H1 and Q11–Q17 suites, with zero discrepancies or incomplete checks.
- MCP acceptance: 140 scenarios / 1,062 source assertions / 3,907 state audits / 4,972 checks, zero discrepancies or incomplete checks.
- One unchanged-protocol 320-episode verification: every per-episode metric, final world and oracle board matches the original; all 1,000 aggregate/controller protocol cells and supplementary scores unchanged. Journal bytes differ because policy query/check records changed; no byte-identity claim is made for the new journal.
- Preservation passes for 140 protected files and original 320-episode evidence. Scripted all-scenario command passes. Full discovery and archive details are recorded in `docs/process/evidence/gateway-q18/validation.json`.

[Descriptive] The preservation command remains strict by default. Its explicit Q18 change record admits exactly five SHA-pinned policy files after successful frozen/comparison verification; all scientific inputs, original evidence and other protected files remain byte-checked. Two older unit-test setups now provide valid primary bindings so their unchanged standing/effect-integrity assertions still isolate the intended controls. Initial diagnostics are retained.

[Descriptive] PR #37 then PR #38 were merged in the approved order after recorded review and green CI. This new PR awaits Claude review. No provider requests, live reruns, spending, gateway launch or original-result relabeling. Do not merge this PR under the current task.
