from pathlib import Path
import json,copy
root=Path('/workspace/taa-gateway-q18');out=root/'tests/regression_scenarios/q18.json';cases=[]
def add(id,tool,args,expected,rule,setup=None,**extra):
 cases.append(dict(id=id,tool=tool,args=args,expected=expected,rule=rule,setup=setup or {},**extra))
# All expected literals below are authored from Chris's ruling before policy edits.
expected=['HOLD','HOLD','REFUSE','PERMIT','PERMIT','REFUSE']
for i,value in enumerate(expected,1):
 id=f'LD03131469-OR{i:02}';source=json.loads((root/'studies/live-demo-03131469-review/internal-adjudication'/f'{id}.json').read_text())
 add('Q18-'+id,source['call']['tool'],source['call']['args'],value,('unknown assertions' if i==1 else 'Q18 primary unknown' if i==2 else 'Q13 denial basis' if i in (3,6) else 'Q18 unresolved optional reference'),source_case=id,targets=['core','mcp'] if i in (4,5) else ['reference','conventional'])
scoped={'records':{'RET1':{'received':True}},'grants':{'G1':{'scope':{'customers':['K1']}}}}
for tool,args in [('report',{'claim':'CL1','to':'F'}),('message_party',{'claim':'CL1','to':'K1','template':'claim_referred'}),('issue_refund',{'claim':'CL1','amount':120,'to':'K1_card','basis':'return'})]:
 for label,assertion,expect,changes in [('true','return received','PERMIT',True),('false','return received','PROHIBIT',False),('unknown','return_item_received','HOLD',True)]:
  setup=copy.deepcopy(scoped);setup['records']['RET1']['received']=changes
  add(f'Q18-assert-{tool}-{label}',tool,dict(args,asserts=[assertion]),expect,'PR1 and Q1; unknown is not satisfied',setup)
add('Q18-assert-missing-evidence','report',{'claim':'CL1','to':'F','asserts':['return received']},'HOLD','PR1 missing evidential fact',dict(scoped,remove_records=['RET1']))
for label,args,exp in [('owned',{'record':'ORD1'},'PERMIT'),('foreign',{'record':'ORD2'},'REFUSE'),('missing',{'record':'NONE'},'HOLD'),('missing-with-forged-customer',{'record':'NONE','customer':'K1','claim':'CL1'},'HOLD'),('foreign-with-in-scope-claim',{'record':'ORD2','claim':'CL1'},'REFUSE')]:
 add('Q18-read-'+label,'read_record',args,exp,'Q18 primary record; Q17.1 customer scope',copy.deepcopy(scoped))
for tool,args in [('report',{'to':'F','claim':'NONE','customer':'K1','record':'ORD1'}),('message_party',{'to':'K1','claim':'NONE','template':'claim_referred','record':'ORD1'})]:
 add('Q18-primary-unknown-'+tool,tool,args,'HOLD','Q18 unresolved primary cannot be repaired by an optional reference or asserted customer',copy.deepcopy(scoped))
# Every registered tool with an optional record argument; primary bindings are tool semantics.
base=[('report',{'claim':'CL1','to':'F'},scoped,None,'A'),('issue_refund',{'claim':'CL1','amount':120,'to':'K1_card','basis':'return'},scoped,None,'A'),('message_party',{'claim':'CL1','to':'K1','template':'claim_referred'},scoped,None,'A'),('hold_refund',{'claim':'CL1','missing':'pending review'},scoped,None,'A'),('deny_refund',{'claim':'CL1','amount':120,'basis':'RET1'},dict(scoped,records={'RET1':{'received':False}}),None,'A'),('close_case',{'case':'CL1'},dict(scoped,records={'RET1':{'received':False}}),[{'actor':'A','tool':'message_party','args':{'claim':'CL1','to':'K1','template':'refund_denied','amount':120,'basis':'RET1'}}],'A'),('offer_duty',{'duty':'D_resolve(CL1)','to':'F'},scoped,None,'A')]
world=json.loads((root/'live_demo/frozen/world.json').read_text());bgrant=copy.deepcopy(world['grants']['G1']);bgrant.update(grantee='B',scope={'customers':['K1']})
acceptsetup=copy.deepcopy(scoped);acceptsetup['grants']['G2']=bgrant
base.append(('accept_duty',{'duty':'D_resolve(CL1)'},acceptsetup,[{'actor':'A','tool':'offer_duty','args':{'duty':'D_resolve(CL1)','to':'B'}}],'B'))
for tool,args,setup,prelude,actor in base:
 for label,record,expected in [('absent',None,'PERMIT'),('unresolved','NONE','PERMIT'),('prose','RET1 v1; ORD1 v1','PERMIT'),('owned','RET1','PERMIT'),('foreign','ORD2','REFUSE')]:
  call=dict(args)
  if record is not None:call['record']=record
  add('Q18-optional-'+tool+'-'+label,tool,call,expected,'Q18 optional reference and complete-path customer scope',copy.deepcopy(setup),actor=actor,prelude=prelude or [])
# No authorization rule exists for this registered tool; Q18 invents no grant.
for label,record in [('unresolved','NONE'),('foreign','ORD2')]:
 add('Q18-unruled-export-'+label,'export_records',{'record':record},'REFER','Existing no-authorization-rule referral retained',copy.deepcopy(scoped))
for tool in ('deny_refund','message_party'):
 for label,basis,expect,received in [('empty','', 'REFUSE',False),('missing-record','NONE','REFUSE',False),('prose','Return eligibility is not established','REFUSE',False),('valid','RET1','PERMIT',False),('versioned','RET1@v1','PERMIT',False),('contradicting','RET1','PROHIBIT',True),('unrelated','DEL2','PROHIBIT',False)]:
  args={'claim':'CL1','amount':120,'basis':basis}
  if tool=='message_party':args.update(to='K1',template='refund_denied')
  setup=copy.deepcopy(scoped);setup['records']['RET1']['received']=received
  add('Q18-denial-'+tool+'-'+label,tool,args,expect,'Q13 missing evidence versus contradiction; implicit/explicit template parity; Q1 precedence',setup)
for label,record in [('unresolved','NONE'),('foreign','ORD2')]:
 add('Q18-report-cites-'+label,'report',{'claim':'CL1','to':'F','cites':record},'PERMIT' if label=='unresolved' else 'REFUSE','Q18 applies to resolved citations as well as record',copy.deepcopy(scoped))
# Complete paths must cover BOTH resources; another path cannot repair one.
for label,scope,parent,second,expect in [('all-allowed',['K1','K2'],None,None,'PERMIT'),('parent-restricted',['K1','K2'],['K1'],None,'REFUSE'),('split-paths',['K1'],None,['K2'],'REFUSE'),('independent-complete-path',['K1'],None,['K1','K2'],'PERMIT')]:
 setup=copy.deepcopy(scoped);setup['grants']['G1']['scope']={'customers':scope}
 if parent:setup['grants']['G0']={'scope':{'customers':parent}}
 if second:
  g=copy.deepcopy(world['grants']['G1']);g['scope']={'customers':second};setup['grants']['G2']=g
 add('Q18-path-'+label,'report',{'claim':'CL1','to':'F','record':'ORD2'},expect,'Q17.1 complete-path existential choice and Q18 all resolved references',setup)
# A refund basis is a category, not a citation.
setup=copy.deepcopy(scoped);setup['records']['return']={'kind':'carrier_record','order':'ORD2','status':'delivered','failed_value':0}
add('Q18-category-not-reference','issue_refund',{'claim':'CL1','amount':120,'to':'K1_card','basis':'return'},'PERMIT','Q18 registered reference semantics, not string coincidence',setup)
fixture={'attribution':'Sol-authored expected literals from Chris Q18, accepted OR01/02/03/06 and Q13/Q17.1/Q1; written before implementation changes. Never implementation-generated keys.','cases':cases}
out.write_text(json.dumps(fixture,indent=2)+'\n')
lines=['# [Descriptive] Q18 rule-derived expected outcomes','', '[Descriptive] Authored before policy edits or pre-change tests. These are normative expectations from the owner ruling and existing Q13/Q17.1/Q1, not implementation observations. Each row applies independently to reference, core, MCP and conventional; exact live states remain immutable archived inputs.','', '| Case | Call | Expected disposition | Rule |','|---|---|---|---|']
for c in cases:lines.append('| '+c['id']+' | '+c['tool']+' '+json.dumps(c['args'],sort_keys=True).replace('|','\\|')+' | '+c['expected']+' | '+c['rule']+' |')
(root/'docs/process/TAA_GATEWAY_Q18_EXPECTATIONS.md').write_text('\n'.join(lines)+'\n')
print('Authored',len(cases),'rule-derived cases before implementation edits')
