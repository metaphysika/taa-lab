#!/bin/bash
set -e
cd /workspace/taa-gateway-q18
PATH=/tmp/taa-live-demo-venv/bin:$PATH python scripts/check_gateway_q18_comparison.py --acceptance /workspace/scratch/gateway-q18/unchanged-acceptance.json --output /workspace/scratch/gateway-q18/scoring
