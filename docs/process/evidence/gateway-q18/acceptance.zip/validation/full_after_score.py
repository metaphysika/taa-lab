"""One free repository test invocation, only if the comparison gate passes."""
import json,os,sys,time
from pathlib import Path
root=Path('/workspace/taa-gateway-q18');manifest=Path('/workspace/scratch/gateway-q18/scoring/manifest.json')
while True:
 try:r=json.loads(manifest.read_bytes())
 except json.JSONDecodeError:
  time.sleep(2);continue
 if r['status']=='STOPPED':raise SystemExit('Comparison stopped: no further validation started')
 if r['status']=='PASS':break
 time.sleep(5)
assert r['episodes']==320 and not r['changes']
os.chdir(root)
os.execv(sys.executable,[sys.executable,'-m','unittest','discover','tests'])
