"""Close PR37 review evidence after final offline gates, without scored reruns."""
import hashlib
import json
from pathlib import Path
import platform
import re
import subprocess
import sys
import zipfile

ROOT=Path('/workspace/taa-lab');sys.path.insert(0,str(ROOT))
from live_demo.config import verify as verify_inputs
from live_demo.evidence import verify

OUT=ROOT/'docs/process/evidence/gateway-live-demo-pr37-review-v011'


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def suite(path):
    content=path.read_text()
    if not re.search(r'^OK(?: \(skipped=\d+\))?$',content,re.M):raise ValueError('not closed PASS: '+str(path))
    m=re.search(r'Ran (\d+) tests in ([\d.]+)s',content)
    skips=re.search(r'^OK \(skipped=(\d+)\)',content,re.M)
    return dict(tests=int(m[1]),seconds=float(m[2]),skips=int(skips[1]) if skips else 0,sha256=sha(path))


def main():
    full=suite(Path('/tmp/taa-live-demo-review-full-003.log'))
    focused=suite(Path('/tmp/taa-live-demo-review-focused-003.log'))
    assert focused['tests']==42
    source=json.loads(Path('/workspace/scratch/live-demo-review-v01/final-source-hashes.json').read_bytes())
    assert all(sha(ROOT/name)==expected for name,expected in source.items())
    pins=verify_inputs()
    preservation=json.loads(Path('/tmp/taa-live-demo-review-preservation-002.json').read_bytes())
    assert preservation['status']=='PASS'
    mutations=json.loads(Path('/tmp/taa-live-demo-review-mutations-003.json').read_bytes())
    assert mutations['status']=='PASS'
    for row in mutations['controls']:
        assert row['before']['passed'] and row['restored']['passed']
        assert row['mutant']['failures']==1 and row['mutant']['errors']==0
    standin=Path('/tmp/taa-live-demo-review-standin-003');checkpoints={'run':verify(standin)}
    for folder in standin.glob('episode-*'):checkpoints[folder.name]=verify(folder)
    entries=[json.loads(p.read_bytes()) for p in standin.glob('[0-9]*.json')]
    summary=next(r['value'] for r in entries if r['kind']=='summary')
    assert summary['stop']=='complete' and len(summary['episodes'])==30
    for arm,counts in summary['per_arm'].items():
        assert counts['episodes']==10
        assert counts['committed_acts']==sum(counts['dispositions'].values())
        assert counts['read_record_calls']['attempted']>0
    for folder in Path('/tmp/taa-live-demo-review-stops-003').iterdir():verify(folder)
    ledger_hashes={}
    for provider in ('openai','claude','google','groq'):
        name='results/formation-spending-v021/'+provider+'.json'
        assert (ROOT/name).read_bytes()==subprocess.check_output(['git','show','affa26d8:'+name],cwd=ROOT)
        ledger_hashes[name]=sha(ROOT/name)
    prior={}
    for name in ('acceptance.zip','checkpoint.zip','validation.json','checkpoint-validation.json'):
        path=ROOT/'docs/process/evidence/gateway-live-demo-v01'/name
        assert path.read_bytes()==subprocess.check_output(['git','show','affa26d8:'+str(path.relative_to(ROOT))],cwd=ROOT)
        prior[str(path.relative_to(ROOT))]=sha(path)
    files={}
    for number in (1,2,3):
        for stem in ('standin','stops'):
            folder=Path('/tmp/taa-live-demo-review-%s-%03d'%(stem,number))
            if folder.exists():
                for path in folder.rglob('*'):
                    if path.is_file():files['%s-%03d/'%(stem,number)+str(path.relative_to(folder))]=path
    for path in Path('/tmp').glob('taa-live-demo-review-*.log'):files['logs/'+path.name]=path
    for path in Path('/tmp').glob('taa-live-demo-review-*.json'):files['controls/'+path.name]=path
    for path in Path('/workspace/scratch/live-demo-review-v01').rglob('*'):
        if path.is_file():files['methods-and-scenarios/'+str(path.relative_to('/workspace/scratch/live-demo-review-v01'))]=path
    for name in source:files['final-source/'+name]=ROOT/name
    for path in (ROOT/'live_demo/frozen').iterdir():
        if path.is_file():files['final-source/live_demo/frozen/'+path.name]=path
    OUT.mkdir(parents=True,exist_ok=True)
    members={}
    with zipfile.ZipFile(OUT/'acceptance.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for name,path in sorted(files.items()):
            assert path.name!='keys.env'
            raw=path.read_bytes();members[name]=hashlib.sha256(raw).hexdigest();archive.writestr(name,raw)
        archive.writestr('MEMBER_SHA256.json',json.dumps(members,indent=2,sort_keys=True)+'\n')
    receipt=dict(status='PASS: offline PR37 review corrections; no launch approval',build='v0.1.1',
        base='affa26d86eeda23e2723e4a4c25ec98bbc14b597',python=platform.python_version(),
        repository_tests=full,focused_tests=focused,final_source_hashes=source,frozen_input_hashes=pins,
        mutations=mutations,protected_preservation=preservation,prior_evidence_sha256=prior,
        provider_ledgers_unchanged=ledger_hashes,actual_model_or_real_neutral_requests=0,actual_new_api_dollars=0,
        standin=dict(episodes=30,mode='CANNED ENGINEERING ONLY',per_arm=summary['per_arm'],
                     cost=summary['totals'],checkpoints=checkpoints),
        local_namespace=dict(status='KERNEL_DENIED',error='unshare: Operation not permitted',
                             fallback='Local socket denial passed; exact-head Ubuntu sudo-unshare CI must be checked after push'),
        required_items_implemented=[1,2,3,4,5,6],staff_list_added=False,
        reason='Chris approval for optional item7 is not recorded',
        diagnostics=['First new test run used three wrong mock binding sites; retained and corrected without relaxing gates.',
                     'Earlier focused40 and41 passes and interrupted broad prefixes retained; final42/full use final bound source.',
                     'Final gate covers mutable tracked step accounting and rejects tracked source edits.'],
        archive=dict(path='acceptance.zip',sha256=sha(OUT/'acceptance.zip'),bytes=(OUT/'acceptance.zip').stat().st_size,
                     members=len(members)+1))
    with (OUT/'validation.json').open('x') as stream:json.dump(receipt,stream,indent=2);stream.write('\n')
    print(json.dumps(dict(repository_tests=full,focused_tests=focused,per_arm=summary['per_arm'],archive=receipt['archive']),indent=2))


if __name__=='__main__':main()
