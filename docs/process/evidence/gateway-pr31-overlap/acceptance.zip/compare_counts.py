from pathlib import Path
import json,subprocess,hashlib
root=Path('/workspace/taa-gateway-v032');run=Path('/workspace/scratch/gateway-pr31-overlap')
def load(p):return json.loads(p.read_text())
def rows_count(rows):return dict(checks=len(rows),source_assertions=sum(r.get('origin')=='source' for r in rows),state_audits=sum(r.get('origin')=='state-audit' for r in rows),discrepancies=sum(r['status']=='discrepancy' for r in rows),incomplete=sum(r['status']=='incomplete' for r in rows))
old=load(root/'docs/process/evidence/gateway-v032-final/validation.json');rows=[]
ref=load(run/'reference.json');prod=load(run/'production.json');sql=load(run/'conventional.json');reg=load(run/'regressions.json')
current={'frozen':dict(reference=rows_count(ref['assertions']),production=prod['frozen']['counts'],conventional=rows_count(sql['results']['frozen']['assertions'])),'permanent_regressions':dict(reference=reg['counts'],production=prod['regressions']['counts'],conventional=rows_count(sql['results']['regression']['assertions']))}
for suite,backends in current.items():
 for name,c in backends.items():
  expected=old[suite][name];shared={k for k in expected.keys()&c.keys() if type(expected[k]) is int}
  assert {'source_assertions','state_audits','discrepancies','incomplete'}<=shared
  assert all(c[k]==expected[k] for k in shared),(suite,name,expected,c)
  rows.append(dict(suite=suite,backend=name,counts={k:c[k] for k in sorted(shared)},unchanged=True))
for suite in ('q14','q15','q16'):
 fresh=load(run/(suite+'.json'));assert fresh['gate_pass']
 for name,values in fresh['backends'].items():
  assert values['counts']==old['current'][suite][name],(suite,name,values['counts'],old['current'][suite][name])
  rows.append(dict(suite=suite,backend=name,counts=values['counts'],unchanged=True))
protected=['taa_gateway','taa_gateway_reference','conventional_gateway','comparators','agents','worlds','tests/expected_traces','tests/regression_scenarios/q14.yaml','tests/regression_scenarios/q15.yaml','tests/regression_scenarios/q16.yaml','tests/regression_scenarios/q11_q12.yaml','tests/regression_scenarios/q13.yaml','tests/regression_scenarios/astra_spot_check.yaml','docs/process/TAA_CROSS_ARM_PROTOCOL_v0.md']
assert not subprocess.check_output(['git','diff','6526bccd','--',*protected],cwd=root)
result=dict(base_commit='6526bccdc707289cea9a54177045b2d9678975bf',comparisons=rows,protected_paths=protected,protected_git_diff_empty=True,gate_pass=True)
(run/'count-comparisons.json').write_text(json.dumps(result,indent=2)+'\n');print('Unchanged cohort comparisons:',len(rows))
