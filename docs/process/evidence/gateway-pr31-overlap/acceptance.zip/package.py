from pathlib import Path
import hashlib,json,re,shutil,subprocess,zipfile
root=Path('/workspace/taa-gateway-v032');run=Path('/workspace/scratch/gateway-pr31-overlap')
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert (run/'discovery-final.exit').read_text().strip()=='0'
log=(run/'discovery-final.log').read_text();match=re.search(r'Ran (\d+) tests in ([\d.]+)s',log)
assert match and int(match[1])==1098 and 'OK (skipped=36)' in log
assert (run/'scripted.exit').read_text().strip()=='0'
subprocess.run(['/workspace/scratch/gateway-py311/bin/python',str(run/'compare_counts.py')],check=True,cwd=root)
checks=load(run/'count-comparisons.json');assert checks['gate_pass'] and len(checks['comparisons'])==15
mutants=load(run/'mutations-fixed.json');assert mutants['gate_pass']
summary={}
for backend,value in mutants['backends'].items():
 def counts(rows):return dict(checks=len(rows),source_assertions=sum(r['origin']=='source' for r in rows),state_audits=sum(r['origin']=='state-audit' for r in rows),discrepancies=sum(r['status']=='discrepancy' for r in rows),incomplete=sum(r['status']=='incomplete' for r in rows))
 current=counts(value['passing']);broken=counts(value['summed_overlap']);assert current['source_assertions']==15 and current['discrepancies']==current['incomplete']==0
 assert value['source_discrepancies']==3 and broken['incomplete']==0 and value['restored_identically']
 # Pin the actual wrong-discharge endpoint, not just an intermediate coverage quantity.
 duty=[r for r in value['summed_overlap'] if r['assertion']=='steps[7]@5.duties'];closure=[r for r in value['summed_overlap'] if r['assertion']=='steps[8]@6.disposition']
 assert len(duty)==len(closure)==1 and duty[0]['observed'][0]['resolution']=='discharged' and duty[0]['observed'][0]['coverage']==400 and closure[0]['observed']=='PERMIT'
 summary[backend]=dict(current=current,mutant=broken,source_discrepancies=3,wrong_discharge_and_permit_closure_verified=True,restored_identically=True)
# Preserve this task's free scripted output directory intact.
text=(run/'scripted.log').read_text();paths=re.findall(r'Saved to (results/[^\n]+)',text);assert len(paths)==1
original=root/paths[0];moved=run/'scripted-results'/original.name;moved.parent.mkdir(exist_ok=True)
if original.exists():shutil.move(str(original),str(moved))
assert moved.is_dir()
out=root/'docs/process/evidence/gateway-pr31-overlap';out.mkdir(exist_ok=True)
inputs={str(p.relative_to(run)):p for p in sorted(run.rglob('*')) if p.is_file()}
archive=out/'acceptance.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in inputs.items():z.writestr(name,p.read_bytes())
manifest={name:sha(p) for name,p in inputs.items()}
with zipfile.ZipFile(archive) as z:assert all(hashlib.sha256(z.read(name)).hexdigest()==digest for name,digest in manifest.items())
report=dict(scope='Claude PR31 conditional approval; one sensitive companion scenario, no production/expected-source changes.',reviewed_base='6526bccdc707289cea9a54177045b2d9678975bf',tests=dict(methods=1098,existing_optional_skips=36,failures=0,errors=0,seconds=float(match[2])),new_scenario=dict(scenarios_per_backend=1,source_assertions_per_backend=15,backends=summary),unchanged_counts=checks,acceptance_commands=load(run/'acceptance-steps.json'),scripted_exit=0,frozen_zip_sha256=sha(root/'tests/expected_traces/v0.2.2/taa_expected_traces_v0.2.2.zip'),archive=dict(path=str(archive.relative_to(root)),sha256=sha(archive),files=manifest),attempt_note='Original wrong SQL mutation-patch use site and interrupted obsolete discovery retained, not credited as passing acceptance.')
(out/'validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(tests=report['tests'],new=summary,unchanged_comparisons=15,archive_bytes=archive.stat().st_size),indent=2))
