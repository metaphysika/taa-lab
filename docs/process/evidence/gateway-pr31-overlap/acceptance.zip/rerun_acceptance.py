from pathlib import Path
import json,os,subprocess,time
root=Path('/workspace/taa-gateway-v032');out=Path('/workspace/scratch/gateway-pr31-overlap');rows=[]
env=dict(os.environ,HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
commands=[('reference','-m tests.trace_support.reference_runner'),('regressions','-I scripts/check_gateway_spot_review.py'),('production','-I scripts/check_gateway_stage5.py --require-complete'),('conventional','-I scripts/check_conventional_w0.py')]+[(n,'-I scripts/check_gateway_v032.py --suite '+n) for n in ('q14','q15','q16')]
for name,cmd in commands:
 command=['/workspace/scratch/gateway-py311/bin/python',*cmd.split(),'--report',str(out/(name+'.json'))];start=time.monotonic()
 with (out/(name+'.log')).open('w') as f:code=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
 rows.append(dict(name=name,command=command,exit=code,seconds=round(time.monotonic()-start,3)));(out/'acceptance-steps.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(json.dumps(rows[-1]),flush=True)
 if code:raise SystemExit(code)
with (out/'scripted.log').open('w') as f:code=subprocess.run(['/workspace/scratch/gateway-py311/bin/python','run.py','--scenario','all'],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
(out/'scripted.exit').write_text(str(code)+'\n');raise SystemExit(code)
