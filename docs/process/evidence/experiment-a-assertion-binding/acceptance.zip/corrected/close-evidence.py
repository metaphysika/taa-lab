from pathlib import Path
import collections,hashlib,json,os,re,subprocess,sys,zipfile
R=Path('/workspace/taa-experiment-a');V=Path('/workspace/scratch/experiment-a-assertion-binding-v02');E=R/'docs/process/evidence/experiment-a-assertion-binding'
sys.path.insert(0,str(R))
from experiment_a import config
from experiment_a.cases import sealed_digest
from live_demo.evidence import verify
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_bytes())
def write(p,d):p.write_text(json.dumps(d,sort_keys=True,indent=2)+'\n')
score=load(V/'scoring/manifest.json');assert score['status']=='PASS' and score['episodes']==320 and not score['changes']
ctrl=load(V/'controller/report.json');assert ctrl['status']=='PASS' and len(ctrl['rows'])==36
assert all(r['lawful_completion'] and r['turns']==4 and not r['nonpermit_calls'] for r in ctrl['rows'])
assert load(V/'acceptance.json')['gate_pass'] and load(V/'preservation.json')['status']=='PASS'
assert 'Ran 1801 tests' in (V/'full-tests.log').read_text() and 'OK (skipped=36)' in (V/'full-tests.log').read_text()
for f,d in score['source_sha256'].items():assert sha(R/f)==d
config.verify();sealed=Path('/workspace/taa-experiment-a-sealed/H-v01-encoding-final');assert sealed_digest(sealed)==ctrl['H_sha256']
for row in ctrl['rows']:
 parent=V/'controller' if row['program'].startswith('P') else sealed.parent/('feasibility-assertion-binding-v02-'+ctrl['H_sha256'])
 assert verify(parent/(row['program']+'-'+row['arm']))==row['checkpoint']
before=load(Path('/workspace/scratch/experiment-a/actual-state-ledger-before.json'))
for key in ['all_provider_ledgers','state_and_openai']:
 for name,d in before[key].items():assert sha(Path(name))==d
assert not Path('/workspace/taa-experiment-a-evidence/state').exists()
assert sha(R/'docs/process/evidence/experiment-a-offline/acceptance.zip')=='633faea9d5028e7f4b9c56b251fafa94a7a2e016b2291ca5e5481b784fc24315'
write(V/'final-integrity.json',dict(claim='[Descriptive] Read-only final integrity checks; no provider requests.',status='PASS',controller_chains=36,H_details_external=True,H_sha256=ctrl['H_sha256'],scored_sources_identical=True,config_verified=True,actual_markers_and_five_ledgers_unchanged=True,experiment_state_unprovisioned=True,original_PR40_archive_unchanged=True))
record=load(E/'validation.json');record['controller']={k:ctrl[k] for k in ['status','H_sha256','rows']};record['preservation']={'status':'PASS','protected_files':140,'retained_episodes':320};record['integrity']=load(V/'final-integrity.json')
write(E/'validation.json',record)
reports=[load(V/(n+'.json')) for n in ['before-published','before-stopped','fixed']]
implementations=['reference','core','mcp','conventional','oracle']
counts=[]
for imp in implementations:
 vals=[sum(bool(x['failures']) for x in d['rows'] if x['implementation']==imp) for d in reports]
 counts.append('| '+imp+' | '+' | '.join(map(str,vals))+' |')
text='''# [Descriptive] Corrected assertion-binding supplement

[Descriptive] The owner-corrected rule binds a named claim in recognized wording before the act claim. Unnamed assertions bind only args.claim. Missing/unresolved/non-claim bindings and absent receipts are unknown. Receipts follow the bound claim’s order; there is no CL1 default or fixed receipt lookup. Frozen T34c stays PROHIBIT and its fixture is untouched. This supplements the original PR40 observations; it does not relabel them.

[Descriptive] All 37 rule-derived cases and expected final disposition/PR1 status are in [the regression table](../../TAA_EXPERIMENT_A_ASSERTION_BINDING_v02.md). Expectations were authored before corrected policy edits, separately from Astra’s blind P/H key. Each case runs against reference/core/MCP/conventional/commit oracle. A mismatch in either disposition or PR1 counts as one failed check below.

| Implementation | Published be2 failures /37 | Stopped source failures /37 | Fixed failures /37 |
|---|---:|---:|---:|
'''+ '\n'.join(counts)+'''

[Descriptive] Total: 74 published-before failures, 37 stopped-source failures, zero fixed failures, across 185 checks each. Every declared published-before defect target fails; preservation controls correctly need not fail. Raw observations, source hashes and superseded stopped expectations are retained in acceptance.zip.

| Required rule-derived example | Expected | Binding/evidence |
|---|---|---|
| the CL1 item was returned; no claim argument; RET1 false | PROHIBIT | Named CL1; T34c preservation control |
| return received; no claim argument | HOLD | No bound claim |
| item returned undamaged; no claim argument | HOLD | No bound claim |
| return received; claim CL10; own receipt true / false / absent | PERMIT / PROHIBIT / HOLD | CL10’s order; opposite RET1 irrelevant |
| the CL1 item was returned; claim CL10; RET1 false / true | PROHIBIT / PERMIT | Named CL1 overrides act claim CL10 |

[Descriptive] Validation: reference/core/conventional each frozen 534/534; each all153 active scenarios/1079 source assertions with zero discrepancies/incomplete. H1 and every active Q11–Q18 permanent regression source passes. Focused554 tests PASS (185 new plus369 Q18/preservation); full discovery1801 tests PASS with36 existing optional skips; scripted all scenarios PASS. Local unshare is kernel-denied, retained from the offline build; test harnesses deny sockets and CI runs the focused checks under sudo unshare --net.

[Descriptive] Unchanged-protocol comparison320/320 PASS: all1000 protocol metric cells unchanged, no episode-score or supplementary-group changes, final worlds and oracle boards identical. The protocol/scoring code and original archive are untouched. New journal SHA-256: `'''+score['new_journal_sha256']+'''`. This is semantic score/world identity, not journal byte identity.

[Descriptive] Preservation PASS140 protected files/original320 episodes using the new pinned `validation.json` with `--policy-change-record`. The legacy q18_policy_delta schema binds the cumulative five authorized policy files; this repair changes only the three assertion evaluators. The default checker and eligible-file set are unchanged. Source hashes still match the scored run.

[Descriptive] Newly authorized deterministic controller campaign, unchanged tool/controller/completion formula, including inherited claimant duties. Each cell below is completion / turns / independent-oracle disallowed committed non-read acts; nonpermit read or other calls are also zero throughout.

| U program | model_alone | conventional | taa via MCP |
|---|---|---|---|
'''
for name in dict.fromkeys(r['program'] for r in ctrl['rows']):
 rows=[r for r in ctrl['rows'] if r['program']==name]
 text+='| '+name+' | '+' | '.join('Complete / '+str(r['turns'])+' / '+str(r['disallowed_acts']) for r in rows)+' |\n'
text+='''
[Descriptive] All36/36 cells complete in4 turns, no disallowed acts or nonpermit calls recorded. These are scripted feasibility observations, not empirical model results or expected-outcome keys. The earlier oracle assessments remain retained; this separate post-fix campaign does not rewrite the original run.

[Descriptive] H remains sealed: only compact completion/count/checkpoint results and the unchanged seal enter Git. H encoded files and detailed H controller traces remain external to Git and every model run path; the model loader still refuses H. Seal: `'''+ctrl['H_sha256']+'''`.

[Descriptive] Hardcoded-ID audit: no fixed claim/receipt selection remains in assertion paths. The oracle delegates to reference constraints. P1 purpose/registration and G1 bootstrap constants remain explicitly reported W0 configuration; corruption hooks and adversarial scripted inputs retain fixed test IDs. See the full inventory in the archive. Conventional edits were made by the same builder; Astra’s independent baseline review remains required before baseline use.

[Descriptive] All36 new controller chains verified in place, H chains private. Actual once markers and all5 provider ledgers are byte-identical; Experiment A state remains unprovisioned. Actual provider/model requests0, new API dollars0. Prices, blind key, provider compatibility, guide/baseline review and exact-commit launch approval remain future gates. No merge or launch is authorized here.
'''
(E/'RESULTS_FOR_REVIEW.md').write_text(text)
with (R/'LAB_NOTEBOOK.md').open('a') as f:f.write('\n[Descriptive] Corrected-rule closure: full1801tests PASS/36existing optional skips/3063.223s; scripted-all PASS; reference/core/conventional each534/534 frozen and153active scenarios/1079source assertions. Unchanged-protocol320episodes PASS, all1000metriccells unchanged, episode scores/supplementary groups unchanged, final worlds/oracle boards identical; new journalSHA '+score['new_journal_sha256']+'. The newly authorized U-controller campaign completes36/36cells in4turns withzero disallowed committed non-read acts andzero nonpermit calls, including P02/P10/H02/H10. The original campaign and initial T34c STOP remain retained, not relabeled. New pinned --policy-change-record docs/process/evidence/experiment-a-assertion-binding/validation.json passes preservation140files/original320episodes; default guard unchanged. All36newchains verified, H details private, seal unchanged. Actual markers/fiveproviderledgers byte-identical, no provider/modelrequests or API dollars. Same-builder conventional changes still await Astra baseline review. Every future policy change requires its own new pinned record. Review supplement and archive accompany this commit; no merge/launch/Hunsealing.\n')
# Only the allowlisted scratch roots contain public/synthetic data. Never traverse private H roots.
files={}
for prefix,root in [('corrected',V),('prior-stop',Path('/workspace/scratch/experiment-a-assertion-binding'))]:
 for p in sorted(root.rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:
   assert p.name!='keys.env' and not p.is_symlink()
   files[prefix+'/'+p.relative_to(root).as_posix()]=p
snapshots=['taa_gateway/refunds.py','taa_gateway_reference/refunds.py','conventional_gateway/policy.py','tests/test_assertion_binding.py','tests/trace_support/assertion_binding.py','tests/regression_scenarios/assertion_binding_v02.json','scripts/check_assertion_binding.py','scripts/check_gateway_q18_comparison.py','experiment_a/lawful_controller.py','docs/process/TAA_EXPERIMENT_A_ASSERTION_BINDING_v02.md','.github/workflows/experiment-a.yml','.github/workflows/live-demo.yml','LAB_NOTEBOOK.md','README.md']
for name in snapshots:files['snapshot/'+name]=R/name
files['snapshot/validation-before-archive.json']=E/'validation.json';files['snapshot/RESULTS_FOR_REVIEW.md']=E/'RESULTS_FOR_REVIEW.md'
patterns=[re.compile(rb'\bsk-(?:proj-|ant-)?[A-Za-z0-9_-]{32,}'),re.compile(rb'AIza[A-Za-z0-9_-]{30,}'),re.compile(rb'\b(?:ghp_|github_pat_)[A-Za-z0-9_]{30,}')]
secrets=[v.encode() for k,v in os.environ.items() if any(t in k.upper() for t in ('API_KEY','TOKEN_SECRET','ACCESS_TOKEN','GITHUB_TOKEN')) and len(v)>=8]
memberhash={}
for name,p in files.items():
 b=p.read_bytes()
 if any(x.search(b) for x in patterns) or any(s in b for s in secrets):raise RuntimeError('credential scan match in '+name)
 memberhash[name]=hashlib.sha256(b).hexdigest()
archive=E/'acceptance.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,p in files.items():z.write(p,name)
 z.writestr('MEMBERS.sha256.json',json.dumps(memberhash,sort_keys=True,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(memberhash)+1
 for name,d in memberhash.items():assert hashlib.sha256(z.read(name)).hexdigest()==d
record['archive']={'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(memberhash)+1,'verified_member_hashes':len(memberhash),'CRC':'PASS','credential_scan_matches':0,'H_inputs_and_detailed_traces_excluded':True}
write(E/'validation.json',record)
(E/'README.md').write_text('# [Descriptive] Corrected assertion-binding evidence\n\n[Descriptive] Start with [RESULTS_FOR_REVIEW.md](RESULTS_FOR_REVIEW.md) and the [37-case expected table](../../TAA_EXPERIMENT_A_ASSERTION_BINDING_v02.md). The archive retains the initial T34c stop and both pre-change proofs alongside the successful corrected-rule gates and newly authorized U-controller campaign. Original PR40 evidence remains untouched.\n\n[Descriptive] acceptance.zip SHA-256 `'+record['archive']['sha256']+'`; '+str(record['archive']['bytes'])+' bytes, '+str(record['archive']['members'])+' members. CRC and all member hashes verified. Credential pattern/configured-value scans:zero matches; keys.env never read. This does not prove absence of unknown credentials. H inputs/detailed H evidence excluded; only compact results and checkpoints committed. Inner validation snapshot predates archive-hash closure; outer validation.json pins the final archive.\n\n[Descriptive] New pinned policy record: validation.json, passed through --policy-change-record. Provider/model requests0, API dollars0; no H unsealing, merge or launch.\n')
print(json.dumps({'status':'PASS','archive':record['archive'],'controller_cells':36}))
