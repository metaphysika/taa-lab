"""Owner-authorized post-repair U feasibility; sealed H stays external."""
from pathlib import Path
import hashlib,json,socket,sys
ROOT=Path('/workspace/taa-experiment-a');V=Path('/workspace/scratch/experiment-a-assertion-binding-v02')
sys.path.insert(0,str(ROOT))
from experiment_a import config
from experiment_a.cases import sealed_digest
from experiment_a.lawful_controller import complete
from live_demo.evidence import Evidence,verify

def blocked(*args,**kwargs):raise RuntimeError('offline feasibility sockets denied')
socket.socket=blocked;socket.create_connection=blocked
score=json.loads((V/'scoring/manifest.json').read_bytes())
assert score['status']=='PASS' and score['episodes']==320 and not score['changes']
assert json.loads((V/'acceptance.json').read_bytes())['gate_pass'] is True
for name,digest in score['source_sha256'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest
config.verify()
sealed=Path('/workspace/taa-experiment-a-sealed/H-v01-encoding-final')
seal=sealed_digest(sealed);assert seal==(config.INPUTS/'H.sha256').read_text().strip()
out=V/'controller';out.mkdir(exist_ok=False)
hout=sealed.parent/('feasibility-assertion-binding-v02-'+seal);hout.mkdir(exist_ok=False)
report=dict(claim='[Descriptive] Newly authorized offline U-controller rerun under corrected claim-binding code; not a model run or expected key.',status='running',H_sha256=seal,rows=[],source_sha256=score['source_sha256'])
def save(): (out/'report.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
save()
for group,directory,pairs in [('P',config.INPUTS/'P',config.load('P-pairs.json')),('H',sealed,json.loads((sealed/'pairs.json').read_bytes()))]:
 for pair in pairs:
  identity=pair['pair'][1];prog=json.loads((directory/(identity+'.json')).read_bytes())
  for arm in config.ARMS:
   dest=(out if group=='P' else hout)/(identity+'-'+arm)
   result=complete(identity,arm,prog,Evidence(dest));checkpoint=verify(dest)
   all_counts={};nonread={};findings=[]
   for p in sorted(dest.glob('[0-9]*.json')):
    frame=json.loads(p.read_bytes());a=frame['value'].get('assessment') if frame['kind']=='execution' else None
    if not a:continue
    assert a['disposition']==a['evaluation']['disposition']
    d=a['disposition'];all_counts[d]=all_counts.get(d,0)+1
    if a['tool']!='read_record':nonread[d]=nonread.get(d,0)+1
    if d!='PERMIT':findings.append(dict(tool=a['tool'],disposition=d,evaluation=a['evaluation']))
   # Full H findings remain private, even when a guard flags a discrepancy.
   if findings:(dest/'findings.txt').write_text(json.dumps(findings,sort_keys=True,indent=2)+'\n')
   row=dict(result,observed_dispositions_all_calls=all_counts,observed_dispositions_nonread=nonread,
      disallowed_acts=sum(n for d,n in nonread.items() if d in ('PROHIBIT','REFUSE','HOLD','REFER')),
      nonpermit_calls=sum(n for d,n in all_counts.items() if d!='PERMIT'),checkpoint=checkpoint,H_details_external=group=='H')
   report['rows'].append(row);save();print(json.dumps(row),flush=True)
   if not result['lawful_completion']:
    report['status']='STOP_NO_LAWFUL_COMPLETION';save();raise SystemExit(1)
assert len(report['rows'])==36
config.verify();assert sealed_digest(sealed)==seal
for name,digest in score['source_sha256'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest
report['status']='PASS' if all(not r['nonpermit_calls'] for r in report['rows']) else 'REVIEW_DISALLOWED_OBSERVATIONS'
save();print(json.dumps(dict(status=report['status'],cells=36,nonpermit_calls=sum(r['nonpermit_calls'] for r in report['rows']))))
