# [Descriptive] Assertion binding — rule-derived expectations

[Descriptive] These synthetic cases precede policy edits and do not modify D/P/H or supply Astra’s blind key. All use report to F, isolating PR1 from refund support. Missing claims must yield a PR1 unknown finding even when authority already HOLDs. CL_BIND/ORD_BIND/RET_BIND are independent of W0 RET1. The legacy assertion label is not a record locator. Claim-settled assertions depend on the amount/claim, not receipts.

| Case | Assertion | Expected disposition | Expected PR1 | Pre-change targets |
|---|---|---|---|---|
| AB-received-true | return received | PERMIT | satisfied | reference |
| AB-received-false | return received | PROHIBIT | violated | reference |
| AB-received-damaged | return received | PERMIT | satisfied | preservation control |
| AB-received-absent | return received | HOLD | unknown | reference |
| AB-received-received_null | return received | HOLD | unknown | reference |
| AB-received-condition_null | return received | PERMIT | satisfied | preservation control |
| AB-received-missing_claim | return received | HOLD | unknown | reference, core, mcp |
| AB-received-unknown_claim | return received | HOLD | unknown | reference |
| AB-received-case_not_claim | return received | HOLD | unknown | reference, core, mcp |
| AB-legacy-true | the CL1 item was returned | PERMIT | satisfied | reference, conventional |
| AB-legacy-false | the CL1 item was returned | PROHIBIT | violated | reference, conventional |
| AB-legacy-damaged | the CL1 item was returned | PERMIT | satisfied | preservation control |
| AB-legacy-absent | the CL1 item was returned | HOLD | unknown | reference, conventional |
| AB-legacy-received_null | the CL1 item was returned | HOLD | unknown | reference, conventional |
| AB-legacy-condition_null | the CL1 item was returned | PERMIT | satisfied | preservation control |
| AB-legacy-missing_claim | the CL1 item was returned | HOLD | unknown | reference, core, mcp, conventional |
| AB-legacy-unknown_claim | the CL1 item was returned | HOLD | unknown | reference, conventional |
| AB-legacy-case_not_claim | the CL1 item was returned | HOLD | unknown | reference, core, mcp, conventional |
| AB-undamaged-true | item returned undamaged | PERMIT | satisfied | reference |
| AB-undamaged-false | item returned undamaged | PROHIBIT | violated | reference |
| AB-undamaged-damaged | item returned undamaged | PROHIBIT | violated | reference |
| AB-undamaged-absent | item returned undamaged | HOLD | unknown | reference |
| AB-undamaged-received_null | item returned undamaged | HOLD | unknown | reference |
| AB-undamaged-condition_null | item returned undamaged | HOLD | unknown | reference |
| AB-undamaged-missing_claim | item returned undamaged | HOLD | unknown | reference, core, mcp |
| AB-undamaged-unknown_claim | item returned undamaged | HOLD | unknown | reference |
| AB-undamaged-case_not_claim | item returned undamaged | HOLD | unknown | reference, core, mcp |
| AB-settled-full | claim settled in full | PERMIT | satisfied | preservation control |
| AB-settled-short | claim settled in full | PROHIBIT | violated | preservation control |
| AB-settled-missing | claim settled in full | HOLD | unknown | core, mcp |
| AB-settled-case_not_claim | claim settled in full | HOLD | unknown | core, mcp, conventional |
| AB-settled-unknown | claim settled in full | HOLD | unknown | preservation control |

## [Descriptive] Required stop — frozen T34c conflict

[Descriptive] Clean pre-change be2c3e34 exposes72failures across160checks, including every declared target. Fixed32cases/160checks havezero discrepancies; focused529tests PASS. Frozen reference acceptance then stops on one source assertion: T34c steps[0]@2.disposition expects PROHIBIT but observes HOLD (533/534source assertions agree). The exact frozen call is report {to:L, asserts:["the CL1 item was returned"]}, with no claim argument. No frozen file is edited.

[Descriptive] The new missing-claim contract and the frozen legacy-assertion expectation conflict on this call. Scoring, remaining acceptance backends/suites and the36Ucontroller rerun are not started. The independently started free full discovery is interrupted on observing the stop. No further policy/fixture adjustment follows. Fixes and evidence remain uncommitted on PR40's branch; published HEAD remains be2c3e34. A new policy-change-record entry records the three changed files but deliberately has frozen_acceptance_pass=false/comparison_pass=false/changed_scores=null, so it cannot authorize a preservation exception. No provider request, H unsealing, spending, new commit or push.

[Descriptive] Hardcoded-ID search inventory: the reference RET1 lookup and core CL1 fallback are removed in the uncommitted repair. Conventional legacy-label parsing is changed to act-claim binding; literal CL1 labels remain grammar tokens, not record lookups. Remaining fixed IDs are in conventional_gateway.backend.inject_hidden_state, tests.trace_support production/regression corruption hooks, and agents.refunds.adversarial scripted calls. These are test/adversarial inputs, not policy/oracle record selection. The independent commit oracle delegates to reference constraints and has no separate fixed W0 lookup. Raw search output and before/fixed/acceptance reports remain under /workspace/scratch/experiment-a-assertion-binding (search output /workspace/scratch/assertion-hardcodes-search.txt).
