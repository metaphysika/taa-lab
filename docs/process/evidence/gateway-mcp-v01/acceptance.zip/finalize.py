from pathlib import Path
import hashlib,json,re,subprocess,zipfile
root=Path('/workspace/taa-comparison-v02');prep=Path(__file__).parent
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ('discovery','scripted','components','acceptance'):assert (prep/(name+'.exit')).read_text().strip()=='0',name
log=(prep/'discovery.log').read_text();n=re.findall(r'Ran (\d+) tests in ([\d.]+)s',log);assert n and int(n[-1][0])==1121,n
r=load(prep/'acceptance.json');assert r['gate_pass'];totals={k:sum(s['counts'][k] for s in r['suites'].values()) for k in ('scenarios','source_assertions','state_audits','checks','discrepancies','incomplete')}
assert totals==dict(scenarios=140,source_assertions=1062,state_audits=3907,checks=4972,discrepancies=0,incomplete=0)
assert all(c['status']=='pass' for c in r['suites']['permanent-regressions']['negative_controls'])
preserved=load(Path('/workspace/scratch/comparison-v02/preservation.json'));assert all(sha(root/p)==h for p,h in preserved.items())
out=root/'docs/process/evidence/gateway-mcp-v01';out.mkdir(exist_ok=False)
files={p.name:p for p in prep.iterdir() if p.is_file() and p.suffix in ('.json','.log','.exit','.py') and p.name!='finalize.log'}
for name in ['taa_gateway/mcp_server.py','tests/trace_support/mcp_backend.py','tests/test_gateway_mcp.py','scripts/check_gateway_mcp.py']:
 files['source/'+name]=root/name
hashes={name:sha(p) for name,p in files.items()};archive=out/'acceptance.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in files.items():z.write(p,name)
 z.writestr('MANIFEST.sha256',''.join(h+'  '+name+'\n' for name,h in hashes.items()))
with zipfile.ZipFile(archive) as z:assert all(hashlib.sha256(z.read(name)).hexdigest()==h for name,h in hashes.items())
validation=dict(version='0.1',comparison_base='74c5b0a0f77d3b8709ba7ffe43b2f502f0f756cc',counts=totals,hidden_state_controls_detected=3,
 component_methods=7,repository_tests=1121,repository_optional_skips=36,repository_seconds=float(n[-1][1]),repository_exit=0,scripted_exit=0,
 source_sha256={name:sha(root/name) for name in ['taa_gateway/mcp_server.py','tests/trace_support/mcp_backend.py','tests/test_gateway_mcp.py','scripts/check_gateway_mcp.py']},
 preserved_scoring=preserved,archive=dict(path=str(archive.relative_to(root)),sha256=sha(archive),bytes=archive.stat().st_size,files=hashes),
 limits=['Scripted clients only; no live model.','Trusted host simulator Session, not remote OAuth/production authentication.','Core paths unchanged; W0 read_record remains an abstract empty effect.','Host log export at EOF; no durable restart claim.'])
(out/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
rows=['\n## Completed acceptance on the comparison-fix base\n',
'Full repository discovery passes **1,121 tests** (36 optional skips), and scripted scenarios pass. Seven component methods pass. The real subprocess test follows the dynamically returned token across stdin/stdout and retains a native log/checkpoint; it makes no model call.\n',
'| Suite | Scenarios | Source assertions | State audits | Discrepancies | Incomplete |','|---|---:|---:|---:|---:|---:|']
for name,s in r['suites'].items():
 c=s['counts'];rows.append('| '+name+' | '+' | '.join(str(c[k]) for k in ('scenarios','source_assertions','state_audits','discrepancies','incomplete'))+' |')
rows+=['', '**Total: 140 scenarios, 1,062 source assertions, 3,907 state audits and 4,972 checks, including all three detected hidden-state controls; 0 discrepancies and 0 incomplete items.** These are engineering checks, not model trials or H3 validation.\n',
'[Validation and source hashes](evidence/gateway-mcp-v01/validation.json) and acceptance.zip retain the full checks and negative-control observations. Frozen fixtures, all v0/v0.1 scoring records and the runtime’s decision/transaction/duty code remain unchanged. Claude review and green CI are required before merge. No launch, model connection, spending or public release is approved.\n']
p=root/'docs/process/TAA_GATEWAY_MCP_v01.md';p.write_text(p.read_text().replace('head74c5b0a0','head `74c5b0a0`').replace('No live client is connected','No live model client is connected')+'\n'.join(rows))
p=root/'LAB_NOTEBOOK.md';p.write_text(p.read_text()+'''\n\n## 2026-10-24 — offline MCP front v0.1, comparison-fix integration\n\nThin stdio MCP exposes proposals, explicit execution/withdrawal and the existing session event rows through the authenticated host-selected Session. No decision, authorization, discharge or transaction code is replaced. No host write/reviewer/clock/fault endpoint is exposed. Full 1,121 tests pass (36 optional skips), scripted scenarios pass, and the common runner records 140 scenarios, 1,062 source assertions, 3,907 state audits and 4,972 checks with 0 discrepancies/incomplete items; all 3 hidden-state controls are detected. Includes the two comparison-review traces, unchanged frozen fixtures and all permanent Q/H1 acceptance. Evidence: TAA_GATEWAY_MCP_v01.md and evidence/gateway-mcp-v01/. No model calls, Modal, spending, deletion or launch.\n''')
subprocess.run(['git','diff','--check'],cwd=root,check=True)
assert subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()=='feat/gateway-mcp-front-v032'
subprocess.run(['git','add','.github/workflows/gateway.yml','README.md','LAB_NOTEBOOK.md','docs/process/TAA_GATEWAY_MCP_v01.md','docs/process/evidence/gateway-mcp-v01','scripts/check_gateway_mcp.py','taa_gateway/mcp_server.py','tests/test_gateway_mcp.py','tests/trace_support/mcp_backend.py'],cwd=root,check=True)
subprocess.run(['git','commit','-m','Add offline authenticated-session MCP front and scripted acceptance'],cwd=root,check=True)
(prep/'head.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True))
print(json.dumps(dict(totals=totals,repository_tests=1121,archive_bytes=archive.stat().st_size),indent=2))
