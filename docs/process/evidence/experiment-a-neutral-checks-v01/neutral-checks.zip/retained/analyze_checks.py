from pathlib import Path
import base64,hashlib,json,sys
R=Path('/workspace/taa-experiment-a-check-7ec90c71');sys.path.insert(0,str(R))
from live_demo.evidence import verify,encoded
E=Path(__file__).parent;S=Path('/workspace/taa-experiment-a-evidence/state');A=Path('/workspace/taa-lab/results/formation-spending-v021')
rows=[]
for provider,name in [('anthropic','claude.json'),('google','google.json')]:
 root=E/(provider+'-attempt-1');checkpoint=verify(root)
 frames=[json.loads(p.read_bytes()) for p in sorted(root.glob('[0-9]*.json'))]
 requests=[f['value'] for f in frames if f['kind']=='request']
 replies=[json.loads(base64.b64decode(f['value']['base64'])) for f in frames if f['kind']=='native_reply']
 usages=[f['value'] for f in frames if f['kind']=='usage']
 failures=[f['value'] for f in frames if f['kind']=='transport_failure']
 carry=None;sig=False;thinking=False;formats=[]
 for reply in replies:
  content=reply.get('content',[]) if provider=='anthropic' else reply['candidates'][0]['content']['parts']
  sig|=any('thoughtSignature' in p or 'signature' in p for p in content)
  thinking|=any(p.get('type') in ('thinking','redacted_thinking') or p.get('thought',False) for p in content)
  formats.append([sorted(p) for p in content])
 if len(requests)==2 and replies:
  expected=dict(role='assistant',content=replies[0]['content']) if provider=='anthropic' else replies[0]['candidates'][0]['content']
  sent=requests[1]['body']['messages'][1] if provider=='anthropic' else requests[1]['body']['contents'][1]
  carry=encoded(expected)==encoded(sent)
 closure=frames[-1]['value']
 row=dict(provider=provider,stop=closure['stop'],returned_model=closure.get('model_returned'),requests=len(requests),replies=len(replies),finish_reasons=[r.get('stop_reason') if provider=='anthropic' else r['candidates'][0]['finishReason'] for r in replies],
 native_usage=[r.get('usage') if provider=='anthropic' else r.get('usageMetadata') for r in replies],thinking_blocks=thinking,signature_returned=sig,unchanged_on_second_request=carry,part_field_formats=formats,
 usage_charge=sum(float(u['charged']) for u in usages),retained_reservations=[f['retained_reserve'] for f in failures],errors=[dict(status=f['status'],**(f.get('error') or {})) for f in failures],
 provider_total_after=str(json.loads((A/name).read_bytes())['estimated_api_dollars']),evidence=str(root),checkpoint=checkpoint)
 rows.append(row)
report=dict(claim='[Descriptive] Exactly one approved neutral attempt/provider; no retry/pilot.',approved_commit='7ec90c71811acc54f92508e3995fc2c67bac6639',rows=rows,step_total_after=S.joinpath('step-budget.txt').read_text().strip())
(E/'check-summary.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps(report,indent=2))
