"""Conditional pilot arithmetic from retained live usage; never a model run."""
from pathlib import Path
from decimal import Decimal as D
from collections import defaultdict
import csv,hashlib,json,zipfile
R=Path('/workspace/taa-experiment-a');E=Path(__file__).parent
source=R/'studies/live-demo-03131469-review';guide=json.loads((E/'guide-token-proxies.json').read_bytes())
rows=list(csv.DictReader((source/'per-episode.csv').open()))
turns=defaultdict(list);current=None
with zipfile.ZipFile(source/'full-evidence.zip') as z:
 for name in sorted(n for n in z.namelist() if n.startswith('original/evidence/') and len(n.split('/'))==3 and n.rsplit('/',1)[1][:1].isdigit() and n.endswith('.json')):
  f=json.loads(z.read(name))
  if f['kind']=='request':
   v=f['value'];current=(v['spec']['program'],v['spec']['arm'],v['spec']['repeat'])
  if f['kind']=='usage':turns[current].append(f['value']['native'])
projected=[]
for row in rows:
 key=(row['program'],row['arm'],1);native=turns[key]
 assert sum(u['prompt_tokens'] for u in native)==int(row['input_tokens'])
 assert sum(u['completion_tokens'] for u in native)==int(row['output_tokens'])
 assert len(native)==int(row['turns'])
 first=native[0]['prompt_tokens'];assert all(u['prompt_tokens']>=first for u in native)
 projected.append(dict(episode=row['episode'],program=row['program'],arm=row['arm'],turns=len(native),input_tokens=int(row['input_tokens']),visible_output_tokens=int(row['output_tokens']),initial_prefix_tokens=first,per_turn_input=[u['prompt_tokens'] for u in native],per_turn_output=[u['completion_tokens'] for u in native]))
prices=json.loads((R/'experiment_a/inputs/prices.json').read_bytes());scale=D(198)/30

def costs(provider,g,ratio=None,ceiling=False):
 rates=prices[provider]['rates'];rate=lambda n:D(rates[n+'_per_million'])
 totals={n:D(0) for n in ['disabled','no_hits','first_cold_then_prefix_hits']}
 for row in projected:
  t=row['turns'];p=D(row['initial_prefix_tokens']+g);i=D(row['input_tokens']+g*t)
  output=D(t*32768) if ceiling else D(row['visible_output_tokens'])*(1+ratio)
  out=output*rate('output')
  write=rate('cache_write_5m') if provider=='anthropic' else rate('input')
  totals['disabled']+=i*rate('input')+out
  totals['no_hits']+=(i-p*t)*rate('input')+p*t*write+out
  totals['first_cold_then_prefix_hits']+=(i-p*t)*rate('input')+p*write+p*(t-1)*rate('cache_read')+out
 return {n:str(v*scale/1000000) for n,v in totals.items()}
result=dict(claim='[Interpretive] Pilot projection anchored to actual 30-episode live usage, not synthetic stand-in usage or a performance prediction.',
 source=dict(csv_sha256=hashlib.sha256((source/'per-episode.csv').read_bytes()).hexdigest(),archive_sha256=hashlib.sha256((source/'full-evidence.zip').read_bytes()).hexdigest(),episodes=30,turns=sum(r['turns'] for r in projected),input_tokens=sum(r['input_tokens'] for r in projected),visible_output_tokens=sum(r['visible_output_tokens'] for r in projected)),
 pilot_episodes_per_provider=198,scale=str(scale),guide=guide,
 observed_ratios=dict(google=dict(first='58/16 = 3.625',second='17/8 = 2.125',aggregate='75/24 = 3.125'),anthropic=None),
 google=dict(low=costs('google',533,D('2.125')),high=costs('google',536,D('3.625')),central=costs('google',533,D('3.125'))),
 anthropic=dict(status='No empirically calibrated thinking range: approved attempt failed401 before model reply.',visible_only_floor=costs('anthropic',533,D(0)),borrowed_google_ratio_sensitivity=costs('anthropic',536,D('3.125')),output_ceiling_envelope=costs('anthropic',536,ceiling=True)),
 assumptions=['Every historical episode contributes its actual input/output and turn count; extrapolate30 to198 by6.6, not20-token fixtures.',
 'Add guide proxy533–536 tokens to EVERY turn. These are offline o200k/cl100k counts, not exact native Anthropic/Gemini counts; UTF8 fallback bound2536 recorded separately.',
 'Live source uses Luna/floor/static/TAA and old D programs; pooled usage is an engineering anchor, not conventional-arm behavior or a forecast for new P cases/providers.',
 'No-hit caching charges the initial stable-prefix writes each turn for Sonnet; Google misses use normal input. Hit scenario has first turn cold, later same-episode initial-prefix hits; growing history stays ordinary input. No cross-episode cache savings assumed.',
 'Google thinking/visible ratios are from only2neutral replies; multiplying historical visible output by1+ratio assumes visible lengths/turns transfer. Hidden-signature/input-tokenization/history changes are not measured.',
 'Sonnet ratio is unavailable. Borrowed-Google sensitivity is explicitly not observed Sonnet behavior. Ceiling envelope assumes same historical turns each returning32768totaloutputtokens; it would exceed caps and stop before pilot completion, not authorize spending.',
 'All pilot-only projections exclude already-booked reservations/check costs and transport failures. Actual shared/provider caps remain controlling.'])
(E/'live-count-projection.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
(E/'live-count-episodes.json').write_text(json.dumps(projected,sort_keys=True,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['source','google','anthropic']},indent=2))
