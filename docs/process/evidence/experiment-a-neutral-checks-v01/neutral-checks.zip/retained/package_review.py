from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,sys,zipfile
R=Path('/workspace/taa-experiment-a');E=Path(__file__).parent;D=R/'docs/process/evidence/experiment-a-neutral-checks-v01';S=Path('/workspace/taa-experiment-a-evidence/state')
sys.path.insert(0,str(R))
from experiment_a import config
from experiment_a.cases import sealed_digest
from live_demo.adapter import Stop
from live_demo.evidence import verify
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
config.verify()
try:config.launch_ready()
except Stop as e:assert e.reason=='experiment_review_pending'
else:raise AssertionError('pilot gate opened')
assert 'Ran 245 tests' in (E/'review-metadata-focused.log').read_text() and '\nOK\n' in (E/'review-metadata-focused.log').read_text()
assert json.loads((E/'preservation-after-metadata.json').read_bytes())['status']=='PASS'
# Retain only this newly generated free scenario folder, never an actual check/marker.
log=(E/'scripted-all-after-metadata.log').read_text();name=re.findall(r'Saved to (results/[^\n]+)',log)[-1].strip().rstrip('/')
p=R/name;assert p.name=='20261026-120632-scripted';assert p.is_dir();p.rename(E/'scripted-validation')
h=S/'sealed/expected-key-H-astra-v01.md';h.chmod(0o600)
assert sha(h)==(config.INPUTS/'expected-key-H-astra-v01.sha256').read_text().strip()
assert sealed_digest(S/'sealed/H-v01-encoding-final')==(config.INPUTS/'H.sha256').read_text().strip()
public=(config.INPUTS/'expected-key-P-astra-v01.md').read_text();assert not re.search(r'\bH(?:0[1-9]|1[0-2])\b',public)
assert len(re.findall(r'^\| \*\*P\d\d ',public,re.M))==12
summary=json.loads((E/'check-summary.json').read_bytes())
for row in summary['rows']:assert verify(Path(row['evidence']))==row['checkpoint']
markers={p.name:sha(p) for p in S.glob('*.once')};assert set(markers)=={'check-anthropic-000001.once','check-google-000001.once'}
assert not (S/'run.once').exists()
reviews=config.load('reviews.json');assert {k for k,v in reviews.items() if v=='pending'}=={'blind_expected_key','measures_astra_review'}
record=dict(claim='[Descriptive] Approved checks executed once; offline metadata/key storage/projection closure; no pilot.',status='PASS',approved_check_commit='7ec90c71811acc54f92508e3995fc2c67bac6639',checks=summary,projection=json.loads((E/'live-count-projection.json').read_bytes()),focused_tests=dict(run=245,seconds=95.599,status='PASS'),scripted_all='PASS',preservation=dict(status='PASS',protected_files=140,retained_episodes=320),runtime_code_changed=False,full_suite_at_approved_runtime=dict(run=1809,skipped=36,status='PASS'),reviews=reviews,keys=dict(public_P='experiment_a/inputs/expected-key-P-astra-v01.md',public_P_sha256=sha(config.INPUTS/'expected-key-P-astra-v01.md'),H_location=str(h),H_sha256=sha(h),H_contents_public=False,dataset_H_sha256=(config.INPUTS/'H.sha256').read_text().strip()),once_markers_unchanged_in_place=markers,pilot_started=False,provider_requests_after_checks=0)
D.mkdir(exist_ok=False)
for name in ['check-summary.json','live-count-projection.json','live-count-episodes.json','guide-token-proxies.json']:shutil.copyfile(E/name,D/name)
files={}
for p in sorted(E.rglob('*')):
 if p.is_file() and '__pycache__' not in p.parts:
  assert p.name!='keys.env' and not p.is_symlink();files['retained/'+p.relative_to(E).as_posix()]=p
# No H key/context, dataset, or state marker is traversed or copied.
for name in ['experiment_a/inputs/reviews.json','experiment_a/inputs/review-records.json','experiment_a/inputs/hashes.json','experiment_a/inputs/expected-key-P-astra-v01.md','experiment_a/inputs/expected-key-H-astra-v01.sha256','docs/process/TAA_EXPERIMENT_A_NEUTRAL_CHECKS_v01.md']:
 files['snapshot/'+name]=R/name
patterns=[re.compile(rb'\bsk-(?:proj-|ant-)?[A-Za-z0-9_-]{32,}'),re.compile(rb'AIza[A-Za-z0-9_-]{30,}'),re.compile(rb'\b(?:ghp_|github_pat_)[A-Za-z0-9_]{30,}')]
secrets=[v.encode() for k,v in os.environ.items() if any(t in k.upper() for t in ('API_KEY','TOKEN_SECRET','ACCESS_TOKEN','GITHUB_TOKEN')) and len(v)>=8]
hashes={}
for name,p in files.items():
 b=p.read_bytes()
 if any(t.search(b) for t in patterns) or any(s in b for s in secrets):raise RuntimeError('credential scan match in '+name)
 hashes[name]=hashlib.sha256(b).hexdigest()
zpath=D/'neutral-checks.zip'
with zipfile.ZipFile(zpath,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,p in files.items():z.write(p,name)
 z.writestr('MEMBERS.sha256.json',json.dumps(hashes,sort_keys=True,indent=2)+'\n')
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None
 for name,d in hashes.items():assert hashlib.sha256(z.read(name)).hexdigest()==d
record['archive']=dict(sha256=sha(zpath),members=len(hashes)+1,verified_member_hashes=len(hashes),CRC='PASS',credential_scan_matches=0,H_outcomes_and_inputs_excluded=True,once_markers_not_copied=True)
(D/'verification.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
(D/'README.md').write_text('# [Descriptive] Experiment A neutral checks and revised projection\n\n[Descriptive] [Review report](../../TAA_EXPERIMENT_A_NEUTRAL_CHECKS_v01.md), check-summary.json and verification.json record both approved attempts. Anthropic401, no retry; Google2requests complete. Native usage/finish/carry-over/checkpoint facts retained. The replacement projection uses actual live-demo episode/turn counts and explicit guide-token proxies; Sonnet thinking ratio is unobserved, so no empirical Sonnet range is claimed.\n\n[Descriptive] neutral-checks.zip SHA256 `'+record['archive']['sha256']+'`; CRC/all member hashes pass, credential scan zero matches. Raw H inputs/outcomes and once markers excluded; markers remain in canonical state. No keys.env access, new model/provider calls after checks, or pilot. Metadata/key-focused245tests, scripted scenarios and preservation pass; runtime implementation unchanged. Prior full1809tests/36skips at approved runtime remain the full-suite result.\n')
print(json.dumps(dict(status='PASS',archive=record['archive'],H_key_sha256=record['keys']['H_sha256'])))
