from pathlib import Path
import hashlib,json,re,subprocess,zipfile
import yaml
root=Path('/workspace/taa-gateway-v032');run=Path('/workspace/scratch/gateway-v032-final');ci=run/'ci'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def counts(rows):return dict(checks=len(rows),source_assertions=sum(r.get('origin')=='source' for r in rows),state_audits=sum(r.get('origin')=='state-audit' for r in rows),discrepancies=sum(r['status']=='discrepancy' for r in rows),incomplete=sum(r['status']=='incomplete' for r in rows))
assert (run/'broad-final.exit').read_text().strip()=='0'
broad=(run/'broad-final.log').read_text();m=re.search(r'Ran (\d+) tests in ([\d.]+)s',broad);assert m and int(m[1])==1097 and 'OK (skipped=36)' in broad
steps=load(ci/'steps.json');assert len(steps)==21 and all(x['exit']==0 for x in steps)
assert load(ci/'scripted.json')['exit']==0
assert all(sha(root/p)==h for p,h in load(run/'source-snapshot-final.json').items())
protected=['tests/expected_traces','comparators/contracts','agents/refunds','worlds/refunds/catalog.py','docs/process/TAA_CROSS_ARM_PROTOCOL_v0.md','tests/regression_scenarios/q11_q12.yaml','tests/regression_scenarios/q13.yaml','tests/regression_scenarios/astra_spot_check.yaml','tests/adversarial_scenarios/COVERAGE.json']
assert not subprocess.check_output(['git','diff','9135bcdb','--',*protected],cwd=root)
assert (root/'tests/regression_scenarios/q14.yaml').read_bytes()==(root/'docs/process/drafts/TAA_Q14_REGRESSIONS_DRAFT_v1.yaml').read_bytes()
prod=load(ci/'gateway-stage6-production.json');ref=counts(load(ci/'gateway-reference-v031.json')['assertions']);sql=load(ci/'conventional-w0.json');regref=load(ci/'gateway-spot-review-fixed.json')['counts']
assert ref==dict(checks=2238,source_assertions=534,state_audits=1704,discrepancies=0,incomplete=0)
assert prod['frozen']['counts']['source_assertions']==534 and prod['frozen']['counts']['state_audits']==1751
assert sql['results']['frozen']['source_assertions']==534 and sql['results']['frozen']['state_audits']==7539
assert regref['source_assertions']==218 and regref['state_audits']==647 and regref['detection_guards']==3
assert prod['regressions']['counts']['source_assertions']==218 and prod['regressions']['counts']['state_audits']==671
assert sql['results']['regression']['source_assertions']==218 and sql['results']['regression']['state_audits']==3090
new={};before={};sensitivity={}
assert all(r['exit']==0 for r in load(run/'baselines/steps.json'))
for suite in ('q14','q15','q16'):
 current=load(ci/('gateway-'+suite+'.json'));old=load(run/'baselines'/(suite+'.json'))
 assert current['gate_pass'] and old['gate_pass'] and current['source_sha256']==old['source_sha256']
 new[suite]={k:v['counts'] for k,v in current['backends'].items()};before[suite]={k:v['counts'] for k,v in old['backends'].items()}
 cases=yaml.safe_load((root/'tests/regression_scenarios'/(suite+'.yaml')).read_text());sensitivity[suite]={}
 for backend,v in current['backends'].items():
  assert not v['counts']['discrepancies'] and not v['counts']['incomplete'] and not v['errors']
  required={c['id'] for c in cases if not c.get('baseline_control') and backend in c.get('baseline_sensitive_backends',['reference','production','conventional'])}
  actual={r['trace'] for r in old['backends'][backend]['checks'] if r['status']=='discrepancy'}
  assert required<=actual,(suite,backend,required-actual)
  sensitivity[suite][backend]=dict(required=sorted(required),each_has_actual_discrepancy=True)
properties=load(ci/'gateway-properties.json');assert properties['counts']['mutants_detected']==6 and not properties['gate_errors']
oracle=load(ci/'gateway-q14-oracle.json');assert len(oracle['results'])==72 and not oracle['errors']
for file in (ci/'gateway-q14-receipts.json',run/'baselines/q14-receipts.json'):assert load(file)['gate_pass']
arms=load(run/'all-arms.json');assert arms['gate_pass'] and not arms['coverage_complete']
sums={k:sum(g['counts'][k] for groups in arms['arms'].values() for g in groups.values()) for k in ('planned_scenarios','executed_scenarios','unavailable_scenarios','not_applicable_scenarios','discrepancies','incomplete','errors','observed_nonatomic_fault_audits','unexpected_discrepancies')}
assert sums['planned_scenarios']==1096 and sums['executed_scenarios']==961 and sums['unavailable_scenarios']==127 and sums['not_applicable_scenarios']==8
assert sums['discrepancies']==sums['observed_nonatomic_fault_audits']==4 and not sums['unexpected_discrepancies'] and not sums['errors'] and not sums['incomplete']
report=dict(scope='Design v0.3 + Clarifications v0.3.2 revision3.1/H1 engineering alignment candidate. No final scores, model calls, launch or merge approval.',base_commit='9135bcdb264be955aadff7fae79feead99137c01',tests=dict(methods=int(m[1]),seconds=float(m[2]),existing_optional_skips=36,failures=0,errors=0),current_workflow_commands=steps,local_command_note='Full discovery includes the duplicate component-only workflow set.21 other current workflow commands ran, plus all-arm input replay and4 new pinned baseline commands. Older checkout-only baseline steps remain enabled in CI and were not all repeated locally.',scripted=load(ci/'scripted.json'),frozen=dict(reference=ref,production=prod['frozen']['counts'],conventional=sql['results']['frozen']),permanent_regressions=dict(reference=regref,production=prod['regressions']['counts'],conventional=sql['results']['regression']),current=new,before=before,sensitivity=sensitivity,properties=properties['counts'],oracle_q14=dict(program_instances=72,errors=0),all_arm_replay=sums,tracegrant_coverage='Ten predeclared development tasks only.127 missing-contract replay instances remain unrun: original84 +9 Q15 +16 Q16 +18 Q14. No new contracts. Final scoring remains held.',business_faults='Four actual record/receipt audit discrepancies preserved, zero unexpected. Eight absent frozen T23 boundaries not applicable by design; six other T23 instances really executed, with actual state captured. Literal Q14 receipt faults are captured too; oracle admits no unreceipted notice.',supersessions={'R-Q11-authorized-standing':'R-Q16-authorized-without-capacity','R-Q12-parallel-L':'R-Q16-parallel-L'},source_snapshot=load(run/'source-snapshot-final.json'),frozen_zip_sha256=sha(root/'tests/expected_traces/v0.2.2/taa_expected_traces_v0.2.2.zip'))
old=load(root/'docs/process/evidence/gateway-pr28-rebase/validation.json')
report['cross_arm_fixture_only_source_delta']=load(run/'cross-arm-fixture-only-source-delta.json')
report['receipt_fixture_only_source_delta']=load(run/'receipt-fixture-only-source-delta.json')
report['historical_permanent_counts']=dict(reference=old['current_reference_regressions'],production=old['current_production_regressions'])
report['count_change_reason']='Only the two approved Q16 active-source substitutions change historical regression/derived counts. Q14 preserves the post-Q16 frozen and permanent counts. All original YAML is retained and unchanged.'
out=root/'docs/process/evidence/gateway-v032-final';out.mkdir(exist_ok=True)
archive_sources={}
for namespace,base in [('final',run),('pre-Q14',Path('/workspace/scratch/gateway-v032-q15-q16-final')),('Q15-Q16-diagnostics',Path('/workspace/scratch/gateway-v032-q15-q16')),('Q15-only-prefix',Path('/workspace/scratch/gateway-v032-q15')),('earlier-Q15-prefix',Path('/workspace/scratch/gateway-v032-q15-prefix'))]:
 for p in sorted(base.rglob('*')):
  if p.is_file() and p.suffix in ('.log','.json','.exit') and 'scripted-results' not in p.parts:archive_sources[namespace+'/'+str(p.relative_to(base))]=p
for pattern in ('q15-*.json','q15-*.log','q16-*.json','q16-*.log','q14-*.json','q14-*.log','q14-before.*','business-fault*.json','business-fault*.log','business-op-fault-before.log'):
 for p in Path('/workspace/scratch').glob(pattern):
  if p.is_file():archive_sources['retained-diagnostics/'+p.name]=p
for name in ('run_gates.py','run_baselines.py','resume_gates.py','package.py'):archive_sources['final/'+name]=run/name
for name in ('q14_draft_probe.py','resume_gates.py','mutant-adapter-only-source-delta.json','source-before-q14.zip'):
 archive_sources['pre-Q14/'+name]=Path('/workspace/scratch/gateway-v032-q15-q16-final')/name
archive_sources['retained-diagnostics/q14_receipt_before_after.py']=Path('/workspace/scratch/q14_receipt_before_after.py')
archive_sources['final/scripted-results.zip']=run/'scripted-results.zip'
archive=out/'acceptance.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in archive_sources.items():z.writestr(name,p.read_bytes())
manifest={n:sha(p) for n,p in archive_sources.items()}
with zipfile.ZipFile(archive) as z:assert all(hashlib.sha256(z.read(n)).hexdigest()==h for n,h in manifest.items())
report['archive']=dict(path=str(archive.relative_to(root)),sha256=sha(archive),bytes=archive.stat().st_size,files=manifest,attempt_note='Only completed final-source checks are acceptance. All interrupted prefixes, the failed5/6 mutation campaign, the1087/one-failure discovery, IR1 intermediate fixture attempt and Q14 authoring/prototype failures remain diagnostics. Pre-Q14 source reconstruction archive is included.')
(out/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(tests=report['tests'],commands=len(steps),replay=sums,archive_bytes=archive.stat().st_size),indent=2))
