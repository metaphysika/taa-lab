from pathlib import Path
import subprocess,os,json,time
root=Path('/workspace/taa-gateway-v032');out=Path('/workspace/scratch/gateway-v032-final/baselines');out.mkdir(exist_ok=True)
python='/workspace/scratch/gateway-py311/bin/python';env=dict(os.environ,HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
commands=[]
for suite in ('q14','q15','q16'):
 commands.append((suite,[python,'-I','scripts/check_gateway_v032.py','--suite',suite,'--implementation-root','/workspace/taa-gateway-v032-pre-q15','--expect-baseline','--report',str(out/(suite+'.json'))]))
commands.append(('q14-receipts',[python,'-I','scripts/check_gateway_q14_receipts.py','--implementation-root','/workspace/taa-gateway-v032-pre-q15','--expect-baseline','--report',str(out/'q14-receipts.json')]))
rows=[]
for name,command in commands:
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as f:code=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
 rows.append(dict(name=name,command=command,exit=code,seconds=round(time.monotonic()-start,3)));(out/'steps.json').write_text(json.dumps(rows,indent=2)+'\n')
 if code:raise SystemExit(code)
