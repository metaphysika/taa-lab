from pathlib import Path
import hashlib,json,os,subprocess,time,yaml
root=Path('/workspace/taa-gateway-v032');out=Path('/workspace/scratch/gateway-v032-final/ci');out.mkdir(exist_ok=True)
env=dict(os.environ,PATH='/workspace/scratch/gateway-py311/bin:'+os.environ['PATH'],HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',RUNNER_TEMP=str(out))
steps=yaml.safe_load((root/'.github/workflows/gateway.yml').read_text())['jobs']['reference-and-foundation']['steps'];results=[]
for step in steps:
 command=step.get('run','')
 if step.get('name','').startswith('Foundation, reference and runner'):continue
 if not command or 'pip install' in command or '--implementation-root' in command or 'cd gateway-pre' in command or 'check_gateway_all_arm_replay.py' in command:continue
 index=len(results);start=time.monotonic();log=out/f'{index:02}.log'
 with log.open('w') as f:code=subprocess.run(command,cwd=root,env=env,shell=True,executable='/bin/bash',stdout=f,stderr=subprocess.STDOUT).returncode
 row=dict(name=step.get('name'),command=command,exit=code,seconds=round(time.monotonic()-start,3),log=str(log),sha256=hashlib.sha256(log.read_bytes()).hexdigest());results.append(row)
 (out/'steps.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
 if code:raise SystemExit(code)
log=out/'scripted.log';start=time.monotonic()
with log.open('w') as f:code=subprocess.run(['python','run.py','--scenario','all'],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
(out/'scripted.json').write_text(json.dumps(dict(exit=code,seconds=round(time.monotonic()-start,3),sha256=hashlib.sha256(log.read_bytes()).hexdigest()),indent=2)+'\n')
raise SystemExit(code)
