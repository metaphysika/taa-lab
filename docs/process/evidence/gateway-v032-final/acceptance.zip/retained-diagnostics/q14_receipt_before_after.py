from pathlib import Path
from copy import deepcopy
import json,sys,yaml
implementation=Path(sys.argv[1]);sys.path.insert(0,str(implementation))
from comparators.business import Backend
from comparators.duty_oracle import Oracle
from tests.trace_support.bundle import world
setup=yaml.safe_load(Path('/workspace/taa-gateway-v032/docs/process/drafts/TAA_Q14_REGRESSIONS_DRAFT_v1.yaml').read_text())[0]['setup']
results=[]
for arm in ('floor','static'):
 b=Backend(arm);s=b.start(world(),setup)
 for args in [dict(claim='CL7',to='K2',template='refund_issued',amount=250,cites='REF1'),dict(claim='CL7',to='K2',template='refund_denied',amount=150,basis='DEL2')]:
  s,p=b.propose(s,'A','message_party',args);s,r=b.execute(s,'A',p['execution_intent'])
  assert r['execute_result']=='committed'
 original=deepcopy(s)
 probe=deepcopy(s);probe['receipts']=deepcopy(s['receipts'][:-1])
 o=Oracle(probe);o.clock(probe['step']);o.reconcile(probe)
 assert s==original
 observed=o.board()['D_resolve(CL7)']['resolution']
 results.append(dict(arm=arm,expected_correct='unresolved',observed=observed,
  desired_result_passes=observed=='unresolved',actual_notice_count=len(probe['notices']),actual_receipt_count=len(probe['receipts']),original=s,controlled_probe=probe))
Path(sys.argv[2]).write_text(json.dumps(dict(implementation_root=str(implementation),results=results),indent=2)+'\n')
print(json.dumps([{k:r[k] for k in ('arm','expected_correct','observed','desired_result_passes','actual_notice_count','actual_receipt_count')} for r in results]))
