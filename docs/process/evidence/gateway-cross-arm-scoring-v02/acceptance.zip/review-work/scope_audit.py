from copy import deepcopy
import json,sys
sys.path.insert(0,'/workspace/taa-comparison-v02')
from tests.trace_support.bundle import world
from tests.trace_support import production_backend as core
from taa_gateway_reference import refunds as reference
from conventional_gateway import backend as sql
args={'claim':'CL1','to':'K1','amount':120,'template':'refund_issued','cites':'REF1'}
base={'records':{'RET1':{'received':True},'REF1':dict(kind='refund',claim='CL1',claimant='K1',order='ORD1',amount=120,currency='USD',settled=True,to='K1_card')}}
rows=[]
for gid in ('G0','G1'):
 for name,b in [('reference',reference),('core',core),('conventional',sql)]:
  setup=deepcopy(base);setup['grants']={gid:{'scope':{'customers':['K1','K2'],'template':['refund_denied']}}}
  s=b.start(world(),setup);_,r=b.propose(s,'A','message_party',args)
  rows.append(dict(grant=gid,backend=name,disposition=r.get('disposition'),rule=r.get('rule')))
print(json.dumps(rows,indent=2))
