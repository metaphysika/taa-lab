#!/bin/bash
set -euo pipefail
prep=/workspace/scratch/comparison-v02
while [[ ! -f "$prep/run.exit" || ! -f "$prep/all-arm-replay.exit" ]]; do sleep 5; done
[[ $(cat "$prep/run.exit") == 0 ]]
[[ $(cat "$prep/all-arm-replay.exit") == 0 ]]
run=/workspace/scratch/gateway-cross-arm-scoring-v02
mkdir "$run/supplements"
cp "$prep/all-arm-replay.json" "$run/supplements/all-arm-replay.json"
cp "$prep/receiptless-faults-audited.json" "$run/supplements/receiptless-faults-audited.json"
/workspace/scratch/gateway-py311/bin/python "$prep/render_v02.py" /workspace/taa-comparison-v02 "$run" /workspace/scratch/gateway-cross-arm-scoring-v01-corrected > "$prep/render.log" 2>&1
