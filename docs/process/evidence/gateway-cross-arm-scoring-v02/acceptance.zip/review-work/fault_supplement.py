"""Outside-scoring receiptless-operation probes; keep actual states and audits."""
from pathlib import Path
import json,sys
sys.path.insert(0,str(Path(sys.argv[1]).resolve()))
from agents.refunds import CONTROLLERS
from comparators.business import Backend
from comparators.business_faults import BOUNDARIES,NOT_APPLICABLE
from comparators.cross_arm import Recorded
from tests.trace_support.bundle import world
from tests.trace_support.state_observations import effects,Observer
rows=[]
for arm in ('floor','static'):
 for tool,args in [('close_case',{'case':'CL1'}),('offer_duty',{'duty':'D_resolve(CL1)','to':'F'}),('accept_duty',{'duty':'D_resolve(CL1)'})]:
  for boundary in BOUNDARIES:
   b=Recorded(Backend(arm),CONTROLLERS['correct'](),{'trace':{'steps':[{'proposal_origin':['fault',0],'propose':{}}]}})
   s=b.start(world(),{'records':{'RET1':{'received':True}}});s=b.enter_step(s,1)[0];s,p=b.propose(s,'A',tool,args)
   before=s;observer=Observer(before);after,result=b.execute(s,'A',p['execution_intent'],boundary);call=b.calls[-1]
   audits=observer.audit('fault/'+arm+'/'+tool+'/'+boundary,before,after,result,agent=True,execute={'actor':'A','token':p['execution_intent']})
   assert all(r['status']=='pass' for r in audits),audits
   changed=bool(after['cases']!=before['cases'] or after['business_operations']!=before['business_operations'])
   rows.append(dict(arm=arm,tool=tool,boundary=boundary,result=result,before=before,after=after,actual_effects=effects(before,after),new_receipts=len(after['receipts'])-len(before['receipts']),actual_business_change=changed,receiptless_operation=call['receiptless_operation'],reference_policy_assessment=call['supplementary_assessment'],state_audits=audits,actual_transition=b.actual_transitions[-1],oracle_closures=b.oracle.closures,oracle_invalid_transfers=b.oracle.invalid_transfers))
   if changed and not after['receipts']:assert call['receiptless_operation'] is not None
out=Path(sys.argv[2]);out.write_text(json.dumps(dict(scope='Separate fault supplement, outside 320 episodes; no new TraceGrant contracts',rows=rows,not_applicable_by_design=NOT_APPLICABLE),sort_keys=True,separators=(',',':'))+'\n')
print(json.dumps(dict(probes=len(rows),receiptless_partial_operations=sum(r['receiptless_operation'] is not None for r in rows),state_audits=sum(len(r['state_audits']) for r in rows))))
