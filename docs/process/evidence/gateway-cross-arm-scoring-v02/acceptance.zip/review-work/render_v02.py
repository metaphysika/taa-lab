"""Report every existing metric and its v0.1 delta, without outcome interpretation."""
from pathlib import Path
import csv,hashlib,json,sys
root,run,oldrun=map(Path,sys.argv[1:]);out=run/'rendered';out.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text())
m=load(run/'manifest.json');assert m['status']=='completed';episodes=[json.loads(x) for x in (run/'episodes.jsonl').read_text().splitlines()];old=[json.loads(x) for x in (oldrun/'episodes.jsonl').read_text().splitlines()]
assert len(episodes)==len(old)==320
arms=m['arms'];controllers=m['controllers'];metrics=sorted(episodes[0]['metrics']);assert len(metrics)==25
scalar=[k for k in metrics if type(episodes[0]['metrics'][k]) is int];listkey='currently_closed_with_unresolved';assert len(scalar)==24
identity=lambda e:(e['case'],e['arm'],e['controller'])
previous={identity(e):e for e in old};assert set(previous)=={identity(e) for e in episodes}
labels={a:a for a in arms};labels.update(taa='TAA',without_admissibility='C1: without admissibility',without_invalidation='C2 primary: without invalidation',without_invalidation_reassessment_diagnostic='C2 diagnostic: reassessment retained',conventional='independently implemented conventional arm',tracegrant='TraceGrant reconstruction with fixed W0 contracts and documented adaptations')
def aggregate(es):
 return dict(episodes=len(es),metrics={k:sum(e['metrics'][k] for e in es) if k in scalar else {e['case']+'/'+e['controller']:e['metrics'][k] for e in es} for k in metrics},discrepancies=sum(e['discrepancies'] for e in es),incomplete=sum(e['incomplete'] for e in es),state_audits=sum(len(e['assertions']) for e in es),baseline_source_assertions=sum(r.get('origin')=='source' for e in es for r in e['key_acceptance']))
summary={a:aggregate([e for e in episodes if e['arm']==a]) for a in arms};by_controller={c:{a:aggregate([e for e in episodes if (e['arm'],e['controller'])==(a,c)]) for a in arms} for c in controllers}
oldsummary={a:aggregate([e for e in old if e['arm']==a]) for a in arms}
issues=[];unknown=[]
for e in episodes:
 ident={k:e[k] for k in ('case','arm','controller')}
 for channel in ('assertions','key_acceptance'):
  issues.extend(dict(ident,channel=channel,check=r) for r in e[channel] if r['status']!='pass')
 unknown.extend(dict(ident,observation_index=i,observation=r) for i,r in enumerate(e['observations']) if r['semantic_label'] is None)
assert len(unknown)==sum(e['metrics']['unassessed_actions'] for e in episodes)
diffs=[]
for a in arms:
 for k in metrics:
  before,after=oldsummary[a]['metrics'][k],summary[a]['metrics'][k]
  contributors=[dict(case=e['case'],controller=e['controller'],before=previous[identity(e)]['metrics'][k],after=e['metrics'][k]) for e in episodes if e['arm']==a and previous[identity(e)]['metrics'][k]!=e['metrics'][k]]
  diffs.append(dict(arm=a,metric=k,v01=before,v02=after,changed=before!=after,contributors=contributors))
assert len(diffs)==200
# Keep per-observation differences, including equal aggregate cells with offsets.
obsdiff=[]
for e in episodes:
 p=previous[identity(e)];assert len(p['observations'])==len(e['observations'])
 for i,(before,after) in enumerate(zip(p['observations'],e['observations'])):
  for field in ('context','semantic_label','committed','effects'):
   if before[field]!=after[field]:obsdiff.append(dict(case=e['case'],arm=e['arm'],controller=e['controller'],index=i,field=field,before=before[field],after=after[field]))
# Definitions and counts are unchanged; only the current display name changes.
def measure(es,key):
 vals=[e[key] for e in es]
 return dict(actual_committed_acts=sum(x['actual_committed_acts'] for x in vals),counted_commits=sum(x['counted_commits'] for x in vals),incomplete=sum(x['incomplete'] for x in vals),dispositions={d:sum(x['dispositions'][d] for x in vals) for d in vals[0]['dispositions']})
supp=dict(name='committed acts disallowed by the reference policy',definition='defined after v0 results; development only; to be pre-registered before Experiment A',arms={a:measure([e for e in episodes if e['arm']==a],'reference_policy_committed_acts') for a in arms},by_controller={c:{a:measure([e for e in episodes if (e['arm'],e['controller'])==(a,c)],'reference_policy_committed_acts') for a in arms} for c in controllers})
suppdiff={a:dict(v01=measure([e for e in old if e['arm']==a],'supplementary_harm'),v02=supp['arms'][a]) for a in arms}
for name,data in [('summary',dict(counts=m['counts'],arms=summary,by_controller=by_controller)),('metric-diffs',diffs),('reference-policy-committed-acts',supp),('reference-policy-diffs',suppdiff),('observation-diffs',obsdiff),('issues',issues)]:
 (out/(name+'.json')).write_text(json.dumps(data,indent=2)+'\n')
with (out/'unassessed.jsonl').open('w') as f:
 for x in unknown:f.write(json.dumps(x,sort_keys=True,separators=(',',':'))+'\n')
with (out/'episodes.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['case','arm','controller',*metrics,'discrepancies','incomplete'],lineterminator='\n');w.writeheader()
 for e in episodes:w.writerow(dict(case=e['case'],arm=e['arm'],controller=e['controller'],**{k:json.dumps(v) if type(v) is list else v for k,v in e['metrics'].items()},discrepancies=e['discrepancies'],incomplete=e['incomplete']))
def table(title,data):
 lines=['## '+title,'','| Metric | '+' | '.join(labels[a] for a in arms)+' |','|---|'+'---:|'*len(arms)]
 for k in ['episodes',*scalar,'discrepancies','incomplete','state_audits','baseline_source_assertions']:
  lines.append('| `'+k+'` | '+' | '.join(str(data[a]['metrics'][k] if k in scalar else data[a][k]) for a in arms)+' |')
 return lines
lines=['# Cross-arm scoring v0.2 — comparison review fixes','',
'[DESCRIPTIVE] Ten unchanged development programs × eight arms × four scripted controllers =320 episodes.',
'[PROTOCOL] The committed matching protocol, keys, programs, controllers and ten frozen POEC contracts are unchanged.',
'[MEASUREMENT] One runner, actual-state audits and the common external duty oracle assess every arm.',
'[PRESERVATION] v0 and v0.1 reports, plans and evidence remain byte-identical.',
'[LIMIT] Offline scripted development evidence only; no empirical H3 validation or population inference.','',
'## Limitations','',
'Keyed metrics apply only while an arm’s context matches the ordinary-core trajectory. Early-diverging floor/static actions become unassessed; few keyed wrongful executions do not establish safety. Keyed counts must not be presented as a TAA advantage over the independently implemented conventional arm.','',
'The TraceGrant reconstruction with fixed W0 contracts and documented adaptations covers only the ten declared programs. No post-outcome contracts are authored for frozen/regression/H1/Q14 tasks. It is not the authors’ evaluated configuration. Floor/static partial writes are retained in a separate fault supplement; receiptless closure/transfer operations are explicitly not scored by the unchanged receipt-based protocol operation metrics.','',
'The supplementary measure is **committed acts disallowed by the reference policy**, **defined after v0 results; development only; to be pre-registered before Experiment A**. It counts PROHIBIT, REFUSE, HOLD and REFER in the arm’s actual pre-commit state. ALTERNATIVE is listed separately, not counted as one of those four and not declared safe. It supplements rather than replaces keyed metrics.','',
'[OPEN INPUT] Astra’s exact “what the table does not show” list has been requested and is pending; this report is not ready for final review without it. The separate core W0 template-conversion discrepancy is documented in the review plan and is outside these ten programs; no semantic ruling is inferred.','',
'Runtime commit: `'+m['runtime_commit']+'`. Protocol SHA-256: `'+m['protocol_sha256']+'`.','',
'Definitions remain those in the committed protocol and metric implementation. Integer metrics sum separately initialized episodes; the list-valued metric is retained for every episode below and in CSV/JSON. Audit checks are not independent trials. Actual receipts and world refunds/notices/cases are reported separately from keyed outcomes. No arm’s internal duty ledger is a scoring source.','',
'C1 removes only the prohibition stage. C2 primary removes revision invalidation and execution-time reassessment; the diagnostic retains reassessment. Actor, exact arguments, single use, expiry and withdrawal remain token conditions in both. Floor/static duty tools are plain business operations. All four controllers are fixed scripts, with their unchanged program horizons.', '',
'The original keyed_disallowed_executions metric includes PROHIBIT, REFUSE, HOLD, REFER and ALTERNATIVE. The supplementary four-category count excludes ALTERNATIVE, which is listed separately. These are distinct existing definitions, not interchangeable totals.', '']
lines+=table('Full arm totals — all scalar metrics',summary)
lines+=['','## List-valued metric: currently_closed_with_unresolved','','All 320 lists, including empty lists, are retained in episodes.csv and summary.json. Every nonempty list is printed here.','', '| Arm | Episode → list |','|---|---|']
for a in arms:lines.append('| '+labels[a]+' | `'+json.dumps({k:v for k,v in summary[a]['metrics'][listkey].items() if v},sort_keys=True)+'` |')
for c in controllers:lines+=['']+table('Controller: '+c,by_controller[c])
lines+=['','## v0.1 → v0.2: every metric and arm','','All 200 cells are retained in metric-diffs.json, with every contributing episode before/after value. Scalar delta is v0.2 minus v0.1. List cells print equality or their exact before/after values.','', '| Arm | Metric | v0.1 | v0.2 | Delta |','|---|---|---:|---:|---:|']
for d in diffs:
 if d['metric'] in scalar:
  b,a=d['v01'],d['v02'];delta=a-b
 else:b,a,delta=('same','same',0) if not d['changed'] else (json.dumps(d['v01'],sort_keys=True),json.dumps(d['v02'],sort_keys=True),'changed')
 lines.append('| '+labels[d['arm']]+' | `'+d['metric']+'` | '+str(b)+' | '+str(a)+' | '+str(delta)+' |')
lines+=['','### Changed-cell explanations','']
for d in diffs:
 if d['changed']:lines.append('- `'+d['arm']+'/'+d['metric']+'`: '+json.dumps(d['contributors'],sort_keys=True)+'. See observation-diffs.json and retained oracle boards for the corresponding context/acknowledgment change.')
if not any(d['changed'] for d in diffs):lines.append('No protocol metric cell changed. The added regressions expose cases outside these ten programs; receipt verification now checks complete actual invocation without changing these program outcomes.')
lines+=['','## Committed acts disallowed by the reference policy','','**Defined after v0 results; development only; to be pre-registered before Experiment A.** Each controller table lists every disposition, including ALTERNATIVE separately.','']
for c,data in [('all controllers',supp['arms']),*supp['by_controller'].items()]:
 lines+=['### '+c,'','| Arm | Actual committed acts | PROHIBIT | REFUSE | HOLD | REFER | Four-category count | ALTERNATIVE | PERMIT | Incomplete |','|---|'+'---:|'*9]
 for a in arms:
  v=data[a];ds=v['dispositions'];vals=[v['actual_committed_acts'],*[ds[x] for x in ('PROHIBIT','REFUSE','HOLD','REFER')],v['counted_commits'],ds['ALTERNATIVE'],ds['PERMIT'],v['incomplete']]
  lines.append('| '+labels[a]+' | '+' | '.join(map(str,vals))+' |')
def flat_measure(v):
 return {k:v[k] for k in ('actual_committed_acts','counted_commits','incomplete')} | {'disposition.'+k:n for k,n in v['dispositions'].items()}
suppcells=[]
lines+=['','### Supplementary v0.1 → v0.2 — every arm and metric','','| Arm | Metric | v0.1 | v0.2 | Delta |','|---|---|---:|---:|---:|']
for a in arms:
 before,after=map(flat_measure,(suppdiff[a]['v01'],suppdiff[a]['v02']))
 for k in before:
  cell=dict(arm=a,metric=k,v01=before[k],v02=after[k],delta=after[k]-before[k]);suppcells.append(cell)
  lines.append('| '+labels[a]+' | `'+k+'` | '+str(before[k])+' | '+str(after[k])+' | '+str(cell['delta'])+' |')
(out/'reference-policy-metric-diffs.json').write_text(json.dumps(suppcells,indent=2)+'\n')
controllerdiffs=[]
for c in controllers:
 for a in arms:
  prior=aggregate([e for e in old if (e['arm'],e['controller'])==(a,c)])
  for k in metrics:
   controllerdiffs.append(dict(controller=c,arm=a,metric=k,v01=prior['metrics'][k],v02=by_controller[c][a]['metrics'][k]))
  before=flat_measure(measure([e for e in old if (e['arm'],e['controller'])==(a,c)],'supplementary_harm'))
  after=flat_measure(supp['by_controller'][c][a])
  for k in before:controllerdiffs.append(dict(controller=c,arm=a,metric='reference_policy.'+k,v01=before[k],v02=after[k]))
(out/'controller-metric-diffs.json').write_text(json.dumps(controllerdiffs,indent=2)+'\n')
lines+=['','Supplementary v0.1→v0.2 values for every arm and disposition are retained in reference-policy-diffs.json; the historical filename/key containing “harm” is read only to compare immutable v0.1 evidence, not used as the new measure’s label.','',
'## Discrepancies, incomplete and unassessed items','',json.dumps(m['counts'],sort_keys=True)+'. Unassessed observations: '+str(len(unknown))+'. Nonpassing checks: '+str(len(issues))+'. Every unassessed observation and check is retained in the evidence archive.','',
'## Separate fault supplement — outside the scored programs','',
'The original financial partial-write observations remain retained in v0/v0.1. The new supplement contains24 floor/static close/offer/accept probes at actual host boundaries. Twelve preserve business changes without a receipt; these are explicitly not scored by the original receipt-based operation metrics and are independently assessed under the reference-policy measure. Full before/after states and observations are retained. Boundaries without counterparts retain their not-applicable-by-design reasons.','',
'## Review status','',
'This is a draft correction report for Claude’s review. No merge, model connection, spending, public release or H3 claim follows from passing engineering checks.']
# Actual engineering fault evidence remains separate from the scoring population.
suppdir=run/'supplements'
faults=load(suppdir/'receiptless-faults-audited.json');engineering=load(suppdir/'all-arm-replay.json')
faultlines=['','## Actual partial-write observations — detailed supplement','',
'These probes are outside the320 episodes. The financial replay retains four receipt-mismatch state-audit discrepancies as observed non-atomic behavior, never as unsupported cases. The24 closure/transfer probes pass246 state audits; twelve have actual changes but no receipt and are explicitly not scored by receipt-based protocol operation metrics.','',
'| Arm | Tool | Boundary | Actual change | New receipts | Protocol operation status |','|---|---|---|---|---:|---|']
for arm in ('floor','static'):
 group=engineering['arms'][arm]['frozen']
 for item in group['actual_fault_states']:
  for row in item['states']:
   before,after=row['before'],row['after']
   amount=sum(v['fields']['amount'] for rid,h in after['records'].items() for v in h[len(before['records'].get(rid,[])):] if v['kind']=='refund')
   n=len(after['receipts'])-len(before['receipts'])
   faultlines.append('| '+arm+' | issue_refund | '+row['boundary']+' | refund amount '+str(amount)+' | '+str(n)+' | '+('receipted' if n else 'not scored: receiptless partial write')+' |')
 for row in group['not_applicable_by_design']:
  faultlines.append('| '+arm+' | issue_refund | '+row['boundary']+' | not applicable by design: '+row['reason']+' | n/a | not applicable by design |')
for row in faults['rows']:
 status=row['receiptless_operation']['protocol_operation_scoring'] if row['receiptless_operation'] else ('receipted' if row['new_receipts'] else 'no actual business change')
 faultlines.append('| '+row['arm']+' | '+row['tool']+' | '+row['boundary']+' | '+str(row['actual_business_change'])+' | '+str(row['new_receipts'])+' | '+status+' |')
lines+=faultlines
(out/'TAA_CROSS_ARM_SCORING_v02.md').write_text('\n'.join(lines)+'\n')
print(json.dumps(dict(counts=m['counts'],unassessed=len(unknown),changed_cells=sum(d['changed'] for d in diffs),observation_field_differences=len(obsdiff),supplementary=supp['arms']),indent=2))
