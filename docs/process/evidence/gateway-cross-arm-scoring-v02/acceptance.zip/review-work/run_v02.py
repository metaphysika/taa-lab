"""One authorized offline v0.2 execution; no automatic retry."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,os,subprocess,sys,traceback
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--runtime',required=True);a=p.parse_args();root=a.root.resolve();out=a.out.resolve()
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
assert not git('status','--porcelain'),'scoring requires clean implementation commit'
assert git('rev-parse','HEAD')==a.runtime
unchanged=['agents/refunds','worlds/refunds','comparators/contracts','tests/expected_traces','docs/process/TAA_CROSS_ARM_PROTOCOL_v0.md']
assert not git('diff','120d8b6a70aa417b32560135151acddcca3a0676','HEAD','--',*unchanged),'protocol/program/controller/key/contract changed'
sys.path.insert(0,str(root))
from comparators.cross_arm import run_suite,ARMS,PROTOCOL
from agents.refunds import CONTROLLERS
from worlds.refunds.catalog import catalog,provenance
from tests.trace_support.bundle import verify_bundle
verify_bundle();programs=catalog();assert [x['id'] for x in programs]==['T%02d'%i for i in range(1,11)]
assert hashlib.sha256(PROTOCOL.read_bytes()).hexdigest()=='e8059b51eaea0399f4ffe198d5712497067e5a0f43045539ffad1a71a67b9580'
preserved=json.loads((Path(__file__).parent/'preservation.json').read_text())
def verify_preserved():assert all(hashlib.sha256((root/k).read_bytes()).hexdigest()==v for k,v in preserved.items()),'historical evidence changed'
verify_preserved();files={}
for name in git('ls-files').splitlines():
 if name.startswith(('taa_gateway/','taa_gateway_reference/','conventional_gateway/','comparators/','agents/refunds/','worlds/refunds/','tests/trace_support/','tests/expected_traces/')):
  f=root/name
  if f.is_file():files[name]=hashlib.sha256(f.read_bytes()).hexdigest()
out.mkdir(parents=True,exist_ok=False)
m=dict(version='v0.2',runtime_commit=a.runtime,input_commit=a.runtime,status='running',started_utc=datetime.now(timezone.utc).isoformat(),python=sys.version,source_sha256=files,driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),programs=[c['id'] for c in programs],arms=list(ARMS),controllers=list(CONTROLLERS),expected_episodes=320,protocol_sha256=hashlib.sha256(PROTOCOL.read_bytes()).hexdigest(),preserved=preserved,provenance=provenance())
(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');seen=[];journal_digests=[]
try:
 with (out/'episodes.jsonl').open('x') as f:
  def retain(e):
   identity=(e['case'],e['arm'],e['controller']);assert identity not in seen;seen.append(identity)
   line=json.dumps(e,sort_keys=True,allow_nan=False,separators=(',',':'));f.write(line+'\n');f.flush();os.fsync(f.fileno());journal_digests.append(hashlib.sha256(line.encode()).hexdigest())
   print(json.dumps(dict(episode=len(seen),case=e['case'],arm=e['arm'],controller=e['controller'],discrepancies=e['discrepancies'],incomplete=e['incomplete'])),flush=True)
  result=run_suite(on_episode=retain)
 assert len(result['episodes'])==320 and len(seen)==320
 assert [hashlib.sha256(json.dumps(e,sort_keys=True,allow_nan=False,separators=(',',':')).encode()).hexdigest() for e in result['episodes']]==journal_digests
 assert all(hashlib.sha256((root/k).read_bytes()).hexdigest()==v for k,v in files.items())
 small={k:v for k,v in result.items() if k!='episodes'};small['episode_journal']='episodes.jsonl'
 (out/'results-summary.json').write_text(json.dumps(small,indent=2)+'\n');verify_preserved()
 m.update(status='completed',counts=result['counts'],completed_utc=datetime.now(timezone.utc).isoformat(),episode_sha256=journal_digests)
except BaseException as error:
 m.update(status='stopped',episodes_retained=len(seen),error=dict(type=type(error).__name__,message=str(error)),stopped_utc=datetime.now(timezone.utc).isoformat());(out/'error.log').write_text(traceback.format_exc());raise
finally:(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
