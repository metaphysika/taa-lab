from pathlib import Path
import json,hashlib,sys
oldrun,newrun,out=map(Path,sys.argv[1:]);old={}
identity=lambda e:(e['case'],e['arm'],e['controller'])
for line in (oldrun/'episodes.jsonl').open():
 e=json.loads(line);old[identity(e)]=e
counts=dict(episodes=0,identical_final_worlds=0,identical_oracle_boards=0,identical_per_episode_reference_policy_counts=0,identical_source_and_audit_checks=0)
metadata_differences={}
def differences(a,b,path=''):
 if type(a) is dict and type(b) is dict:
  for k in sorted(a.keys()|b.keys()):
   if k not in a or k not in b:metadata_differences[path+'.'+k]=metadata_differences.get(path+'.'+k,0)+1
   else:differences(a[k],b[k],path+'.'+k)
 elif type(a) is list and type(b) is list:
  if len(a)!=len(b):metadata_differences[path+'.length']=metadata_differences.get(path+'.length',0)+1
  for x,y in zip(a,b):differences(x,y,path+'[]')
 elif a!=b:metadata_differences[path]=metadata_differences.get(path,0)+1
for line in (newrun/'episodes.jsonl').open():
 e=json.loads(line);p=old[identity(e)];counts['episodes']+=1
 for field,key in [('final_world','identical_final_worlds'),('oracle_board','identical_oracle_boards')]:
  assert p[field]==e[field],(identity(e),field);counts[key]+=1
 prior=p['supplementary_harm'];current={k:v for k,v in e['reference_policy_committed_acts'].items() if k!='measure'}
 assert prior==current,identity(e);counts['identical_per_episode_reference_policy_counts']+=1
 assert p['assertions']==e['assertions'] and p['key_acceptance']==e['key_acceptance'],identity(e);counts['identical_source_and_audit_checks']+=1
 for a,b in zip(p['observations'],e['observations']):differences(a,b,'observations')
assert counts['episodes']==320
result=dict(counts=counts,observation_metadata_difference_paths=metadata_differences,scope='Read-only post-run comparison; no episodes rerun, no metric definitions changed.')
out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
