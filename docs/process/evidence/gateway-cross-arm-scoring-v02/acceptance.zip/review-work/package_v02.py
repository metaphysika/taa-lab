"""Package retained v0.2 evidence without modifying prior runs."""
from pathlib import Path
import hashlib,json,shutil,sys,zipfile
root,run,prep=map(Path,sys.argv[1:]);rendered=run/'rendered'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text())
m=load(run/'manifest.json');assert m['status']=='completed' and m['counts']['episodes']==320
assert m['counts']['discrepancies']==m['counts']['incomplete']==0
for name in ('discovery','scripted','controls-final','all-arm-replay','run','render-final'):
 assert (prep/(name+'.exit')).read_text().strip()=='0',name
preserved=load(prep/'preservation.json');assert all(sha(root/p)==h for p,h in preserved.items())
allarm=load(prep/'all-arm-replay.json');assert allarm['gate_pass']
faults=load(prep/'receiptless-faults-audited.json');assert len(faults['rows'])==24 and sum(r['receiptless_operation'] is not None for r in faults['rows'])==12
assert all(x['status']=='pass' for r in faults['rows'] for x in r['state_audits'])
summary=load(rendered/'summary.json');diffs=load(rendered/'metric-diffs.json');assert len(diffs)==200
assert load(rendered/'issues.json')==[]
out=root/'docs/process/evidence/gateway-cross-arm-scoring-v02';out.mkdir(exist_ok=False)
for name in ('summary.json','episodes.csv','metric-diffs.json','reference-policy-committed-acts.json','reference-policy-diffs.json','reference-policy-metric-diffs.json','controller-metric-diffs.json'):
 shutil.copyfile(rendered/name,out/name)
report=root/'docs/process/TAA_CROSS_ARM_SCORING_v02.md';report.write_text((rendered/report.name).read_text()+'\nEvidence: [validation](evidence/gateway-cross-arm-scoring-v02/validation.json), [full metric diff](evidence/gateway-cross-arm-scoring-v02/metric-diffs.json), [arm/controller totals](evidence/gateway-cross-arm-scoring-v02/summary.json), [reference-policy committed-act measure](evidence/gateway-cross-arm-scoring-v02/reference-policy-committed-acts.json), and acceptance.zip in the same directory.\n')
files={str(p.relative_to(run)):p for p in sorted(run.rglob('*')) if p.is_file()}
for p in sorted(prep.rglob('*')):
 if p.is_file() and '__pycache__' not in p.parts and 'scripted-results' not in p.parts:
  files['review-work/'+str(p.relative_to(prep))]=p
# Runtime source and the separate authored probes are reviewable without loading model artifacts.
for name in ['comparators/business.py','comparators/commit_oracle.py','comparators/cross_arm.py','comparators/duty_oracle.py','comparators/tracegrant.py','comparators/world.py','comparators/execution_observation.py','comparators/retained_actual.py','conventional_gateway/policy.py','tests/test_comparison_review_v02.py','tests/regression_scenarios/comparison_review_v02.yaml','tests/regression_scenarios/tracegrant_injected_drift_v02.json','docs/process/TAA_COMPARISON_REVIEW_v02.md']:
 files['source/'+name]=root/name
hashes={name:sha(p) for name,p in files.items()};archive=out/'acceptance.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in files.items():z.write(p,name)
 z.writestr('MANIFEST.sha256',''.join(h+'  '+name+'\n' for name,h in hashes.items()))
assert archive.stat().st_size<100*1024*1024
with zipfile.ZipFile(archive) as z:assert all(hashlib.sha256(z.read(name)).hexdigest()==h for name,h in hashes.items())
validation=dict(version='v0.2',runtime_commit=m['runtime_commit'],counts=m['counts'],protocol_sha256=m['protocol_sha256'],preserved=preserved,
 metric_cells=200,changed_metric_cells=sum(d['changed'] for d in diffs),all_arm_replay_gate=True,
 unassessed=sum(x['metrics']['unassessed_actions'] for x in summary['arms'].values()),
 controls=dict(methods=8,before_failures=4,before_errors=0,after_failures=0,receiptless_fault_probes=24,receiptless_partial_operations=12,receiptless_state_audits=246),
 supplementary_metric_cells=72,changed_supplementary_metric_cells=sum(d['v01']!=d['v02'] for d in load(rendered/'reference-policy-metric-diffs.json')),
 controller_metric_cells=1088,changed_controller_metric_cells=sum(d['v01']!=d['v02'] for d in load(rendered/'controller-metric-diffs.json')),
 world_comparison=load(prep/'world-comparison.json'),
 pending_inputs=['Exact Astra what-the-table-does-not-show list','Claude ruling on additional core W0 template conversion discrepancy'],
 scheduling_change=load(prep/'scheduling-change.json'),
 tracegrant_coverage='Ten predeclared development programs with fixed W0 contracts and documented adaptations only; no new contracts.',
 report_sha256=sha(report),archive=dict(path=str(archive.relative_to(root)),sha256=sha(archive),bytes=archive.stat().st_size,files=hashes))
(out/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
assert all(sha(root/p)==h for p,h in preserved.items())
print(json.dumps({k:v for k,v in validation.items() if k not in ('archive','preserved')},indent=2));print('archive',archive.stat().st_size,sha(archive))
