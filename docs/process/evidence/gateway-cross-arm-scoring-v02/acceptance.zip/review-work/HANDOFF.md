# Active comparison fix task (do not restart the v0.2 run)

Latest priority: user relayed Astra/Claude's three comparison blockers; fix in one PR, rerun320 as v0.2 preserving v0/v0.1, then resume audit/MCP separately. No model calls, Modal, spend, deletions or releases.

Repo / branch: /workspace/taa-comparison-v02, fix/comparison-v02.
Frozen runtime commit: 4bb6d23c1fb186d7f00a35e07d059a53eafb0858 (clean, pushed).
Draft PR33: https://github.com/metaphysika/taa-lab/pull/33 . Needs Claude review and green CI; no merge approval yet.

Implemented: conventional full-chain customer/template scope and root action-standing guard; oracle ACK candidate dedup by duty id with all old guards; TraceGrant actual tool/actor/full canonical arguments + postconditions (trusted actual-operation journal and physical notice check). Added separate user-directed regressions and injected-drift probe; frozen fixtures unchanged. Labels updated in current docs and historic erratum; v0/v0.1 immutable.

Controls: before 3 methods/4 subtest failures/0errors covering three bugs; after8 methods pass. 24 receiptless-business fault probes,12 partial operations,246 common state audits pass. Explicit not-scored marker for receipt-based closure/transfer metrics; separate post-v0 reference-policy assessment retained. Full root discovery1114 tests,36 optional skips,0fail/error (1816.859s); scripted scenarios0; frozen manifest/validator49 variants0errors.

ACTIVE: all-arm engineering replay (started before commit, source bytes identical) and single320 v0.2 run. Do not run either again just because results exist. Inspect .exit and logs:
- /workspace/scratch/comparison-v02/{all-arm-replay.log,json,exit}
- /workspace/scratch/comparison-v02/{run.log,exit}
- /workspace/scratch/gateway-cross-arm-scoring-v02/{manifest.json,episodes.jsonl,results-summary.json}
Raw v0.2 uses compact episodes journal, no duplicate pretty results.json. Manifest protects input/program/controller/key/contract hashes and all15 v0/v0.1 files.

A waiting render_final_when_complete.sh process will, after both exit0, copy separate fault supplements and render all tables/diffs into the v0.2 run/rendered directory. Check render-final.exit and render.log. DO NOT launch another renderer into an existing directory. Helpers are in /workspace/scratch/comparison-v02. Renderer makes a draft report, full200 protocol cells, every arm/controller table, supplementary counts/dispositions, unassessed/issue files and detailed fault table.

NEXT after run/render: inspect diffs and explain every changed cell concretely; improve draft report if necessary without rerunning. Run package_v02.py ROOT RUN PREP (requires test/run/render exit0); archive includes full raw journal, reports, source, controls and fault states. Publish docs/process/TAA_CROSS_ARM_SCORING_v02.md and evidence/gateway-cross-arm-scoring-v02/. Verify retained v0/v0.1 hashes and original source inputs. Update README/notebook/results/discrepancy statuses (docs only), commit/push same PR33, update body/title. No merge until Claude review+CI. Source code freeze must remain4bb6d23c for this run.

Two idle wait-controller processes were intentionally terminated BEFORE any implementation commit/scoring to overlap independent checks efficiently. pipeline.exit and render-pipeline.exit are143; they are NOT failed tests or interrupted research outcomes. scheduling-change.json documents it; preserve these records. The current render-final controller is separate and correct. Package checks run/render-final, not old pipeline exits.

PENDING REQUIRED INPUTS (async asked; no reply yet):
1. Astra's exact "what the table does not show" list. PR32 comments and read-only Notion MVP tracker have no copy; new report explicitly pending, do not invent attribution.
2. For Claude: additional audit found core RefundWorld.grant drops scope.template. A refund_issued notice restricted to refund_denied is REFUSE on reference/corrected SQL, PERMIT on core. Preserving scope in generic checker would HOLD template-less calls whereas reference ignores template restriction there. No declared ten program uses template-scoped grant. Recorded COMP-V02-CORE-TEMPLATE-CONVERSION and alignment note; no semantic fix inferred. Do not mutate source mid-run.

PR33 attachment tool codex_app__attach_artifact was called but is unusually slow (functions exec cell143 still awaiting); wait/verify if possible, do not block local work. URL already given to user.

PAUSED work preserved: replay branch feat/gateway-replay-v01 at f0e40cc1 in /workspace/taa-gateway-v032 (361 pages+manifest, deterministiczipSHA94c8b666... 18.7MB; full1111 tests pass). MCP branch feat/gateway-mcp-v032 at4626784b (no current worktree; old directory was moved/reused for comparison fix), thin offline stdio, acceptance138 scenarios/1055source/3875audits/0discrep/incomplete, full1113tests pass. No PRs for these yet. After fix, adapt replay to v0.2 actual retained channels rather than inventing missing native history; MCP remains no live client. Each future PR needs Claude/CI.
