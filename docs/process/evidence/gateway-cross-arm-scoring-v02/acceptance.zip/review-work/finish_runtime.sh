#!/bin/bash
set -euo pipefail
cd /workspace/taa-comparison-v02
prep=/workspace/scratch/comparison-v02
while [[ ! -f "$prep/discovery.exit" || ! -f "$prep/all-arm-replay.exit" ]]; do sleep 5; done
[[ $(cat "$prep/discovery.exit") == 0 ]]
[[ $(cat "$prep/all-arm-replay.exit") == 0 ]]
[[ $(cat "$prep/scripted.exit") == 0 ]]
[[ $(cat "$prep/controls-final.exit") == 0 ]]
git diff --check
/workspace/scratch/gateway-py311/bin/python /tmp/preserve_scoring.py
git add .github/workflows/gateway.yml README.md LAB_NOTEBOOK.md comparators/business.py comparators/commit_oracle.py comparators/cross_arm.py comparators/duty_oracle.py comparators/tracegrant.py comparators/world.py comparators/execution_observation.py comparators/retained_actual.py conventional_gateway/policy.py docs/process/TAA_COMPARISON_REVIEW_v02.md docs/process/TAA_GATEWAY_C3_v0.md docs/process/TAA_GATEWAY_CODE_INVENTORY_v0.md docs/process/TAA_GATEWAY_PRIOR_ART_v1.md tests/regression_scenarios/README.md tests/regression_scenarios/comparison_review_v02.yaml tests/regression_scenarios/tracegrant_injected_drift_v02.json tests/test_comparison_review_v02.py
git commit -m 'Fix comparison scope, report acknowledgments and receipt verification'
git rev-parse HEAD > "$prep/runtime-commit.txt"
HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 /workspace/scratch/gateway-py311/bin/python "$prep/run_v02.py" --root /workspace/taa-comparison-v02 --out /workspace/scratch/gateway-cross-arm-scoring-v02 --runtime "$(cat "$prep/runtime-commit.txt")" > "$prep/run.log" 2>&1
printf '0\n' > "$prep/run.exit"
