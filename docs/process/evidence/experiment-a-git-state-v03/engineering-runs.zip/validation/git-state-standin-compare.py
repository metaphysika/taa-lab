import json
from pathlib import Path
from zipfile import ZipFile
from live_demo.evidence import encoded
root=Path('/workspace/scratch/experiment-a-git-state-v03-standin')
prior=Path('docs/process/evidence/experiment-a-measures-v02/engineering-runs.zip')
with ZipFile(prior) as archive:
 old=[json.loads(archive.read(name)) for name in sorted(archive.namelist()) if name.startswith('standin/') and name.count('/')==1 and name.rsplit('/',1)[-1][:6].isdigit() and name.endswith('.json')]
new=[json.loads(path.read_bytes()) for path in sorted(root.glob('*.json')) if path.stem.isdigit()]
a=[encoded(row['value']['body']) for row in old if row['kind']=='request']
b=[encoded(row['value']['body']) for row in new if row['kind']=='request']
assert a==b and len(a)==396
old_rows=[row['value'] for row in old if row['kind']=='episode_summary']
new_rows=[row['value'] for row in new if row['kind']=='episode_summary']
assert old_rows==new_rows and len(old_rows)==396
report=dict(label='[Descriptive] Engineering stand-in comparison only',status='PASS',requests_byte_equal=396,episode_rows_exactly_equal=396,baseline=str(prior),new_root=str(root))
Path('/workspace/scratch/git-state-standin-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
