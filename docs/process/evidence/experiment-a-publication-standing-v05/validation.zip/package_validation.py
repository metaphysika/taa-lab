"""Archive offline validation only, retaining every diagnostic; never keys.env."""
import ast,base64,hashlib,json,os,re,subprocess,zipfile
from pathlib import Path

ROOT=Path('/workspace/taa-experiment-a-evidence-fix')
OUT=Path(__file__).parent
DEST=ROOT/'docs/process/evidence/experiment-a-publication-standing-v05'
for name in ('full-discovery','focused','scripted-all'):
    assert (OUT/(name+'.exit')).read_text().strip()=='0', name
source=json.loads((OUT/'source-before.json').read_text())
assert all(hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==v for n,v in source.items())
preflight=json.loads((OUT/'real-preflight.json').read_text())
for n,v in preflight['state_files'].items():
    p=Path('/workspace/taa-experiment-state')/n
    assert hashlib.sha256(p.read_bytes()).hexdigest()==v['sha256'] and p.stat().st_mtime_ns==v['mtime_ns']
standin=json.loads((OUT/'standin-verification.json').read_text())
assert standin['episodes']==396 and standin['chains']==397
report=dict(claim='[Descriptive] Offline engineering validation only; no provider request, model campaign, verdict or scientific expected outcome generation.',
    focused_log=(OUT/'focused.log').read_text().splitlines()[-4:],full_log=re.findall(r'Ran \d+ tests in [^\n]+|^OK(?: \(skipped=\d+\))?$',(OUT/'full-discovery.log').read_text(),re.M),
    required_scripted_all_exit=0,standin_episodes=396,standin_chains=397,
    canonical_request_bodies_and_complete_episode_rows_identical=396,source_snapshot_stable=True,
    preservation=json.loads((OUT/'preservation.json').read_text())['status'],protected_files=140,retained_scored_episodes=320,
    real_sources_touched_indices=91,next_untouched_index=91,missing_outage_metrics_not_reconstructed=True,
    actual_state_commit=preflight['state_commit'],actual_state_files_and_timestamps_unchanged=True,
    dedicated_evidence_branch=json.loads((OUT/'evidence-branch.json').read_text()))
(OUT/'validation.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
archive=OUT/'validation.zip'
files=[p for p in sorted(OUT.rglob('*')) if p.is_file() and p!=archive and '__pycache__' not in p.parts]
assert all(p.name!='keys.env' for p in files)
manifest={str(p.relative_to(OUT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for p in files:z.write(p,p.relative_to(OUT))
patterns=next(ast.literal_eval(n.value) for n in ast.parse((ROOT/'studies/live-demo-03131469-review/scan_original_evidence.py').read_bytes()).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='patterns' for t in n.targets))
secrets=[v.encode() for k,v in os.environ.items() if v and any(w in k for w in ('API_KEY','TOKEN_SECRET','ACCESS_TOKEN'))]
findings=[];decoded=0
def scan(name,b):
    global decoded
    assert Path(name).name!='keys.env'
    assert not re.search(r'(^|/)(?:H\d\d\.json|expected-key-H[^/]*\.md|[^/]*\.once)$',name)
    for label,pat in patterns.items():
        if re.search(pat,b):findings.append(dict(file=name,category=label))
    if any(s in b for s in secrets):findings.append(dict(file=name,category='configured_secret_match'))
    if name.endswith('.json'):
        try:r=json.loads(b)
        except (ValueError,UnicodeError):return
        if isinstance(r,dict)and r.get('kind')=='native_reply':
            decoded+=1;scan(name+'#decoded',base64.b64decode(r['value']['base64'],validate=True))
for p in files:scan(str(p.relative_to(OUT)),p.read_bytes())
with zipfile.ZipFile(archive)as z:
    assert z.testzip()is None and len(z.namelist())==len(manifest)
    for name in z.namelist():
        b=z.read(name);assert hashlib.sha256(b).hexdigest()==manifest[name];scan(name,b)
scan(archive.name,archive.read_bytes())
assert not findings
scan_report=dict(claim='[Descriptive] PR38 patterns and exact configured-secret comparisons, every retained validation file/member and decoded native reply; zero secret values emitted.',findings=findings,files=len(files),members=len(manifest),decoded_native_replies=decoded,no_H_material=True,
    archive=dict(bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest()),source_sha256=manifest)
(OUT/'credential-scan.json').write_text(json.dumps(scan_report,indent=2,sort_keys=True)+'\n')
DEST.mkdir(parents=True,exist_ok=False)
import shutil
for name in ('validation.zip','validation.json','credential-scan.json','source-before.json','real-preflight.json','standin-verification.json'):
    shutil.copy2(OUT/name,DEST/name)
print(json.dumps({k:v for k,v in scan_report.items()if k!='source_sha256'}))
