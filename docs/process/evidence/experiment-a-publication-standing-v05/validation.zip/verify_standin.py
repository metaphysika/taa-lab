"""Canned stand-in equality/preservation check, never expected science labels."""
from pathlib import Path
from unittest.mock import patch
import socket,json
from experiment_a.run import run
from live_demo.evidence import verify,encoded
out=Path(__file__).parent;directory=out/'standin396-final'
with patch.object(socket,'socket',side_effect=AssertionError('network forbidden')):report=run(directory)
assert report['stop']=='complete' and len(report['episodes'])==396
checkpoints=[dict(directory=str(p),**verify(p)) for p in [directory]+sorted(directory.glob('episode-*'))]
base=Path('/workspace/scratch/experiment-a-repush-v042/standin396')
def frames(p):return [json.loads(f.read_bytes()) for f in sorted(p.glob('[0-9]*.json'))]
a,b=frames(base),frames(directory)
aa=[encoded(f['value']['body']) for f in a if f['kind']=='request'];bb=[encoded(f['value']['body']) for f in b if f['kind']=='request']
ar=next(f['value']['episodes'] for f in a if f['kind']=='summary');br=next(f['value']['episodes'] for f in b if f['kind']=='summary')
assert len(aa)==len(bb)==396 and aa==bb and ar==br
result=dict(claim='[Descriptive] Canned engineering only; no scientific expected outcomes generated.',episodes=396,chains=len(checkpoints),canonical_request_bodies_identical=396,complete_episode_rows_identical=396,baseline=str(base),checkpoints=checkpoints)
(out/'standin-verification.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print({k:v for k,v in result.items() if k!='checkpoints'})
