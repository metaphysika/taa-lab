from pathlib import Path
import hashlib,json,os,re,subprocess,sys,zipfile
R=Path('/workspace/taa-experiment-a');V=Path('/workspace/scratch/experiment-a-provider-update-v01');E=R/'docs/process/evidence/experiment-a-provider-update-v012'
sys.path.insert(0,str(R))
from experiment_a import config
from experiment_a.cases import sealed_digest
from live_demo.evidence import verify
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_bytes())
def write(p,d):p.write_text(json.dumps(d,sort_keys=True,indent=2)+'\n')
full=(V/'full-tests.log').read_text();assert 'Ran 1809 tests' in full and 'OK (skipped=36)' in full
assert 'Ran 245 tests' in (V/'focused.log').read_text() and '\nOK\n' in (V/'focused.log').read_text()
assert load(V/'preservation.json')['status']=='PASS'
engineering=load(V/'engineering-verification.json');assert engineering['status']=='PASS' and engineering['episodes']==396
for name,checkpoint in engineering['chains'].items():assert verify(V/name)==checkpoint
pins=load(V/'source-before-validation.json')
for name,digest in pins.items():assert sha(R/name)==digest
config.verify();seal=sealed_digest(Path('/workspace/taa-experiment-a-evidence/state/sealed/H-v01-encoding-final'))
assert seal==(config.INPUTS/'H.sha256').read_text().strip()
assert sealed_digest(Path('/workspace/taa-experiment-a-sealed/H-v01-encoding-final'))==seal
before=load(Path('/workspace/scratch/experiment-a/actual-state-ledger-before.json'))
for field in ('all_provider_ledgers','state_and_openai'):
 for path,digest in before[field].items():assert sha(Path(path))==digest
state=Path('/workspace/taa-experiment-a-evidence/state')
assert subprocess.run(['git','-C',str(state),'rev-parse','--show-toplevel'],capture_output=True).returncode != 0
assert not any((state/n).exists() for n in ('state.json','step-budget.txt','run.once'))
for name,digest in [('experiment-a-offline','633faea9d5028e7f4b9c56b251fafa94a7a2e016b2291ca5e5481b784fc24315'),('experiment-a-assertion-binding','16f3b3a35071ebb21aa4e3d05249d2daa4a729f307b191817382e711d4f87bd2')]:
 assert sha(R/'docs/process/evidence'/name/'acceptance.zip')==digest
# Only approved prospective input files may change; P/science/guide remain identical.
changed=set(subprocess.check_output(['git','diff','--name-only','467b2eea','--','experiment_a/inputs'],cwd=R,text=True).splitlines())
assert changed=={'experiment_a/inputs/design.json','experiment_a/inputs/prices.json','experiment_a/inputs/hashes.json'},changed
assert subprocess.check_output(['git','diff','467b2eea','--','taa_gateway','taa_gateway_reference','conventional_gateway','comparators','live_demo/frozen','tests/regression_scenarios'],cwd=R)==b''
record=dict(claim='[Descriptive] Approved offline provider/cache/guard update; no launch approval.',status='PASS',base_commit='467b2eeae5dc2d59aacd47967a3809e5e5802fc3',source_sha256=pins,input_sha256=config.verify(),
 models=config.MODELS,step_cap=config.STEP_CAP,provider_stops=config.PROVIDER_CAPS,focused_tests=dict(run=245,status='PASS',seconds=float(re.search(r'Ran 245 tests in ([0-9.]+)s', (V/'focused.log').read_text()).group(1))),full_tests=dict(run=1809,status='PASS',skipped=36),scripted_all='PASS',
 unshare=dict(status='KERNEL_DENIED',evidence='unshare-focused.log',fallback='Socket-denying focused harnesses; CI sudo unshare --net'),
 mutations=load(V/'mutation-proof-v03.json'),neutral_checks={p:load(V/('neutral-'+p+'-report.json')) for p in config.MODELS},standin=dict(episodes=396,stop='complete',bookkeeping='Artificial $1/M fixture ledgers; not actual charges',costs=load(V/'standin-396-report.json')['costs'],verified_chains=399),
 preservation=dict(status='PASS',protected_files=140,retained_episodes=320,policy_change_record='docs/process/evidence/experiment-a-assertion-binding/validation.json'),
 sealed_H=dict(location=str(state/'sealed/H-v01-encoding-final'),sha256=seal,unsealed=False,details_archived=False,loader_refuses=True),
 actual_markers_and_five_ledgers_unchanged=True,old_archives_unchanged=True,operational_experiment_state_provisioned=False,gateway_policy_and_fixtures_unchanged=True,provider_API_requests=0,actual_API_dollars=0,
 price_sources={p:{k:row[k] for k in ['model','source_url','additional_sources','verified_at','status','valid_until']} for p,row in config.load('prices.json').items()},
 cost_projection=load(V/'cost-projection.json'))
E.mkdir(exist_ok=False);write(E/'verification.json',record)
write(V/'final-integrity.json',dict(status='PASS',source_pins_unchanged=True,sealed_H=record['sealed_H'],actual_markers_and_five_ledgers_unchanged=True,operational_state_unprovisioned=True,old_archives_unchanged=True,verified_chains=399))
with (R/'LAB_NOTEBOOK.md').open('a') as f:f.write('\n[Descriptive] Provider-update closure:245focused tests PASS; final duration in verification.json; local unshare denied by kernel with log retained, socket-blocked harnesses and CI OS isolation. Full1809tests PASS/36existing optional skips; scripted-all PASS; preservation140files/original320episodes PASS against unchanged pinned assertion policy record. Both stand-in neutral checks complete2requests each;396/396canned D+P episodes complete,399chains verified. Seven targeted mutations caught, including both reviewed survivors; initial recorder KeyError diagnostic retained. Config/model/cache changes are engineering only; no policy/fixture/measures/guide/staff/prompt/scorer change or scored/U-controller/live rerun. DurableH copy at/workspace/taa-experiment-a-evidence/state/sealed/H-v01-encoding-final, same seal2f53b1db5767159e79e58f6703462daa9549d1ccbc83726afe3e925ec4654147, no operational state manifest/ledger/marker provisioned. Actual markers/fiveproviderledgers and both prior archives unchanged. Provider API/modelrequests0, actual API dollars0.\n\n[Interpretive] Cost projection, D+P198episodes/provider: with5000totalSonnetoutputtokens/episode and synthetic20inputtokens/episode, cache-disabled9.907920USD / cache-enabled-nohits9.909900USD / hypothetical onecold-perprogramthenhits9.901452USD. Gemini synthetic7visible+3thinkingtokens:0.010395USD /0.010395USD /0.008019USD. Warm scenario assumes reuse before eviction and exceeds what the literal20tokenfixture can cache (Sonnetminimum512); it is a rate sensitivity, not a live forecast. Real prompts/turns/thinking can cost much more; actual usage/caps govern. Full formulas/P-only breakdown in new evidence. Pushforreview, no merge or launch.\n')
files={}
for p in sorted(V.rglob('*')):
 if p.is_file() and '__pycache__' not in p.parts:
  assert p.name!='keys.env' and not p.is_symlink();files['raw/'+p.relative_to(V).as_posix()]=p
names=list(pins)+['experiment_a/inputs/prices.json','experiment_a/inputs/design.json','experiment_a/inputs/hashes.json','.github/workflows/experiment-a.yml','README.md','LAB_NOTEBOOK.md','docs/process/TAA_EXPERIMENT_A_PROVIDER_UPDATE_v012.md']
for name in names:files['snapshot/'+name]=R/name
files['snapshot/verification-before-archive.json']=E/'verification.json'
patterns=[re.compile(rb'\bsk-(?:proj-|ant-)?[A-Za-z0-9_-]{32,}'),re.compile(rb'AIza[A-Za-z0-9_-]{30,}'),re.compile(rb'\b(?:ghp_|github_pat_)[A-Za-z0-9_]{30,}')]
secrets=[v.encode() for k,v in os.environ.items() if any(t in k.upper() for t in ('API_KEY','TOKEN_SECRET','ACCESS_TOKEN','GITHUB_TOKEN')) and len(v)>=8]
hashes={}
for name,p in files.items():
 raw=p.read_bytes()
 if any(p.search(raw) for p in patterns) or any(v in raw for v in secrets):raise RuntimeError('credential scan match in '+name)
 hashes[name]=hashlib.sha256(raw).hexdigest()
archive=E/'acceptance.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,p in files.items():z.write(p,name)
 z.writestr('MEMBERS.sha256.json',json.dumps(hashes,sort_keys=True,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,digest in hashes.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
record['archive']=dict(sha256=sha(archive),bytes=archive.stat().st_size,members=len(hashes)+1,verified_member_hashes=len(hashes),CRC='PASS',credential_scan_matches=0)
write(E/'verification.json',record)
(E/'README.md').write_text('# [Descriptive] Experiment A provider-update evidence\n\n[Descriptive] Read [the update report](../../TAA_EXPERIMENT_A_PROVIDER_UPDATE_v012.md) and verification.json. Archive includes socket-blocked focused/full/scripted logs, local unshare denial, both canned checks, all396canned episodes/native usage,399checkpoints, isolated mutation proofs (including initial recorder diagnostic), price/cost formulas and source snapshots. No provider API/model requests or actual spending; no H inputs/details included.\n\n[Descriptive] ArchiveSHA256 `'+record['archive']['sha256']+'`; '+str(record['archive']['bytes'])+'bytes/'+str(record['archive']['members'])+'members. CRC and all member hashes verified. Credential pattern/configured-value scans0matches; keys.env untouched. This cannot prove absence of unknown credentials. Inner snapshot precedes final archive closure; outer verification pins final archive.\n\n[Descriptive] DurableH location `/workspace/taa-experiment-a-evidence/state/sealed/H-v01-encoding-final`; SHA256 `'+seal+'`. Original retained, loader refusesH, state is storage-only without launch/accounting provisioning. Actual markers/fiveledgers and prior archives unchanged. Review only; no merge/launch.\n')
print(json.dumps(dict(status='PASS',archive=record['archive'])))
