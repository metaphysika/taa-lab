from pathlib import Path
import hashlib,json,socket,sys
R=Path('/workspace/taa-experiment-a');V=Path('/workspace/scratch/experiment-a-provider-update-v01');sys.path.insert(0,str(R))
from experiment_a import config
from experiment_a.check import run as check
from experiment_a.run import run
from experiment_a.cases import sealed_digest
from live_demo.evidence import verify

def denied(*a,**k):raise AssertionError('provider update engineering: outbound socket forbidden')
socket.socket=denied;socket.create_connection=denied
for provider in config.MODELS:
 result=check(provider,V/('neutral-'+provider))
 assert result['stop']=='complete' and result['requests']==2
 (V/('neutral-'+provider+'-report.json')).write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
 print(json.dumps(dict(provider=provider,stop=result['stop'],requests=result['requests'])),flush=True)
result=run(V/'standin-396')
(V/'standin-396-report.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
assert result['stop']=='complete' and len(result['episodes'])==396
chains=[V/('neutral-'+p) for p in config.MODELS]+[V/'standin-396']+sorted((V/'standin-396').glob('episode-*'))
heads={str(p.relative_to(V)):verify(p) for p in chains}
seal=sealed_digest(Path('/workspace/taa-experiment-a-evidence/state/sealed/H-v01-encoding-final'))
assert seal==(config.INPUTS/'H.sha256').read_text().strip()
config.verify()
(V/'engineering-verification.json').write_text(json.dumps(dict(claim='[Descriptive] Socket-blocked canned protocol checks, not model runs.',status='PASS',episodes=396,chains=heads,H_sha256=seal,provider_requests=0,API_dollars=0),sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(stop=result['stop'],episodes=len(result['episodes']),costs=result['costs'],verified_chains=len(heads))),flush=True)
