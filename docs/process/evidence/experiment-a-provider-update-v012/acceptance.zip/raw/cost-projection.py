"""Arithmetic scenarios only, from retained canned native usage and stated assumptions."""
from collections import Counter
from decimal import Decimal as D
import json
from pathlib import Path
R=Path('/workspace/taa-experiment-a');V=Path('/workspace/scratch/experiment-a-provider-update-v01')
report=json.loads((V/'standin-396-report.json').read_bytes());assert report['stop']=='complete' and len(report['episodes'])==396
prices=json.loads((R/'experiment_a/inputs/prices.json').read_bytes());schedule=json.loads((R/'experiment_a/inputs/pilot-order.json').read_bytes())
rows=[]
for scope,select in [('D+P pilot',lambda row:True),('P only',lambda row:row['program'].startswith('P'))]:
 for provider in ('anthropic','google'):
  specs=[r for r in schedule if r['provider']==provider and select(r)]
  episodes=len(specs);programs=len(set(r['program'] for r in specs))
  measured=report['costs'][provider];assert measured['attempts']==198 and measured['input']==3960
  # Canned exchange is one request/episode, reports 20 input, 10 total output.
  input_tokens=episodes*20;observed_output=episodes*10
  output_tokens=episodes*5000 if provider=='anthropic' else observed_output
  cold_tokens=programs*20;hit_tokens=input_tokens-cold_tokens
  rates=prices[provider]['rates'];rate=lambda k:D(rates[k+'_per_million'])
  output_cost=D(output_tokens)*rate('output')/1000000
  nocache=output_cost+D(input_tokens)*rate('input')/1000000
  cold=output_cost+D(input_tokens)*rate('cache_write_5m' if provider=='anthropic' else 'input')/1000000
  warm=output_cost+(D(cold_tokens)*rate('cache_write_5m' if provider=='anthropic' else 'input')+D(hit_tokens)*rate('cache_read'))/1000000
  rows.append(dict(scope=scope,provider=provider,episodes=episodes,programs=programs,standin_input_tokens=input_tokens,standin_output_including_thinking=observed_output,
   projected_output_including_thinking=output_tokens,first_miss_input_tokens=cold_tokens,assumed_hit_input_tokens=hit_tokens,
   without_caching_dollars=str(nocache),cache_enabled_no_hits_dollars=str(cold),one_cold_request_per_program_then_hits_dollars=str(warm)))
value=dict(claim='[Interpretive] Conditional arithmetic from synthetic stand-in usage, not a forecast of model usage or cache hits.',
 assumptions=['Sonnet total output including thinking = 5000 tokens per episode at default high effort; no explicit effort parameter.',
 'Gemini visible/thinking tokens stay at synthetic stand-in 7+3 per episode; unknown real output may be much larger.',
 'Canned prompt usage is 20 tokens/request, not a tokenization of the actual prompt; 1 request/episode. Real episodes may use up to 12 turns.',
 'Warm scenario: one cold request for each program, all later 8 repeated/arm requests reuse all input before eviction; Anthropic 5m writes charged, Google normal input on misses.',
 '20 synthetic input tokens are below Anthropic cache minimum512; warm scenario is a hypothetical price sensitivity, not attainable for that literal token count.',
 'No explicit Google cache resources/storage cost; no retries, neutral checks, prior spend, or other provider costs included. Actual ledgers/caps remain controlling.'],rows=rows)
(V/'cost-projection.json').write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
print(json.dumps(value,indent=2))
