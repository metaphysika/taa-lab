from contextlib import nullcontext
from copy import deepcopy
import io,json,socket,sys,unittest
from pathlib import Path
from unittest.mock import patch
R=Path('/workspace/taa-experiment-a');V=Path('/workspace/scratch/experiment-a-provider-update-v01');sys.path.insert(0,str(R))
from experiment_a import config,native
from tests.test_experiment_a_provider_update import ProviderUpdate
original_system=config.system;original_body=native.body;original_parse=native.parse

def changed_body(*args,**kw):
 b=original_body(*args,**kw)
 if args[0]=='anthropic':b['system'][0]['text']+='\n'
 return b

def missing_cache(*args,**kw):
 b=original_body(*args,**kw)
 if args[0]=='anthropic' and b['tools']:b['tools'][-1].pop('cache_control',None)
 return b

def lost_signature(provider,reply,turn):
 r=deepcopy(reply)
 if provider=='google':r['candidates'][0]['content']['parts']=[p for p in r['candidates'][0]['content']['parts'] if set(p)!={'thoughtSignature'}]
 return original_parse(provider,r,turn)

def missing_id(*args,**kw):
 b=original_body(*args,**kw)
 if args[0]=='google':
  for c in b['contents']:
   for part in c['parts']:
    if 'functionResponse' in part:part['functionResponse'].pop('id',None)
 return b
mutants=[('Google cap raised',patch.dict(config.PROVIDER_CAPS,google='16'),'test_approved_caps_are_literal_pins'),
 ('Rendered system changed',patch.object(config,'system',side_effect=lambda:original_system()+'\n'),'test_rendered_system_bytes_are_pinned_in_both_wire_formats'),
 ('Wire system changed',patch.object(native,'body',side_effect=changed_body),'test_rendered_system_bytes_are_pinned_in_both_wire_formats'),
 ('Tool cache marker omitted',patch.object(native,'body',side_effect=missing_cache),'test_three_explicit_cache_breakpoints_and_no_signed_block_edit'),
 ('Signature-only part dropped',patch.object(native,'parse',side_effect=lost_signature),'test_signature_only_part_survives_roundtrip_and_call_id_is_rest_id'),
 ('Function response id dropped',patch.object(native,'body',side_effect=missing_id),'test_signature_only_part_survives_roundtrip_and_call_id_is_rest_id')]
rows=[]
for name,context,test in mutants:
 result=unittest.TestResult()
 with context:ProviderUpdate(test).run(result)
 assert len(result.failures)+len(result.errors)==1,(name,result.errors)
 rows.append(dict(mutation=name,test=test,caught=True,assertion_failures=len(result.failures),test_errors=len(result.errors)))
p=V/'mutation-proof-v02.json';p.write_text(json.dumps(dict(claim='[Descriptive] Isolated in-process mutations; no source edits or provider requests.',status='PASS',rows=rows),sort_keys=True,indent=2)+'\n')
print('PASS',len(rows),'of',len(mutants),'mutations caught')
