[Descriptive] Builds the exploratory thirty-episode live-demo harness with identical model-visible system prompt, native business tools, staff text and first request across floor/static/MCP TAA arms. Model-visible replies contain only business results and constant short refusals. Independent scoring and audit data remain host-side. No thirty-episode launch has occurred.

[Descriptive] Chat Completions uses native function tools, assistant tool_calls/tool history, max_completion_tokens 4096, store:false, default sampling/reasoning settings, and no reasoning carry-over uniformly across arms. Frozen measures record that protocol; all prompts/programs/tools/order remain as reviewed. Output length ends only that episode as output_ceiling without executing calls; malformed output stops the run. Read calls are counted separately from committed acts. Chris approved this protocol switch on 2026-10-25; Claude accepted the prior head fae033e0, including its three additional guard tests. This does not approve a new neutral check or study launch.

[Descriptive] Existing launch guards require exact commit, clean source, explicit owner receipt, caps before every attempt, canonical provider lock/ledger and durable state at /workspace/taa-live-demo-evidence/state/. Attempts1/2/3 are used and retained; no study claim or attempt4. Neutral receipts require check_attempt; a run receipt requires the returned model string. The three launch-state/empty-tool-calls tests remain pinned, as do all prior fairness/leakage/state/budget/identity/transport guards. The [durable-state audit](docs/process/TAA_LIVE_DEMO_DURABLE_STATE_v013.md) retains the original once-marker and authorization/accounting history.

[Descriptive] Latest commit c7a205c4818138b30af0d30c4ce12c8f94a663f9 adds only the requested error-param filter to runtime: retain param if its string fully matches `[A-Za-z0-9_.\[\]]{1,128}`, otherwise withheld; existing controlled type/code fields remain. Never retain error message or raw body. New test subcases cover unsafe, overlong, newline, non-ASCII/non-string parameters and message exclusion; an in-memory removal of the regex causes one assertion failure with zero errors, baseline/restored passes. All frozen inputs and prior evidence archives remain unchanged. Version is v0.1.5.

[Descriptive] Actual neutral attempts1/2 returned HTTP401 and attempt3 at fae033e0 returned HTTP400, without a model reply or native usage. All evidence and conservative reservations remain; attempt3's error param was not retained by that older parser. Chris then approved ONE separate diagnostic process, at most four requests with 16-token ceilings, cumulative reservations at most $0.01, shared $5step/$8provider caps, immediate stop on401/5xx. All four bodies were frozen before replies; no retries or marker changes. Body(a) is byte-identical to attempt3's first request apart from the approved ceiling. b removes only store, c removes only tools and retains store:false, d removes strict from the tool function. No body contains reasoning_effort.

| Diagnostic variant | HTTP | Error type | Code | Param | Booked dollars |
| --- | --- | --- | --- | --- | --- |
| a: original body, ceiling16 | 400 | invalid_request_error | null | reasoning_effort | 0.002120625 |
| b: no store | 400 | invalid_request_error | null | reasoning_effort | 0.002118875 |
| c: no tools | 200 | — | — | — | 0.000011800 |
| d: no strict | 400 | invalid_request_error | null | reasoning_effort | 0.002118750 |

[Descriptive] c returned gpt-6-luna, finish_reason length, no tool_calls; native usage prompt38/completion16/total54, reasoning16 and all other usage-detail counts0. The [diagnostic report](docs/process/TAA_LIVE_DEMO_BODY_DIAGNOSTIC_v015.md) retains the complete native usage JSON. Four requests/one process; cumulative reservations $0.008449250 <= $0.01. Total booked $0.006370050 comprises observed native usage $0.000011800 plus retained error reserves $0.006358250 (actual billing for errors unknown). Step after $0.018854925; persisted OpenAI after $1.1516518999999985. Other provider ledgers, old reserves, markers and original evidence are unchanged. Actual round source, exact bodies, lock/booking evidence and before/after ledgers are archived with [validation](docs/process/evidence/gateway-live-demo-body-diagnostic-v015/validation.json).

[Open question] The tool-bearing requests were rejected with param reasoning_effort despite that field being absent from all sent bodies. This does not identify where it was introduced/checked, and the tool-free length result does not demonstrate native-tool compatibility or a passed two-request neutral check. No additional reasoning override or transport fix is included.

[Descriptive] Final validation: Python 3.11.17 full discovery PASS, 1,194 tests / 36 existing skips in 2,273.961s. 62 focused tests PASS locally with outbound sockets denied (258.345s). Preservation PASS, 140 protected files / 320 original episodes; scripted all scenarios PASS; existing seven review mutants and new param-pattern mutant caught with baseline/restored passes. Four diagnostic stand-in campaigns pin four-success/four-error accounting and immediate401/503stops. Exact-head [namespace CI PASS](https://github.com/metaphysika/taa-lab/actions/runs/40202269152): 62 tests in 102.208s under sudo unshare --net, preservation and seven review mutants PASS. Local unshare is kernel-denied; local socket denial is not claimed as namespace isolation. Prior 61/1193,58/1190 and52/1184 test evidence stays unchanged in its original archives.

[Descriptive] Earlier approved same-process non-generating authentication probes remain:

| Request | HTTP | Error type | Code |
| --- | --- | --- | --- |
| GET /v1/models | 200 | null | null |
| POST /v1/responses, body {} | 401 | invalid_request_error | invalid_api_key |
| POST /v1/chat/completions, body {} | 400 | invalid_request_error | null |

[Descriptive] Chris's 2026-10-25 protocol approval: “I approve switching the live demo to OpenAI Chat Completions with native function tools and no reasoning carry-over, identical across all arms, because the environment's proxy does not authenticate /v1/responses.” The neutral staff text approved2026-10-24 remains byte-identical in all10programs/all3arms:

```text
A: you, refund agent.
B: refund agent.
L: desk lead; runs refund operations; takes over open customer matters that no one else holds.
C: compliance officer; receives misconduct reports; handles data requests; takes over open customer matters that no one else holds.
F: finance controller; holds refund authority; decides claims; receives misconduct reports.
R: fraud reviewer; answers fraud questions.
K1, K2: customers.
```

[Descriptive] Diagnostic approval is exhausted. No further provider request, neutral attempt, thirty episodes, merge or release. Stop for Claude review and new exact-commit owner approval before any further paid step. Original Paper3/scientific freezes and outcomes are unchanged; no scored experiment rerun or new empirical TAA claim.


