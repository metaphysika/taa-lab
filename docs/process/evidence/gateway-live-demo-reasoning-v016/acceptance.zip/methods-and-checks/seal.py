"""Seal reasoning selection and offline validation without further calls."""
from pathlib import Path
from decimal import Decimal
import hashlib,json,re,subprocess,sys,zipfile
ROOT=Path('/workspace/taa-lab');sys.path.insert(0,str(ROOT))
WORK=Path('/workspace/scratch/live-demo-reasoning-v016')
LIVE=Path('/workspace/taa-live-demo-evidence/reasoning-effort-diagnostic-20261025-001')
BASE='c7a205c4818138b30af0d30c4ce12c8f94a663f9'
from live_demo import config
from live_demo.evidence import verify
from live_demo.state import LiveState
def sha(raw):return hashlib.sha256(raw).hexdigest()
def old(name):return subprocess.check_output(['git','show',BASE+':'+name],cwd=ROOT)
def suite(name,count):
    p=WORK/(name+'.log');s=p.read_text()
    assert re.search(r'^OK(?: \(skipped=\d+\))?$',s,re.M),name
    m=re.search(r'Ran (\d+) tests in ([\d.]+)s',s);skip=re.search(r'^OK \(skipped=(\d+)\)',s,re.M)
    assert int(m[1])==count
    return dict(tests=count,seconds=float(m[2]),skips=int(skip[1]) if skip else 0,sha256=sha(p.read_bytes()))
def main():
    full=suite('full',1195);focused=suite('focused',63)
    source=json.loads((WORK/'source-hashes.json').read_bytes())
    assert all(sha((ROOT/p).read_bytes())==h for p,h in source.items())
    allowed=set(source)
    for p in (ROOT/'live_demo').rglob('*'):
        if p.is_file() and '__pycache__' not in str(p):
            name=str(p.relative_to(ROOT))
            if name not in allowed:assert p.read_bytes()==old(name)
    frozen=config.verify();before=json.loads(old('live_demo/frozen/hashes.json'))
    assert [name for name in frozen if frozen[name]!=before[name]]==['live_demo/frozen/measures.json']
    settings=config.load('measures.json')['reasoning_effort']
    assert config.REASONING_EFFORT==settings['value']=='none'
    assert settings['deviation_from_provider_defaults'] and settings['identical_across_arms']
    result=json.loads((LIVE/'result.json').read_bytes());plan=json.loads((LIVE/'plan.json').read_bytes())
    assert result['requests']==3 and result['chosen_reasoning_effort']=='none'
    assert [row['status'] for row in result['rows']]==[400,400,200]
    assert Decimal(result['total_reserved_dollars'])<=Decimal('0.01')
    assert sum(Decimal(r['booked_dollars']) for r in result['rows'])==Decimal('0.004271175')
    assert verify(LIVE/'evidence')==result['checkpoint']
    state=LiveState()
    assert state.ledger.read_bytes()==(LIVE/'openai-ledger-after.json').read_bytes()
    assert state.step_ledger.read_bytes()==(LIVE/'step-budget-after.txt').read_bytes()
    assert state.step_ledger.read_text().strip()=='0.023126100'
    assert plan['initial_marker_hashes']=={p.name:sha(p.read_bytes()) for p in state.root.glob('*.once')}
    assert not (state.root/'run.once').exists() and not (state.root/'check-attempt-000004.once').exists()
    assert not state.lock.exists()
    standin=json.loads((WORK/'standin.log').read_bytes());neutral=json.loads((WORK/'neutral.log').read_bytes())
    assert standin['stop']=='complete' and standin['episodes']==30
    assert neutral['stop']=='complete' and neutral['requests']==2
    checkpoints={str(p.parent.relative_to(WORK)):verify(p.parent) for p in WORK.rglob('checkpoint.json')}
    assert len(checkpoints)==32
    for folder in (WORK/'standin',WORK/'neutral'):
        for p in folder.rglob('[0-9]*.json'):
            row=json.loads(p.read_bytes())
            if row['kind']=='request':
                body=row['value']['body'];assert body['reasoning_effort']=='none'
                assert set(body)=={'model','messages','tools','max_completion_tokens','store','reasoning_effort'}
    preservation=json.loads((WORK/'preservation.json').read_bytes())
    assert preservation['status']=='PASS' and len(preservation['protected_hashes'])==140 and preservation['episodes']==320
    mutants=json.loads((WORK/'review-mutations.json').read_bytes());assert mutants['status']=='PASS'
    assert (WORK/'override-mutations.log').read_text().count('caught; baseline/restored pass')==4
    assert (WORK/'standin-validation.log').read_text().count('PASS')==6
    assert (WORK/'scripted-scenarios').is_dir()
    prior={}
    for p in (ROOT/'docs/process/evidence').glob('gateway-live-demo*/**/*'):
        if p.is_file():
            name=str(p.relative_to(ROOT));assert p.read_bytes()==old(name);prior[name]=sha(p.read_bytes())
    for provider in ('claude','google','groq'):
        name='results/formation-spending-v021/'+provider+'.json';assert (ROOT/name).read_bytes()==old(name)
    files={}
    for folder,prefix in ((LIVE,'actual-diagnostic'),(WORK,'methods-and-checks')):
        for p in folder.rglob('*'):
            if p.is_file() and '__pycache__' not in str(p):files[prefix+'/'+str(p.relative_to(folder))]=p
    for name in source:files['source/'+name]=ROOT/name
    out=ROOT/'docs/process/evidence/gateway-live-demo-reasoning-v016';out.mkdir(exist_ok=False)
    members={}
    with zipfile.ZipFile(out/'acceptance.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for name,p in sorted(files.items()):
            assert p.name!='keys.env';raw=p.read_bytes();members[name]=sha(raw);archive.writestr(name,raw)
        archive.writestr('MEMBER_SHA256.json',json.dumps(members,sort_keys=True,indent=2)+'\n')
    with zipfile.ZipFile(out/'acceptance.zip') as archive:
        assert archive.testzip() is None and all(sha(archive.read(n))==h for n,h in members.items())
    report=dict(status='PASS',base=BASE,version='v0.1.6',repository_tests=full,focused_tests=focused,
        source_hashes=source,frozen_input_hashes=frozen,reasoning_effort=settings,diagnostic=result,
        preservation=preservation,standin=standin,neutral=neutral,checkpoints=checkpoints,
        review_mutations=mutants,override_mutations='4 caught, one assertion each, zero errors; baseline/restored PASS',
        diagnostic_mock_campaigns=6,old_archives_unchanged=prior,actual_provider_requests=3,
        no_real_neutral_check=True,no_real_thirty_episodes=True,no_merge=True,
        accounting=dict(step='0.023126100',openai='1.1559230749999982',booked='0.004271175',observed_usage='0.000023300',retained_error_reserves='0.004247875',markers_unchanged=True),
        local_namespace='Local unshare kernel-denied; socket-denied focused tests, pushed-head namespace CI in PR',
        archive=dict(bytes=(out/'acceptance.zip').stat().st_size,members=len(members)+1,sha256=sha((out/'acceptance.zip').read_bytes())))
    with (out/'validation.json').open('x') as stream:json.dump(report,stream,indent=2);stream.write('\n')
    print(json.dumps({k:report[k] for k in ('status','repository_tests','focused_tests','accounting','archive')},indent=2))
if __name__=='__main__':main()
