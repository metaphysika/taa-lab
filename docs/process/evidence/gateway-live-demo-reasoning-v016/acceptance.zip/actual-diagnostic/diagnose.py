"""One owner-approved body diagnostic round. No neutral once claims or retries."""
from copy import deepcopy
from datetime import datetime, timezone
from decimal import Decimal
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

REPO=Path('/workspace/taa-lab')
sys.path.insert(0,str(REPO))
from live_demo import adapter, chat, config
from live_demo.check import CheckAdapter
from live_demo.evidence import Evidence, encoded, verify
from live_demo.state import LiveState

ROOT=Path('/workspace/taa-live-demo-evidence/reasoning-effort-diagnostic-20261025-001')
BASE='c7a205c4818138b30af0d30c4ce12c8f94a663f9'
ROUND_CAP=Decimal('0.01')

def bodies():
    base=CheckAdapter(None,None).body([dict(role='user',content='Please perform the neutral echo task.')])
    earlier=Path('/workspace/taa-live-demo-evidence/neutral-fae033e0-20261025-003/evidence')
    first=next(json.loads(p.read_bytes())['value']['body'] for p in sorted(earlier.glob('[0-9]*.json'))
               if json.loads(p.read_bytes())['kind']=='request')
    assert encoded(base)==encoded(first)
    base['max_completion_tokens']=16
    rows=[dict(deepcopy(base),reasoning_effort=value) for value in ('medium','low','none')]
    return list(zip('efg',rows))

def reserve_amount(body,prices):
    maximum=max(Decimal(str(prices[k])) for k in ('input_per_million','cached_input_per_million','cache_write_per_million'))
    return (Decimal(len(encoded(body))+16384)*maximum+Decimal(16)*Decimal(str(prices['output_per_million'])))/1000000

def send(body):
    # Use precisely the harness's urllib module, environment binding, endpoint,
    # proxy and TLS defaults. Never expose header values or error messages.
    key=os.environ.get('TAA_OPENAI_API_KEY')
    if not key:raise adapter.Stop('missing_configured_key')
    request=adapter.urllib.request.Request('https://api.openai.com/v1/chat/completions',data=encoded(body),
        headers={'Content-Type':'application/json','Authorization':'Bearer '+key})
    try:
        with adapter.urllib.request.urlopen(request,timeout=120) as response:
            status=response.status
            raw=response.read(16*1024*1024+1)
            if len(raw)>16*1024*1024:raise adapter.Stop('reply_size')
    except adapter.urllib.error.HTTPError as error:
        return error.code,adapter.http_error_fields(error),None
    # No response text/content/tool arguments are persisted.
    return status,None,json.loads(raw)

def main():
    assert os.environ.get('TAA_OPENAI_API_KEY'), 'missing_configured_key'
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()==BASE
    config.verify()
    planned=bodies();prices=config.load('prices.json')
    reservations=[reserve_amount(body,prices) for _,body in planned]
    assert sum(reservations)<=ROUND_CAP
    state=LiveState()
    assert not state.lock.exists()
    assert not state.step_ledger.with_suffix('.pending').exists()
    assert not state.ledger.with_name(state.ledger.name+'.live-demo-pending').exists()
    assert not (state.root/'run.once').exists()
    initial_markers={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in state.root.glob('*.once')}
    ROOT.mkdir(exist_ok=False)
    (ROOT/'diagnose.py').write_bytes(Path(__file__).read_bytes())
    (ROOT/'openai-ledger-before.json').write_bytes(state.ledger.read_bytes())
    (ROOT/'step-budget-before.txt').write_bytes(state.step_ledger.read_bytes())
    plan=dict(owner='Chris',approved_date='2026-10-25',purpose='one reasoning-effort diagnostic round only, not a neutral check',
        base_commit=BASE,adapter_sha256=hashlib.sha256((REPO/'live_demo/adapter.py').read_bytes()).hexdigest(),
        script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),max_requests=3,max_reserved_dollars=str(ROUND_CAP),
        max_completion_tokens=16,planned_reservations=[str(r) for r in reservations],planned_total=str(sum(reservations)),
        bodies=[dict(variant=name,body=body) for name,body in planned],initial_marker_hashes=initial_markers,
        preflight_at_utc=datetime.now(timezone.utc).isoformat())
    (ROOT/'plan.json').write_bytes(encoded(plan)+b'\n')
    with (ROOT/'round.started').open('xb') as stream:
        stream.write(encoded(dict(pid=os.getpid(),plan_sha256=hashlib.sha256(encoded(plan)).hexdigest()))+b'\n')
        stream.flush();os.fsync(stream.fileno())
    evidence=Evidence(ROOT/'evidence')
    evidence.write('diagnostic_plan',plan)
    descriptor=os.open(state.lock,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    owner=encoded(dict(step='live-demo-body-diagnostic',output=str(ROOT),pid=os.getpid()))
    os.write(descriptor,owner);os.fsync(descriptor)
    rows=[];reserved=Decimal('0');stop='complete';old_ceiling=config.OUTPUT_TOKENS
    try:
        # Only this diagnostic process uses the expressly approved 16 ceiling.
        # Production constants, source files and frozen measures are unchanged.
        config.OUTPUT_TOKENS=16
        budget=adapter.Budget(state.ledger,evidence,step_ledger=state.step_ledger)
        for (name,body),maximum in zip(planned,reservations):
            if len(rows)>=3 or reserved+maximum>ROUND_CAP:raise adapter.Stop('diagnostic_cap')
            reservation,bound=budget.reserve(body)
            assert reservation==maximum
            reserved+=reservation
            evidence.write('request',dict(variant=name,body=body))
            before=budget.phase_spent
            row=dict(variant=name,status=None,error=None,finish_reason=None,model=None,tool_calls_present=None,native_usage=None,
                     reserved_dollars=str(reservation),booked_dollars=str(reservation))
            try:
                status,error,native=send(body)
                row.update(status=status,error=error)
                if native is not None:
                    if type(native) is not dict:raise adapter.Stop('unknown_output')
                    choices=native.get('choices');model=native.get('model')
                    row['model']=model;row['native_usage']=native.get('usage')
                    if type(choices) is list and len(choices)==1 and type(choices[0]) is dict:
                        row['finish_reason']=choices[0].get('finish_reason')
                        message=choices[0].get('message')
                        row['tool_calls_present']=bool(message.get('tool_calls')) if type(message) is dict else None
                    if type(model) is not str or not model:raise adapter.Stop('model_identity')
                    budget.settle(reservation,bound,chat.canonical(native),expected_model=model,native_usage=native.get('usage'))
                    row['booked_dollars']=str(reservation+budget.phase_spent-before)
                evidence.write('diagnostic_result',row);rows.append(row)
                if status==200:
                    stop='first_accepted';break
                if status==401 or 500<=status<=599:
                    stop='http_early_stop';break
                if status!=200 and error is None:
                    stop='unexpected_http_status';break
            except BaseException as error:
                row['guard_stop']=error.reason if isinstance(error,adapter.Stop) else type(error).__name__
                evidence.write('diagnostic_result',row);rows.append(row)
                stop='guard_or_transport_stop';break
        result=dict(stop=stop,chosen_reasoning_effort=next((body['reasoning_effort'] for (name,body) in planned if any(row['variant']==name and row['status']==200 and 'guard_stop' not in row for row in rows)),None),rows=rows,total_reserved_dollars=str(reserved),booked_dollars=str(budget.phase_spent),
            requests=budget.attempts,step_total=state.step_ledger.read_text().strip(),
            openai_total=str(json.loads(state.ledger.read_text(),parse_float=Decimal)['estimated_api_dollars']))
        checkpoint=evidence.close(result)
    finally:
        config.OUTPUT_TOKENS=old_ceiling
        os.close(descriptor)
        if state.lock.read_bytes()==owner:state.lock.unlink()
    assert verify(ROOT/'evidence')==checkpoint
    assert initial_markers=={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in state.root.glob('*.once')}
    (ROOT/'openai-ledger-after.json').write_bytes(state.ledger.read_bytes())
    (ROOT/'step-budget-after.txt').write_bytes(state.step_ledger.read_bytes())
    result.update(checkpoint=checkpoint,checkpoint_file_sha256=hashlib.sha256((ROOT/'evidence/checkpoint.json').read_bytes()).hexdigest(),
                  evidence=str(ROOT/'evidence'),markers_unchanged=True)
    (ROOT/'result.json').write_bytes(encoded(result)+b'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
