"""Read retained frozen measures only; no model calls, host replay or rescoring."""
from collections import Counter
from decimal import Decimal
from pathlib import Path
import csv,hashlib,json,subprocess,sys

ROOT=Path(__file__).resolve().parent
CHECKOUT=Path('/workspace/taa-live-demo-checkouts/run-03131469-20261025')
sys.path.insert(0,str(CHECKOUT))
from live_demo.evidence import verify

ARMS=('floor','static','taa')
DISPOSITIONS=('PROHIBIT','REFUSE','HOLD','REFER','ALTERNATIVE','PERMIT')
NORMAL_STOPS={'model_done','turn_limit','output_ceiling'}

def rows(folder):
    for p in sorted(folder.glob('[0-9]*.json')):
        yield p,json.loads(p.read_bytes())

def digest(raw):return hashlib.sha256(raw).hexdigest()

def main():
    evidence=ROOT/'evidence'
    checkpoint=verify(evidence)
    summaries=[];run=None;summary=None;charged=Decimal('0');observed_charge=Decimal('0');requests=0
    native_models=Counter();native_finishes=Counter();failures=[];retry_waits=[]
    for p,row in rows(evidence):
        kind=row['kind'];value=row['value']
        if kind=='run':run=value
        elif kind=='episode_summary':summaries.append(value)
        elif kind=='summary':summary=value
        elif kind=='ledger_change':charged+=Decimal(value['delta'])
        elif kind=='usage':observed_charge+=Decimal(value['charged'])
        elif kind=='request':requests+=1
        elif kind=='native_format':native_models[value['model_returned']]+=1
        elif kind=='native_reply':
            import base64
            native=json.loads(base64.b64decode(value['base64']))
            for choice in native.get('choices',[]):native_finishes[str(choice.get('finish_reason'))]+=1
        elif kind=='transport_failure':
            failures.append({k:value.get(k) for k in ('status','error','reservation_retained')})
        elif kind=='retry_wait':retry_waits.append(value)
    assert run is not None and summary is not None
    retained=summary['episodes'];assert len(retained)<=len(run['schedule'])==30
    assert [r['spec'] for r in retained]==run['schedule'][:len(retained)]
    pre=json.loads((ROOT/'preflight.json').read_bytes())
    assert run['pins']==pre['frozen_hashes']
    assert run['schedule']==pre['schedule']
    for name,expected in pre['frozen_hashes'].items():assert digest((CHECKOUT/name).read_bytes())==expected
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=CHECKOUT,text=True).strip()==pre['commit']
    assert subprocess.run(['git','symbolic-ref','-q','HEAD'],cwd=CHECKOUT,capture_output=True).returncode==1
    assert subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=CHECKOUT,text=True)==''
    chains={'root':checkpoint};per_episode=[];over_refusals=[];reporting=[];closed_cases=[]
    for index,r in enumerate(retained):
        episode='episode-%02d'%index;folder=evidence/episode
        chains[episode]=verify(folder)
        endings=[value['value'] for _,value in rows(folder) if value['kind']=='episode_end']
        assert endings==[r]
        m=r['metrics'];cost=r['cost'];ref=m['reference_policy']
        item=dict(episode=episode,**r['spec'],stop=r['stop'],turns=r['turns'],
            input_tokens=cost['input_tokens'],output_tokens=cost['output_tokens'],
            tokens=cost['input_tokens']+cost['output_tokens'],dollars=cost['dollars'],attempts=cost['attempts'],
            committed_nonread_acts=ref['actual_committed_acts'],disallowed_commits=ref['counted_commits'],
            dispositions=ref['dispositions'],committed_measure_incomplete=ref['incomplete'],
            prohibited_commits=m['prohibited_commits'],lawful_completion=m['lawful_completion'],
            gateway_over_refusals=len(m['gateway_over_refusals']),duty_integrity=m['duty_integrity'],
            reporting_owed=len(m['reporting']),reporting_delivered=sum(bool(q['delivered']) for q in m['reporting']),
            reporting_artifact_matches=sum(len(q['artifacts']) for q in m['reporting']),
            read_record_calls=m['read_record_calls'])
        per_episode.append(item)
        for number,call in enumerate(m['gateway_over_refusals'],1):
            over_refusals.append(dict(case='%s-OR%02d'%(episode,number),episode=episode,**r['spec'],**call))
        for duty in m['reporting']:reporting.append(dict(episode=episode,**r['spec'],**duty))
        for claim in m['duty_integrity']['currently_closed_with_unresolved']:
            closed_cases.append(dict(episode=episode,**r['spec'],claim=claim))
    numeric_duties=('unresolved_duties','overdue_duties','unowned_duties','report_duties',
        'reports_delivered','reports_acknowledged','closures_with_unresolved_duties',
        'invalid_transfer_operations','oracle_incomplete')
    per_arm={}
    for arm in ARMS:
        selected=[r for r in per_episode if r['arm']==arm]
        result=dict(scheduled_episodes=sum(s['arm']==arm for s in run['schedule']),
            retained_episodes=len(selected),completed_episodes=sum(r['stop'] in NORMAL_STOPS for r in selected),
            committed_nonread_acts=sum(r['committed_nonread_acts'] for r in selected),
            disallowed_commits=sum(r['disallowed_commits'] for r in selected),
            dispositions={d:sum(r['dispositions'][d] for r in selected) for d in DISPOSITIONS},
            committed_measure_incomplete=sum(r['committed_measure_incomplete'] for r in selected),
            prohibited_commits=sum(r['prohibited_commits'] for r in selected),
            lawful_completion=sum(r['lawful_completion'] for r in selected),
            gateway_over_refusals=sum(r['gateway_over_refusals'] for r in selected),
            duty_integrity={k:sum(r['duty_integrity'][k] for r in selected) for k in numeric_duties},
            currently_closed_with_unresolved=sum(len(r['duty_integrity']['currently_closed_with_unresolved']) for r in selected),
            reporting_owed=sum(r['reporting_owed'] for r in selected),
            reporting_delivered=sum(r['reporting_delivered'] for r in selected),
            reporting_artifact_matches=sum(r['reporting_artifact_matches'] for r in selected),
            read_record_calls={k:sum(r['read_record_calls'][k] for r in selected) for k in ('attempted','completed','refused')},
            output_ceiling_episodes=[r['episode'] for r in selected if r['stop']=='output_ceiling'],
            stops=dict(Counter(r['stop'] for r in selected)),
            input_tokens=sum(r['input_tokens'] for r in selected),output_tokens=sum(r['output_tokens'] for r in selected),
            tokens=sum(r['tokens'] for r in selected),turns=sum(r['turns'] for r in selected),
            attempts=sum(r['attempts'] for r in selected),dollars=str(sum((Decimal(r['dollars']) for r in selected),Decimal('0'))))
        original=summary['per_arm'][arm]
        assert result['committed_nonread_acts']==original['committed_acts']
        assert result['disallowed_commits']==original['disallowed_commits']
        assert result['dispositions']==original['dispositions']
        assert result['read_record_calls']==original['read_record_calls']
        assert result['disallowed_commits']==sum(result['dispositions'][d] for d in ('PROHIBIT','REFUSE','HOLD','REFER'))
        per_arm[arm]=result
    total=dict(input_tokens=sum(r['input_tokens'] for r in per_episode),output_tokens=sum(r['output_tokens'] for r in per_episode),
        tokens=sum(r['tokens'] for r in per_episode),turns=sum(r['turns'] for r in per_episode),
        attempts=sum(r['attempts'] for r in per_episode),dollars=str(sum((Decimal(r['dollars']) for r in per_episode),Decimal('0'))))
    assert total['input_tokens']==summary['totals']['input_tokens'] and total['output_tokens']==summary['totals']['output_tokens']
    assert total['attempts']==summary['totals']['attempts']==requests
    assert Decimal(total['dollars'])==Decimal(summary['totals']['dollars'])==charged
    state=Path('/workspace/taa-live-demo-evidence/state')
    spec=json.loads((state/'state.json').read_bytes());ledger=Path(spec['provider_ledger'])
    for name,expected in pre['existing_marker_sha256'].items():assert digest((state/name).read_bytes())==expected
    marker=json.loads((state/'run.once').read_bytes())
    assert marker['commit']==pre['commit'] and marker['output']==str(evidence)
    assert not Path(spec['provider_lock']).exists()
    assert not (state/'step-budget.pending').exists() and not ledger.with_name(ledger.name+'.live-demo-pending').exists()
    for name,expected in pre['other_provider_hashes'].items():
        assert digest((Path('/workspace/taa-lab/results/formation-spending-v021')/(name+'.json')).read_bytes())==expected
    after_step=(state/'step-budget.txt').read_text().strip()
    assert Decimal(after_step)==Decimal(pre['step_total'])+charged==Decimal(summary['step_dollars'])
    provider=str(json.loads(ledger.read_text(),parse_float=Decimal)['estimated_api_dollars'])
    (ROOT/'openai-ledger-after.json').write_bytes(ledger.read_bytes())
    (ROOT/'step-budget-after.txt').write_bytes((state/'step-budget.txt').read_bytes())
    result=dict(claim='Descriptive only; exploratory; never H3 evidence',commit=pre['commit'],
        stop=summary['stop'],scheduled_episodes=30,retained_episodes=len(retained),
        completed_episodes=sum(r['stop'] in NORMAL_STOPS for r in per_episode),
        per_arm=per_arm,per_episode=per_episode,totals=total,gateway_over_refusal_cases=over_refusals,
        reporting_duties=reporting,currently_closed_with_unresolved_cases=closed_cases,
        native_models=dict(native_models),native_finish_reasons=dict(native_finishes),
        transport_failures=failures,retry_waits=retry_waits,
        observed_usage_charge=str(observed_charge),retained_reserve_this_run=str(charged-observed_charge),
        step_total_after=after_step,openai_total_after=provider,evidence=str(evidence),checkpoints=chains,
        checkpoint_file_sha256=digest((evidence/'checkpoint.json').read_bytes()),
        aggregation='Sums of already-recorded frozen measures only; no replay, rescoring or implementation-generated expectations. Duty/report counts sum per-episode snapshots.',
        prior_markers_unchanged=True,run_once_retained=True,checkout_clean_and_detached=True)
    with (ROOT/'results.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
    fields=['episode','program','arm','stop','turns','input_tokens','output_tokens','tokens','dollars','attempts']
    with (ROOT/'per-episode.csv').open('x',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
        writer.writerows({k:r[k] for k in fields} for r in per_episode)
    with (ROOT/'over-refusals.json').open('x') as f:json.dump(over_refusals,f,indent=2);f.write('\n')
    with (ROOT/'reporting-duties.json').open('x') as f:json.dump(reporting,f,indent=2);f.write('\n')
    print(json.dumps({k:result[k] for k in ('stop','scheduled_episodes','retained_episodes','completed_episodes','per_arm','totals','step_total_after','openai_total_after','checkpoint_file_sha256')},indent=2))

if __name__=='__main__':main()
